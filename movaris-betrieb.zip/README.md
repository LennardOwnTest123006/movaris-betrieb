# MOVARIS Betrieb

Betriebs-App für MOVARIS Umzüge: Anfragen aus dem Postfach und von der Website einlesen, Angebote kalkulieren und versenden, Zuschlag oder Absage erfassen, Einsätze planen, Mitarbeiterstunden, Urlaub und Krankmeldungen verwalten. Dazu gibt es eine Mitarbeiter-App fürs Handy für Rückmeldungen vor Ort, die Stunden, Urlaubsanträge und Krankmeldungen.

Die App läuft **lokal** (Büro-PC, NAS) oder in einer **privaten Cloud** (eigener Server, Docker). Sie hat keine Lizenzkosten und keine Fremd-Clouds, die Daten bleiben bei MOVARIS.

---

## Funktionen

| Bereich | Was es kann |
|---|---|
| **Posteingang** | Liest Mails per IMAP (z. B. info@movaris.de) und/oder AgentMail regelmäßig ein. Erkannte Anfragen werden automatisch als Auftrag mit Kunde angelegt, inklusive Anhänge (Fotos/PDF). Unklare Mails landen zur Prüfung im Posteingang. Antworten mit Auftragsnummer im Betreff werden dem Auftrag zugeordnet, Abwesenheitsnotizen ignoriert. Dubletten werden verhindert. |
| **Website-Formular** | Anfragen der MOVARIS-Website gehen direkt in die App, geschützt mit einem Schlüssel (`INQUIRY_KEY`). |
| **Aufträge** | Tafel (Eingang → Angebot → Beauftragt → Abschluss) und Liste mit Suche und Filter. Der Status folgt dem Prozess: Neu → In Bearbeitung → Besichtigung → Angebot erstellt → Angebot versendet → **Zuschlag / Absage** → Geplant → In Durchführung → Erledigt → Abgerechnet. Jede Änderung steht im Verlauf. |
| **Angebotskalkulation** | Umzugsgutliste mit Richtwerten in m³, Personal × Stunden (auch als Schätzung aus dem Volumen), LKW, km, Zusatzleistungen aus dem Preiskatalog, freie Positionen, Zuschläge für Etagen ohne Aufzug, Laufweg und Wochenende sowie Nachlass und MwSt. Das Ergebnis wird live berechnet, mit Versionen. |
| **Angebot versenden** | Als formatierte E-Mail (SMTP oder AgentMail) oder drucken bzw. als PDF speichern. Der Kunde bekommt einen Link und kann das Angebot **online annehmen oder ablehnen**, danach steht der Auftrag automatisch auf Zuschlag bzw. Absage. |
| **Einsatzplanung** | Wochen- und Teamansicht mit Feiertagen in Niedersachsen. Termin, Team, Teamleitung und Fahrzeuge werden zugewiesen, mit **Konfliktprüfung** bei Urlaub, Krankheit, Doppelbelegung von Mitarbeitern oder LKW. |
| **Mitarbeiter** | Stammdaten, Soll- und Ist-Stunden, Über- und Minusstunden, **Stunden je Auftrag**, Gesamtleistung im Jahr (Stunden, Aufträge, Ø Std./Auftrag), Urlaubskonto (Anspruch, genommen, beantragt, Rest) und Krankheitstage. |
| **Stunden** | Freigabe der App-Einträge (einzeln oder alle) und Nachtragen im Büro. Hinweis auf Pausen nach Arbeitszeitgesetz. **CSV-Export für die Lohnbuchhaltung.** |
| **Urlaub & Krank** | Anträge genehmigen oder ablehnen, Krankmeldungen mit AU-Foto. Eingeplante Aufträge erhalten automatisch eine Warnung. |
| **Rückmeldungen** | Probleme, Sonderwünsche, Schäden und Infos aus dem Einsatz mit Fotos. Sonderwünsche werden automatisch im Auftrag vermerkt. |
| **Mitarbeiter-App** (`/m/`) | Lässt sich auf iPhone und Android installieren (PWA). Zeigt Heute und die nächsten Einsätze, hat Zeiterfassung per Knopfdruck, Auftragsdetails mit Navigation und Anruf-Link, Rückmeldungen mit Kamera, Stunden, Urlaubsantrag und Krankmeldung. **Ohne Netz** werden Meldungen gespeichert und später automatisch gesendet. |
| **Einstellungen** | Firmendaten und Angebotstexte, Kalkulationsfaktoren, Preiskatalog, Umzugsgutliste, Benutzer und Rollen, Fahrzeuge, Exporte und Datensicherung. |

**Rollen:**
- **Admin** (Geschäftsführung): alles, inklusive Preise, Benutzer und Sicherung.
- **Büro**: Aufträge, Planung, Mitarbeiter, Stunden, Urlaub.
- **Mitarbeiter**: nur die Mitarbeiter-App mit den eigenen Daten.

> Es sind **keine Preise hinterlegt**. Alle Sätze und Faktoren trägt MOVARIS unter *Einstellungen → Preise / Kalkulation* ein. Positionen ohne Preis meldet die Kalkulation.

---

## Start

### A) Büro-PC (Windows)
1. **Node.js 22 LTS** installieren: https://nodejs.org
2. Ordner entpacken und `start-windows.bat` doppelklicken.
3. Der Browser öffnet http://localhost:8080. Dort den ersten Admin-Zugang anlegen.

Andere Geräte im Büro-Netz erreichen die App über `http://<IP-des-PCs>:8080`. Handys im Büro-WLAN ebenso, mit `/m/` für die Mitarbeiter-App.

### B) Linux/macOS
```bash
cp .env.example .env      # anpassen
npm install --omit=dev
npm start                 # http://localhost:8080
```

### C) Private Cloud / Server mit Docker
```bash
cp .env.example .env      # PUBLIC_URL, Postfach, SMTP, INQUIRY_KEY eintragen
docker compose up -d      # SQLite, Daten in ./data
# mit PostgreSQL:
#   in .env: DATABASE_URL=postgres://movaris:PASSWORT@postgres:5432/movaris  und POSTGRES_PASSWORD=PASSWORT
docker compose --profile postgres up -d
```
Für HTTPS liegt ein Beispiel in `Caddyfile.example` bei (Caddy holt Zertifikate automatisch). Dann `TRUST_PROXY=true` setzen.
**Von außen (Handys unterwegs, Online-Annahme durch Kunden) muss die App per HTTPS erreichbar sein.**

---

## Postfach & Website anbinden

- **IMAP** (empfohlen): Die Zugangsdaten des Postfachs, z. B. info@movaris.de bei IONOS, Strato oder Google, kommen in `.env` (`IMAP_*`). Die App ruft alle `MAIL_POLL_MINUTES` ab und markiert verarbeitete Mails als gelesen. Unter *Einstellungen → Postfach* legst du fest, ob nur erkannte Anfragen, alle Mails oder nichts automatisch angelegt wird.
- **AgentMail**: `AGENTMAIL_API_KEY` und `AGENTMAIL_INBOX_ID` setzen. Darüber laufen dann Eingang und, falls kein SMTP eingerichtet ist, auch der Versand.
- **Angebote versenden**: `SMTP_*` (z. B. das Postfach info@movaris.de) oder AgentMail. Ohne Versand gibt es „Drucken/PDF“ und „Als versendet markieren“.
- **Website (Cloudflare)**: In der App `INQUIRY_KEY` als langen Zufallswert setzen. Auf der Website (Cloudflare → Variablen) setzt du `APP_INQUIRY_URL = https://<deine-app>/api/public/inquiry` und `APP_INQUIRY_KEY = <derselbe Wert>`. Das Anfrageformular der Website legt dann sofort einen Auftrag an.

Passwörter und Schlüssel stehen **nur** in `.env` auf dem Server, nie in der Oberfläche oder im Browser.

---

## Mitarbeiter-App installieren
1. Im Büro unter *Mitarbeiter → Name → Zugang anlegen* E-Mail und Passwort vergeben.
2. Auf dem Handy `https://<deine-app>/m/` öffnen und anmelden.
3. Auf dem **iPhone** in Safari *Teilen → Zum Home-Bildschirm* wählen. Auf **Android** im Chrome-Menü *App installieren* wählen.

---

## Datensicherung & Updates
- **SQLite**: Unter *Einstellungen → Daten & Export → Sicherung herunterladen* lädst du eine Sicherung herunter. Zusätzlich sollte der Ordner `data/` täglich gesichert werden (enthält Datenbank und Fotos).
- **PostgreSQL**: `pg_dump` sowie der Ordner `data/` mit den Fotos und PDFs.
- **Update**: Dateien ersetzen, dabei `data/` und `.env` behalten, dann neu starten bzw. `docker compose up -d --build`.

## Sicherheit
- Passwörter werden mit scrypt gespeichert. Die Sitzungen laufen über ein HttpOnly-Cookie, und es gibt einen Schutz gegen gefälschte Formular-Anfragen (CSRF-Header).
- Die Anmeldung ist begrenzt (10 Versuche in 15 Min.), dazu kommen strenge Sicherheits-Header (CSP, kein Einbetten).
- Uploads sind nur als JPG, PNG, WEBP oder PDF erlaubt, der Dateiinhalt wird geprüft. Ausgeliefert werden sie in einer Sandbox.
- Mitarbeiter sehen nur Aufträge, die ihnen zugeteilt sind, und keine Preise. Löhne sieht nur der Admin.
- Die CSV-Exporte sind gegen Formel-Injektion in Excel geschützt.

## Tests
```bash
npm install     # inkl. Testwerkzeug PGlite
npm test        # Rechenkern, Mail-Erkennung, Feiertage + kompletter Ablauf auf SQLite und PostgreSQL
```

## Technik
Node.js 22 ohne Web-Framework. Die Datenbank ist SQLite (in Node eingebaut) oder PostgreSQL. Die Oberfläche ist reines HTML/CSS/JavaScript ohne Build-Schritt und Tracker. Abhängigkeiten: `imapflow`, `mailparser`, `nodemailer`, `pg`.

## Schnelltest mit Beispieldaten
`test-start.bat` (Windows) startet Server, legt Beispielkunden, Aufträge, Mitarbeiter an und öffnet den Browser.
Logins: Büro `chef@movaris.de` / `SehrGeheim123`, Mitarbeiter-App `/m/` mit `tom@movaris.de` / `TomTom12345`.
Mit Supabase-Datenbank: `DATABASE_URL=postgres://postgres:PASSWORT@db.<projekt>.supabase.co:5432/postgres` in `.env` (Passwort aus Supabase → Project Settings → Database).
