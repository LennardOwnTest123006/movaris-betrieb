# Testbericht MOVARIS Betrieb (31.10.2026)

Umgebung: Node.js 22, Chromium (Playwright), SQLite (eingebaut) und PostgreSQL (PGlite).

| Prüfung | Ergebnis | Beleg |
|---|---|---|
| Rechenkern Kalkulation (Positionen, Zuschläge nur auf Personal, Nachlass anteilig, MwSt., fehlende Preise) | PASS | `tests/unit.test.mjs` |
| Mail-Erkennung (Website-Format, Freitext mit PLZ/Ort, m³, Etagen, Datum; Rechnungen nicht als Anfrage) | PASS | `tests/unit.test.mjs` |
| Feiertage Niedersachsen, Arbeitstage, Pausen nach ArbZG, CSV-Formelschutz | PASS | `tests/unit.test.mjs` |
| Gesamtablauf auf **SQLite**: Einrichtung, Login, CSRF, Rollen, Website-Anfrage, Postfach (angelegt/zur Prüfung/ignoriert/zugeordnet/Dublette), Statusregeln, Angebot (Kalkulation 1.927,21 €), Druck, Versand ohne Mailserver → klare Meldung, Online-Annahme durch Kunden → Zuschlag, Planung mit Konflikten (Urlaub, Doppelbelegung LKW/Mitarbeiter), Mitarbeiter-App (Zeiterfassung, Foto-Rückmeldung, gefälschtes Bild abgelehnt, fremde Fotos gesperrt, Abschluss → Erledigt), Stunden/Urlaub/Krank/Auswertung, Freigaben, CSV, Benutzer/Passwort/Sperre | PASS (10 Teilprüfungen) | `tests/api.test.mjs` |
| Derselbe Gesamtablauf auf **PostgreSQL** | PASS (10 Teilprüfungen) | `tests/pg.test.mjs` |
| Büro-App im Browser: 19 Seiten auf 1366 px und 390 px, kein Seiten-Überlauf, keine JS-Fehler, Auftrag mit allen 5 Reitern, Live-Kalkulation, neue Angebotsversion, Planungsdialog mit Konfliktprüfung, neue Anfrage, Mitarbeiterdetail, mobiles Menü | PASS (96 Prüfungen) | Playwright |
| Mitarbeiter-App auf 360 px und 414 px: Anmeldung, Zeiterfassung Start/Stopp, Auftrag, Sonderwunsch mit Foto, Stunden nachtragen, Urlaubsantrag, Offline-Warteschlange (offline speichern → online senden), Touch-Ziele, Service Worker | PASS (34 Prüfungen) | Playwright |
| Produktionsinstallation `npm ci --omit=dev` + Start mit `.env.example` | PASS | lokal |
| Docker-Image bauen | **NICHT GETESTET** | in der Testumgebung kein Docker-Dienst verfügbar |
| Echter IMAP-Abruf / SMTP-Versand / AgentMail | **NICHT GETESTET** | keine Zugangsdaten; Logik mit simulierten Mails getestet |
| iPhone/Android-Installation der PWA auf echten Geräten | **NICHT GETESTET** | im Browser simuliert |
| Rechtliches (DSGVO, Arbeitszeiterfassung, GoBD) | NICHT GEPRÜFT | bitte fachlich prüfen lassen |
