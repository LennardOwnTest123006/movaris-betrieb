// UI-Werkzeuge ohne Framework: Elemente bauen, API-Aufrufe, Dialoge, Meldungen, Formate.
import { euro } from "../shared/calc.js";
import { deDate, hm } from "../shared/dates.js";
import { STATUS, KINDS } from "../shared/domain.js";

export { euro, deDate, hm };

export function h(tag, attrs, ...kids) {
  const el = document.createElement(tag);
  if (attrs !== null && attrs !== undefined && (typeof attrs !== "object" || attrs instanceof Node || Array.isArray(attrs))) {
    kids.unshift(attrs);
    attrs = null;
  }
  for (const [k, v] of Object.entries(attrs || {})) {
    if (v === undefined || v === null || v === false) continue;
    if (k.startsWith("on") && typeof v === "function") el.addEventListener(k.slice(2), v);
    else if (k === "style" && typeof v === "object") for (const [sk, sv] of Object.entries(v)) sk.startsWith("--") ? el.style.setProperty(sk, sv) : (el.style[sk] = sv);
    else if (k === "class") el.className = v;
    else if (k === "html") el.innerHTML = v; // nur für eigene, statische Inhalte
    else if (k in el && k !== "list" && k !== "form" && typeof v !== "string") el[k] = v;
    else el.setAttribute(k, v === true ? "" : v);
  }
  add(el, kids);
  return el;
}
function add(el, kids) {
  for (const k of kids.flat(Infinity)) {
    if (k === null || k === undefined || k === false) continue;
    el.append(k instanceof Node ? k : document.createTextNode(String(k)));
  }
}
export const $ = (sel, root = document) => root.querySelector(sel);
export const clear = (el) => {
  while (el.firstChild) el.removeChild(el.firstChild);
  return el;
};

export class ApiError extends Error {
  constructor(status, msg, data) {
    super(msg);
    this.status = status;
    this.data = data;
  }
}
export async function api(method, path, body) {
  const r = await fetch(path, {
    method,
    headers: { "x-mv": "1", ...(body !== undefined ? { "content-type": "application/json" } : {}) },
    body: body !== undefined ? JSON.stringify(body) : undefined,
    credentials: "same-origin",
  });
  if (r.status === 401 && !path.startsWith("/api/login")) {
    window.dispatchEvent(new CustomEvent("mv:logout"));
  }
  const ct = r.headers.get("content-type") || "";
  const data = ct.includes("json") ? await r.json() : r.status === 204 ? null : await r.text();
  if (!r.ok) throw new ApiError(r.status, (data && data.error) || "Fehler " + r.status, data);
  return data;
}
export const get = (p) => api("GET", p);
export const post = (p, b = {}) => api("POST", p, b);
export const put = (p, b = {}) => api("PUT", p, b);
export const del = (p) => api("DELETE", p);

// Meldungen
export function toast(msg, kind = "ok") {
  let box = $("#toasts");
  if (!box) document.body.append((box = h("div", { id: "toasts", role: "status", "aria-live": "polite" })));
  const t = h("div", { class: `toast ${kind}` }, msg);
  box.append(t);
  setTimeout(() => t.classList.add("out"), 3800);
  setTimeout(() => t.remove(), 4300);
}
export const fail = (e) => toast(e && e.message ? e.message : String(e), "bad");

// Dialoge
export function modal(title, body, actions = [], { wide = false } = {}) {
  const dlg = h("dialog", { class: "modal" + (wide ? " wide" : "") });
  const close = () => {
    dlg.close();
    dlg.remove();
  };
  const foot = h("div", { class: "modal-foot" });
  for (const a of actions) {
    const b = h("button", { type: "button", class: "btn " + (a.kind || "") }, a.label);
    b.addEventListener("click", async () => {
      if (!a.onClick) return close();
      b.disabled = true;
      try {
        const keep = await a.onClick(close, dlg);
        if (keep !== true) close();
      } catch (e) {
        if (e instanceof ApiError && e.status === 409) {
          /* vom Aufrufer behandelt */
        }
        fail(e);
      } finally {
        b.disabled = false;
      }
    });
    foot.append(b);
  }
  dlg.append(h("div", { class: "modal-head" }, h("h2", title), h("button", { type: "button", class: "x", "aria-label": "Schließen", onclick: close }, "×")), h("div", { class: "modal-body" }, body), foot);
  dlg.addEventListener("cancel", (e) => {
    e.preventDefault();
    close();
  });
  document.body.append(dlg);
  dlg.showModal();
  return { close, dlg };
}
export function confirmBox(text, label = "OK", kind = "primary") {
  return new Promise((res) => {
    let done = false;
    const m = modal("Bitte bestätigen", h("p", text), [
      { label: "Abbrechen", onClick: () => { done = true; res(false); } },
      { label, kind, onClick: () => { done = true; res(true); } },
    ]);
    m.dlg.addEventListener("close", () => !done && res(false));
  });
}

// Formulare: Felddefinitionen -> Elemente, Werte auslesen
export function field(label, input, hint) {
  const id = input.id || "f" + Math.random().toString(36).slice(2, 9);
  input.id = id;
  return h("div", { class: "field" }, h("label", { for: id }, label), input, hint ? h("small", { class: "hint" }, hint) : null);
}
export const inp = (name, value, attrs = {}) => h("input", { name, value: value ?? "", ...attrs });
export const area = (name, value, attrs = {}) => {
  const t = h("textarea", { name, rows: 3, ...attrs });
  t.value = value ?? "";
  return t;
};
export function sel(name, value, options, attrs = {}) {
  const s = h("select", { name, ...attrs });
  for (const [v, l] of Array.isArray(options) ? options : Object.entries(options)) s.append(h("option", { value: v }, l));
  s.value = value ?? "";
  return s;
}
export const check = (name, checked, label) => {
  const i = h("input", { type: "checkbox", name });
  i.checked = Boolean(checked);
  return h("label", { class: "check" }, i, " ", label);
};
export function formData(root) {
  const out = {};
  for (const el of root.querySelectorAll("input[name],select[name],textarea[name]")) {
    if (el.type === "checkbox") out[el.name] = el.checked;
    else if (el.type === "number") out[el.name] = el.value === "" ? null : el.value;
    else out[el.name] = el.value;
  }
  return out;
}

// Anzeige-Bausteine
export const chip = (status) => {
  const s = STATUS[status] || { label: status, color: "#667085" };
  const c = h("span", { class: "chip" }, s.label);
  c.style.setProperty("--c", s.color);
  return c;
};
export const kind = (k) => KINDS[k] || k || "";
export const dt = (s) => (s ? deDate(s) + (s.length > 10 ? " " + s.slice(11, 16) : "") : "");
export const ago = (iso) => {
  if (!iso) return "";
  const d = (Date.now() - new Date(iso).getTime()) / 60000;
  if (d < 1) return "gerade eben";
  if (d < 60) return `vor ${Math.round(d)} Min.`;
  if (d < 1440) return `vor ${Math.round(d / 60)} Std.`;
  return deDate(iso.slice(0, 10));
};
export const empty = (text) => h("div", { class: "empty" }, text);
export function table(cols, rows, { onRow, rowClass } = {}) {
  const t = h("table", { class: "tbl" });
  t.append(h("thead", h("tr", cols.map((c) => h("th", { class: c.cls || "" }, c.label)))));
  const tb = h("tbody");
  for (const r of rows) {
    const tr = h("tr", { class: (onRow ? "click " : "") + (rowClass ? rowClass(r) || "" : "") });
    if (onRow) {
      tr.tabIndex = 0;
      tr.addEventListener("click", (e) => !e.target.closest("button,a,input,select") && onRow(r));
      tr.addEventListener("keydown", (e) => e.key === "Enter" && onRow(r));
    }
    for (const c of cols) tr.append(h("td", { class: c.cls || "", "data-l": c.label }, c.render ? c.render(r) : r[c.key] ?? ""));
    tb.append(tr);
  }
  t.append(tb);
  return h("div", { class: "tbl-wrap" }, rows.length ? t : empty("Keine Einträge."));
}
export const debounce = (fn, ms = 300) => {
  let t;
  return (...a) => {
    clearTimeout(t);
    t = setTimeout(() => fn(...a), ms);
  };
};
export const initials = (name) => String(name || "?").split(/\s+/).map((p) => p[0]).slice(0, 2).join("").toUpperCase();

// Bilder vor dem Hochladen verkleinern (schont Mobilfunk und Speicher)
export async function readFileForUpload(file, maxSide = 1800) {
  if (file.type === "application/pdf") {
    const buf = await file.arrayBuffer();
    return { name: file.name, mime: file.type, data: b64(buf) };
  }
  if (!file.type.startsWith("image/")) throw new Error("Nur Fotos oder PDF.");
  const url = URL.createObjectURL(file);
  try {
    const img = await new Promise((res, rej) => {
      const i = new Image();
      i.onload = () => res(i);
      i.onerror = () => rej(new Error("Bild konnte nicht gelesen werden."));
      i.src = url;
    });
    const scale = Math.min(1, maxSide / Math.max(img.naturalWidth, img.naturalHeight));
    const c = document.createElement("canvas");
    c.width = Math.round(img.naturalWidth * scale);
    c.height = Math.round(img.naturalHeight * scale);
    c.getContext("2d").drawImage(img, 0, 0, c.width, c.height);
    const blob = await new Promise((res) => c.toBlob(res, "image/jpeg", 0.82));
    return { name: file.name.replace(/\.\w+$/, "") + ".jpg", mime: "image/jpeg", data: b64(await blob.arrayBuffer()) };
  } finally {
    URL.revokeObjectURL(url);
  }
}
function b64(buf) {
  let s = "";
  const bytes = new Uint8Array(buf);
  for (let i = 0; i < bytes.length; i += 0x8000) s += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
  return btoa(s);
}
