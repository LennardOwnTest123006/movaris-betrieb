// Büro-App: Anmeldung, Navigation, Seitenwechsel (Hash-Router).
import { h, $, clear, get, post, toast, fail, inp, field } from "./lib.js";
import { dashboard } from "./views/dashboard.js";
import { inbox } from "./views/inbox.js";
import { orders, orderDetail } from "./views/orders.js";
import { planning } from "./views/planning.js";
import { customers } from "./views/customers.js";
import { employees, employeeDetail, timesPage, absencesPage, feedbackPage } from "./views/staff.js";
import { settingsPage } from "./views/settings.js";

const root = $("#app");
const app = { me: null, badges: {} };

const NAV = [
  ["#/", "Übersicht", null],
  ["#/posteingang", "Posteingang", "mail_open"],
  ["#/auftraege", "Anfragen & Aufträge", "new_orders"],
  ["#/planung", "Einsatzplanung", null],
  ["#/kunden", "Kunden", null],
  "sep",
  ["#/mitarbeiter", "Mitarbeiter", null],
  ["#/zeiten", "Stunden", "time_unapproved"],
  ["#/abwesenheiten", "Urlaub & Krank", "absences_pending"],
  ["#/rueckmeldungen", "Rückmeldungen", "feedback_open"],
  "sep",
  ["#/einstellungen", "Einstellungen", null],
];

const ROUTES = [
  [/^#?\/?$/, dashboard],
  [/^#\/posteingang$/, inbox],
  [/^#\/auftraege$/, orders],
  [/^#\/auftrag\/([\w-]+)(?:\/(\w+))?$/, orderDetail],
  [/^#\/planung$/, planning],
  [/^#\/kunden$/, customers],
  [/^#\/mitarbeiter$/, employees],
  [/^#\/mitarbeiter\/([\w-]+)$/, employeeDetail],
  [/^#\/zeiten$/, timesPage],
  [/^#\/abwesenheiten$/, absencesPage],
  [/^#\/rueckmeldungen$/, feedbackPage],
  [/^#\/einstellungen(?:\/(\w+))?$/, settingsPage],
];

function authScreen(setup) {
  clear(root);
  const msg = h("p", { class: "badbox", hidden: true });
  const form = h(
    "form",
    setup ? field("Ihr Name", inp("name", "", { required: true, autocomplete: "name" })) : null,
    field("E-Mail", inp("email", "", { type: "email", required: true, autocomplete: "username" })),
    field("Passwort", inp("password", "", { type: "password", required: true, autocomplete: setup ? "new-password" : "current-password", minlength: setup ? 10 : undefined }), setup ? "Mindestens 10 Zeichen." : null),
    msg,
    h("button", { class: "btn primary", type: "submit" }, setup ? "Einrichtung abschließen" : "Anmelden")
  );
  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    msg.hidden = true;
    const d = Object.fromEntries(new FormData(form));
    try {
      const r = await post(setup ? "/api/setup" : "/api/login", d);
      if (r.role === "mitarbeiter") return (location.href = "/m/");
      start();
    } catch (err) {
      msg.textContent = err.message;
      msg.hidden = false;
    }
  });
  root.append(
    h("div", { class: "auth" },
      h("div", { class: "card" },
        h("div", { class: "logo" }, h("img", { src: "/img/icon.svg", alt: "" }), "MOVARIS Betrieb"),
        h("p", { class: "muted" }, setup ? "Willkommen! Legen Sie den ersten Admin-Zugang an (Geschäftsführung)." : "Anmeldung für Büro und Disposition. Mitarbeiter nutzen die Mitarbeiter-App."),
        form,
        setup ? null : h("p", { class: "small muted" }, h("a", { href: "/m/" }, "Zur Mitarbeiter-App →"))
      )
    )
  );
  form.querySelector("input").focus();
}

function layout() {
  clear(root);
  const side = h("aside", { class: "side", id: "side" });
  const nav = h("nav", { class: "nav", "aria-label": "Hauptmenü" });
  for (const n of NAV) {
    if (n === "sep") { nav.append(h("div", { class: "sep" })); continue; }
    if (n[0] === "#/einstellungen" && app.me.user.role !== "admin" && app.me.user.role !== "buero") continue;
    nav.append(h("a", { href: n[0], "data-b": n[2] || "" }, h("span", n[1]), n[2] ? h("span", { class: "badge", hidden: true }) : null));
  }
  side.append(
    h("div", { class: "brand" }, h("img", { src: "/img/icon.svg", alt: "" }), h("div", app.me.company || "MOVARIS", h("small", "Betrieb & Disposition"))),
    nav,
    h("div", { class: "side-foot" },
      h("b", app.me.user.name), app.me.roles[app.me.user.role],
      h("div", { class: "row" },
        h("button", { class: "btn sm", onclick: logout }, "Abmelden"),
        app.me.user.employee_id ? h("a", { class: "btn sm", href: "/m/" }, "Mitarbeiter-App") : null)
    )
  );
  const search = h("input", { type: "search", placeholder: "Aufträge, Kunden, Orte suchen …", "aria-label": "Suche" });
  search.addEventListener("keydown", (e) => {
    if (e.key === "Enter") location.hash = "#/auftraege?q=" + encodeURIComponent(search.value);
  });
  const main = h("main", { class: "main" },
    h("div", { class: "top" },
      h("button", { class: "btn burger", "aria-label": "Menü", onclick: () => side.classList.toggle("open") }, "☰"),
      h("div", { class: "search" }, search),
      h("div", { class: "grow" }),
      h("a", { class: "btn primary", href: "#/auftraege?neu=1" }, "+ Neue Anfrage")
    ),
    h("div", { class: "content", id: "content" })
  );
  side.addEventListener("click", (e) => e.target.closest("a") && side.classList.remove("open"));
  root.append(h("div", { class: "shell" }, side, main));
}

async function refreshBadges() {
  try {
    app.badges = await get("/api/badges");
    for (const a of document.querySelectorAll(".nav a[data-b]")) {
      const k = a.getAttribute("data-b");
      const b = a.querySelector(".badge");
      if (!k || !b) continue;
      const n = app.badges[k] || 0;
      b.textContent = n > 99 ? "99+" : n;
      b.hidden = !n;
    }
  } catch {}
}
app.refreshBadges = refreshBadges;

let current = 0;
async function route() {
  const hash = location.hash.split("?")[0] || "#/";
  const key = hash.startsWith("#/auftrag/") ? "#/auftraege" : hash;
  for (const a of document.querySelectorAll(".nav a")) {
    const href = a.getAttribute("href");
    a.classList.toggle("on", href === "#/" ? key === "#/" || key === "" : key.startsWith(href));
  }
  const content = $("#content");
  if (!content) return;
  const my = ++current;
  for (const [re, view] of ROUTES) {
    const m = hash.match(re);
    if (!m) continue;
    clear(content).append(h("div", { class: "muted" }, "Lädt …"));
    try {
      const params = Object.fromEntries(new URLSearchParams(location.hash.split("?")[1] || ""));
      const el = await view({ app, params, match: m });
      if (my !== current) return;
      clear(content).append(el);
      window.scrollTo(0, 0);
    } catch (e) {
      if (my !== current) return;
      clear(content).append(h("div", { class: "badbox" }, e.message || String(e)));
    }
    return;
  }
  clear(content).append(h("div", { class: "empty" }, "Seite nicht gefunden."));
}
app.reload = route;

async function logout() {
  await post("/api/logout").catch(() => {});
  location.reload();
}

async function start() {
  try {
    app.me = await get("/api/me");
  } catch (e) {
    return void (root.textContent = "Server nicht erreichbar: " + e.message);
  }
  if (!app.me.user) {
    const s = await get("/api/setup").catch(() => ({ needed: false }));
    return authScreen(s.needed);
  }
  if (app.me.user.role === "mitarbeiter") return (location.href = "/m/");
  layout();
  route();
  refreshBadges();
  setInterval(refreshBadges, 60000);
}

window.addEventListener("hashchange", route);
window.addEventListener("mv:logout", () => { if (app.me) { app.me = null; start(); } });
window.addEventListener("mv:badges", refreshBadges);
start().catch(fail);
export { toast };
