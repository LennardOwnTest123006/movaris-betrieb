import { h, get, post, put, toast, fail, modal, field, inp, area, formData, table, chip, dt, kind, empty } from "../lib.js";

const form = (c = {}) => h("div", { class: "form" },
  field("Name *", inp("name", c.name || "", { required: true })), field("Firma", inp("company", c.company || "")),
  field("E-Mail", inp("email", c.email || "", { type: "email" })), field("Telefon", inp("phone", c.phone || "", { type: "tel" })),
  field("Straße", inp("street", c.street || "")), field("PLZ", inp("zip", c.zip || "")), field("Ort", inp("city", c.city || "")),
  h("div", { class: "full" }, field("Notizen", area("notes", c.notes || ""))));

export async function customers({ app, params }) {
  const q = params.q || "";
  const d = await get("/api/customers?limit=200" + (q ? "&q=" + encodeURIComponent(q) : ""));
  const search = inp("q", q, { type: "search", placeholder: "Name, E-Mail, Ort, Telefon …" });
  search.addEventListener("keydown", (e) => e.key === "Enter" && (location.hash = "#/kunden?q=" + encodeURIComponent(search.value)));
  const open = async (row) => {
    const c = await get(`/api/customers/${row.id}`);
    const f = form(c);
    modal(c.name, h("div", { class: "grid" }, f, h("h3", `Aufträge (${c.orders.length})`),
      c.orders.length ? table([{ label: "Nr.", key: "number" }, { label: "Art", render: (o) => kind(o.kind) }, { label: "Status", render: (o) => chip(o.status) }, { label: "Angelegt", render: (o) => dt(o.created_at) }], c.orders, { onRow: (o) => { document.querySelector("dialog")?.close(); location.hash = `#/auftrag/${o.id}`; } }) : empty("Keine Aufträge.")), [
      { label: "Schließen" },
      { label: "Speichern", kind: "primary", onClick: async () => { await put(`/api/customers/${c.id}`, formData(f)); toast("Gespeichert."); app.reload(); } },
    ], { wide: true });
  };
  return h("div",
    h("div", { class: "page-head" }, h("h1", "Kunden"), h("div", { class: "row" }, h("div", { style: { width: "280px" } }, search),
      h("button", { class: "btn primary", onclick: () => { const f = form(); modal("Neuer Kunde", f, [{ label: "Abbrechen" }, { label: "Anlegen", kind: "primary", onClick: async () => { await post("/api/customers", formData(f)); toast("Kunde angelegt."); app.reload(); } }]); } }, "+ Kunde"))),
    table([
      { label: "Name", render: (c) => h("div", h("b", c.name), c.company ? h("div", { class: "small muted" }, c.company) : null) },
      { label: "Kontakt", render: (c) => h("div", c.email || "", h("div", { class: "small muted" }, c.phone || "")) },
      { label: "Ort", render: (c) => [c.zip, c.city].filter(Boolean).join(" ") },
      { label: "Aufträge", key: "orders", cls: "r" },
      { label: "Seit", render: (c) => dt(c.created_at) },
    ], d.rows, { onRow: open }));
}
