import { h, get, post, toast, fail, euro, hm, chip, kind, dt, ago, empty } from "../lib.js";
import { STATUS } from "../../shared/domain.js";

const kpi = (value, label, href) => h("div", { class: "card kpi" + (href ? " click" : ""), onclick: href ? () => (location.hash = href) : null, role: href ? "link" : null, tabindex: href ? 0 : null }, h("b", value), h("span", label));

export async function dashboard({ app }) {
  const [d, b] = await Promise.all([get("/api/dashboard"), get("/api/badges")]);
  const st = d.by_status;
  const tasks = [
    [b.mail_open, "E-Mails ohne Zuordnung prüfen", "#/posteingang"],
    [b.new_orders, "neue Anfragen bearbeiten", "#/auftraege?status=neu"],
    [b.feedback_open, "offene Rückmeldungen aus dem Einsatz", "#/rueckmeldungen"],
    [b.absences_pending, "Urlaubsanträge entscheiden", "#/abwesenheiten"],
    [b.time_unapproved, "Stundeneinträge freigeben", "#/zeiten?unapproved=1"],
  ].filter(([n]) => n > 0);

  const mailCard = h("div", { class: "card" }, h("h2", "Postfach"));
  const ms = d.mail;
  const src = [ms.imap && `IMAP ${ms.imap.user}`, ms.agentmail && `AgentMail ${ms.agentmail.inbox}`, ms.inquiry_endpoint && "Website-Formular"].filter(Boolean);
  mailCard.append(
    src.length ? h("p", h("span", { class: "tag green" }, "verbunden"), " ", src.join(" · ")) : h("p", { class: "warnbox" }, "Noch kein Postfach verbunden. Zugangsdaten in der .env eintragen (siehe README)."),
    h("p", { class: "small muted" }, ms.last_run ? `Letzter Abruf: ${ago(ms.last_run)}` : "Noch kein Abruf.", ms.poll_minutes ? ` · automatisch alle ${ms.poll_minutes} Min.` : ""),
    h("p", { class: "small muted" }, "Versand: ", ms.send ? ms.send.toUpperCase() : h("span", { class: "tag amber" }, "nicht eingerichtet")),
    h("button", {
      class: "btn sm",
      disabled: !(ms.imap || ms.agentmail),
      onclick: async (e) => {
        e.target.disabled = true;
        try {
          const r = await post("/api/mail/fetch");
          const n = (r.imap?.created || 0) + (r.agentmail?.created || 0);
          const err = r.imap?.error || r.agentmail?.error;
          err ? fail(err) : toast(`Abruf fertig: ${n} neue Anfrage(n).`);
          app.reload();
        } catch (er) {
          fail(er);
        }
      },
    }, "Jetzt abrufen")
  );

  return h("div",
    h("div", { class: "page-head" }, h("h1", "Übersicht"), h("span", { class: "muted" }, new Date().toLocaleDateString("de-DE", { weekday: "long", day: "numeric", month: "long", year: "numeric" }))),
    h("div", { class: "grid g4" },
      kpi(String((st.neu || 0) + (st.in_bearbeitung || 0) + (st.besichtigung || 0)), "Anfragen in Bearbeitung", "#/auftraege?status=neu,in_bearbeitung,besichtigung"),
      kpi(`${d.open_offers.count} · ${euro(d.open_offers.gross)}`, "Offene Angebote (brutto)", "#/auftraege?status=angebot_versendet"),
      kpi(`${d.won.count} · ${euro(d.won.gross)}`, `Zuschläge ${d.today.slice(0, 4)} (brutto)`, "#/auftraege?status=zuschlag,geplant,in_durchfuehrung,erledigt,abgerechnet"),
      kpi(d.win_rate === null ? "–" : `${d.win_rate} %`, `Abschlussquote ${d.today.slice(0, 4)} (${d.won.count} Zuschlag / ${d.lost} Absage)`)
    ),
    h("div", { class: "grid g3", style: { marginTop: "16px" } },
      h("div", { class: "card" }, h("h2", "Zu erledigen"), tasks.length ? h("ul", { class: "plain" }, tasks.map(([n, t, href]) => h("li", h("a", { href }, h("b", n), " ", t)))) : h("p", { class: "muted" }, "Alles erledigt. 👍")),
      h("div", { class: "card" }, h("h2", "Heute abwesend"), d.absent.length ? h("ul", { class: "plain" }, d.absent.map((a) => h("li", h("b", a.name), " – ", a.kind === "krank" ? "krank" : a.kind === "urlaub" ? "Urlaub" : "abwesend", h("span", { class: "muted" }, ` bis ${dt(a.end_date)}`)))) : h("p", { class: "muted" }, "Alle an Bord."), h("p", { class: "small muted" }, `Erfasste Stunden diesen Monat: ${hm(d.month_minutes)} Std.`)),
      mailCard
    ),
    h("div", { class: "grid g2", style: { marginTop: "16px" } },
      h("div", { class: "card" }, h("h2", "Neue Anfragen", h("a", { class: "btn sm", href: "#/auftraege?status=neu" }, "Alle")),
        d.newest.length ? h("ul", { class: "list" }, d.newest.map((o) => h("li", { onclick: () => (location.hash = `#/auftrag/${o.id}`) }, h("div", h("b", o.number), " ", o.customer || "", h("div", { class: "small muted" }, kind(o.kind), " · ", o.title || "")), h("span", { class: "small muted" }, ago(o.created_at), h("br"), h("span", { class: "tag" }, o.source))))) : empty("Keine neuen Anfragen.")),
      h("div", { class: "card" }, h("h2", "Nächste Einsätze (8 Tage)", h("a", { class: "btn sm", href: "#/planung" }, "Planung")),
        d.upcoming.length ? h("ul", { class: "list" }, d.upcoming.map((o) => h("li", { onclick: () => (location.hash = `#/auftrag/${o.id}`) }, h("div", h("b", dt(o.scheduled_start)), " · ", o.number, " ", o.customer || "", h("div", { class: "small muted" }, [o.from_address, o.to_address].filter(Boolean).join(" → "), o.staff.length ? ` · Team: ${o.staff.join(", ")}` : h("span", { class: "tag red" }, " kein Team"))), chip(o.status)))) : empty("Keine Einsätze geplant."))
    ),
    h("div", { class: "card", style: { marginTop: "16px" } }, h("h2", "Auftragsstand"),
      h("div", { class: "row" }, Object.entries(STATUS).map(([k]) => h("a", { href: `#/auftraege?status=${k}`, class: "statpill" }, chip(k), h("b", " " + (st[k] || 0))))))
  );
}
