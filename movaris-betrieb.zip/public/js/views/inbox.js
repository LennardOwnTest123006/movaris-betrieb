import { h, get, post, toast, fail, table, dt, modal, empty } from "../lib.js";

const LABEL = { offen: "Zu prüfen", angelegt: "Als Anfrage angelegt", zugeordnet: "Zu Auftrag zugeordnet", ignoriert: "Ignoriert" };
const TAG = { offen: "amber", angelegt: "green", zugeordnet: "", ignoriert: "" };

export async function inbox({ app, params }) {
  const status = params.status ?? "offen";
  const d = await get(`/api/mail${status ? "?status=" + status : ""}`);
  const s = d.status;
  const tabs = h("div", { class: "tabs" }, [["offen", "Zu prüfen"], ["angelegt", "Angelegt"], ["zugeordnet", "Zugeordnet"], ["ignoriert", "Ignoriert"], ["", "Alle"]].map(([k, l]) => h("button", { class: status === k ? "on" : "", onclick: () => (location.hash = "#/posteingang?status=" + k) }, l)));

  const open = async (row) => {
    const m = await get(`/api/mail/${row.id}`);
    const actions = [{ label: "Schließen" }];
    if (m.status !== "angelegt" && m.status !== "zugeordnet") {
      actions.push({ label: "Ignorieren", onClick: async () => { await post(`/api/mail/${m.id}/ignore`); app.refreshBadges(); app.reload(); } });
      actions.push({ label: "Als Anfrage anlegen", kind: "primary", onClick: async () => { const r = await post(`/api/mail/${m.id}/create-order`); toast("Anfrage angelegt."); app.refreshBadges(); location.hash = `#/auftrag/${r.orderId}`; } });
    } else if (m.order_id) actions.push({ label: "Zum Auftrag", kind: "primary", onClick: () => (location.hash = `#/auftrag/${m.order_id}`) });
    modal(m.subject || "(ohne Betreff)", h("div", h("p", h("b", "Von: "), m.from_addr, h("br"), h("b", "Eingang: "), dt(m.received_at), " · ", m.source), h("div", { class: "mailbody" }, m.body || "(kein Text)")), actions, { wide: true });
  };

  return h("div",
    h("div", { class: "page-head" }, h("h1", "Posteingang"),
      h("div", { class: "row" },
        h("span", { class: "small muted" }, [s.imap && `IMAP: ${s.imap.user}`, s.agentmail && `AgentMail: ${s.agentmail.inbox}`].filter(Boolean).join(" · ") || "Kein Postfach verbunden"),
        h("button", { class: "btn primary", disabled: !(s.imap || s.agentmail), onclick: async (e) => {
          e.target.disabled = true;
          try {
            const r = await post("/api/mail/fetch");
            const err = r.imap?.error || r.agentmail?.error;
            err ? fail(err) : toast(`Abruf fertig: ${(r.imap?.created || 0) + (r.agentmail?.created || 0)} neue Anfrage(n).`);
            app.refreshBadges();
            app.reload();
          } catch (er) { fail(er); e.target.disabled = false; }
        } }, "Jetzt abrufen"))),
    !(s.imap || s.agentmail) ? h("div", { class: "warnbox" }, "Damit Anfragen automatisch aus dem Postfach kommen, tragen Sie IMAP-Zugangsdaten (z. B. info@movaris.de) oder AgentMail in der .env ein. Erkannte Anfragen werden direkt als Auftrag angelegt, unklare Mails landen hier zur Prüfung.") : null,
    tabs,
    d.rows.length
      ? table([
          { label: "Eingang", render: (r) => dt(r.received_at) },
          { label: "Von", key: "from_addr" },
          { label: "Betreff", key: "subject" },
          { label: "Status", render: (r) => h("span", { class: "tag " + TAG[r.status] }, LABEL[r.status] || r.status) },
          { label: "Auftrag", render: (r) => (r.order_id ? h("a", { href: `#/auftrag/${r.order_id}` }, r.order_number) : "") },
        ], d.rows, { onRow: open })
      : empty(status === "offen" ? "Keine E-Mails zu prüfen." : "Keine Einträge.")
  );
}
