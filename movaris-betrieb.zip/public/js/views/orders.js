// Anfragen & Aufträge: Tafel, Liste, Detailansicht mit Kalkulation, Planung, Einsatz und Verlauf.
import { h, get, post, put, del, toast, fail, modal, confirmBox, field, inp, area, sel, check, formData, chip, kind, dt, ago, euro, hm, table, empty, debounce, clear, readFileForUpload } from "../lib.js";
import { KINDS, STATUS, PIPELINE, FEEDBACK, OFFER_STATUS } from "../../shared/domain.js";
import { calculate, inventoryVolume } from "../../shared/calc.js";
import { openSchedule } from "./schedule.js";

// ---------------- Liste / Tafel ----------------
export async function orders({ app, params }) {
  const view = params.view || localStorage.getItem("mv-orders-view") || "tafel";
  const qs = new URLSearchParams();
  if (params.status) qs.set("status", params.status);
  if (params.kind) qs.set("kind", params.kind);
  if (params.q) qs.set("q", params.q);
  const offset = Number(params.offset || 0);
  qs.set("limit", view === "tafel" && !params.status ? 200 : 50);
  qs.set("offset", offset);
  const d = await get("/api/orders?" + qs);
  const setParam = (k, v) => {
    const p = new URLSearchParams(params);
    v ? p.set(k, v) : p.delete(k);
    p.delete("offset");
    location.hash = "#/auftraege?" + p;
  };

  const search = inp("q", params.q || "", { type: "search", placeholder: "Suche …" });
  search.addEventListener("keydown", (e) => e.key === "Enter" && setParam("q", search.value));
  const statusSel = sel("status", params.status || "", [["", "Alle Status"], ...Object.entries(STATUS).map(([k, v]) => [k, v.label])]);
  statusSel.addEventListener("change", () => setParam("status", statusSel.value));
  const kindSel = sel("kind", params.kind || "", [["", "Alle Arten"], ...Object.entries(KINDS)]);
  kindSel.addEventListener("change", () => setParam("kind", kindSel.value));
  const seg = h("div", { class: "seg", role: "group" }, ["tafel", "liste"].map((v) => h("button", { class: view === v ? "on" : "", onclick: () => { localStorage.setItem("mv-orders-view", v); setParam("view", v); } }, v === "tafel" ? "Tafel" : "Liste")));

  let body;
  if (view === "tafel") {
    body = h("div", { class: "board" },
      PIPELINE.map(([title, sts]) => {
        const items = d.rows.filter((o) => sts.includes(o.status));
        return h("section", { class: "col" }, h("h3", title, h("span", { class: "muted" }, items.length)),
          items.length ? items.map((o) => card(o)) : h("div", { class: "empty small" }, "–"));
      }));
  } else {
    body = h("div",
      table([
        { label: "Nr.", key: "number" },
        { label: "Kunde", render: (o) => h("div", h("b", o.customer || "–"), h("div", { class: "small muted" }, o.title || "")) },
        { label: "Art", render: (o) => kind(o.kind) },
        { label: "Status", render: (o) => chip(o.status) },
        { label: "Termin", render: (o) => (o.scheduled_start ? dt(o.scheduled_start) : o.desired_date ? h("span", { class: "muted" }, "Wunsch: " + dt(o.desired_date)) : "") },
        { label: "Strecke", render: (o) => [o.from_address, o.to_address].filter(Boolean).join(" → ") },
        { label: "Angebot", cls: "r", render: (o) => (o.offer_gross ? euro(o.offer_gross) : "") },
        { label: "Geändert", render: (o) => ago(o.updated_at) },
      ], d.rows, { onRow: (o) => (location.hash = `#/auftrag/${o.id}`) }),
      d.total > d.rows.length ? h("div", { class: "row", style: { marginTop: "10px" } },
        h("span", { class: "muted" }, `${offset + 1}–${offset + d.rows.length} von ${d.total}`),
        offset > 0 ? h("button", { class: "btn sm", onclick: () => setParam("offset", Math.max(0, offset - 50)) }, "← Zurück") : null,
        offset + d.rows.length < d.total ? h("button", { class: "btn sm", onclick: () => { const p = new URLSearchParams(params); p.set("offset", offset + 50); location.hash = "#/auftraege?" + p; } }, "Weiter →") : null) : null);
    body.querySelector("table")?.classList.add("stack");
  }
  if (params.neu) setTimeout(() => newOrder(app), 0);
  return h("div",
    h("div", { class: "page-head" }, h("h1", "Anfragen & Aufträge"),
      h("div", { class: "row" }, seg,
        h("a", { class: "btn", href: "/api/export/orders.csv", download: "" }, "CSV-Export"),
        h("button", { class: "btn primary", onclick: () => newOrder(app) }, "+ Neue Anfrage"))),
    h("div", { class: "row filters", style: { marginBottom: "14px" } }, h("div", { class: "grow", style: { maxWidth: "320px" } }, search), statusSel, kindSel),
    view === "tafel" && params.status ? h("p", { class: "small muted" }, "Filter aktiv – ", h("a", { href: "#/auftraege" }, "alle anzeigen")) : null,
    body
  );
}

function card(o) {
  const c = h("article", { class: "ocard", tabindex: 0, onclick: () => (location.hash = `#/auftrag/${o.id}`), onkeydown: (e) => e.key === "Enter" && (location.hash = `#/auftrag/${o.id}`) },
    h("div", { class: "row" }, h("span", { class: "t" }, o.customer || "–"), h("span", { class: "grow" }), chip(o.status)),
    h("div", { class: "small" }, o.number, " · ", kind(o.kind)),
    h("div", { class: "m" }, h("span", o.scheduled_start ? "📅 " + dt(o.scheduled_start) : o.desired_date ? "Wunsch " + dt(o.desired_date) : ago(o.created_at)), o.offer_gross ? h("b", euro(o.offer_gross)) : null));
  c.style.setProperty("--c", STATUS[o.status]?.color || "#1F7FE0");
  return c;
}

function orderForm(o = {}, c = null) {
  return h("div", { class: "form" },
    c !== null ? [
      field("Kunde / Name *", inp("customer_name", c.name || "", { required: true })),
      field("E-Mail", inp("customer_email", c.email || "", { type: "email" })),
      field("Telefon", inp("customer_phone", c.phone || "", { type: "tel" })),
    ] : null,
    field("Art", sel("kind", o.kind || "umzug", KINDS)),
    field("Titel", inp("title", o.title || "", { placeholder: "z. B. 3-Zimmer-Umzug" })),
    field("Wunschtermin", inp("desired_date", o.desired_date || "", { type: "date" })),
    field("Von (Adresse)", inp("from_address", o.from_address || "")),
    field("Etage (von)", inp("from_floor", o.from_floor ?? "", { type: "number", min: -2, max: 40 })),
    h("div", { class: "field" }, h("label", "Zugang (von)"), check("from_elevator", o.from_elevator, "Aufzug vorhanden")),
    field("Laufweg von (m)", inp("from_carry_m", o.from_carry_m ?? "", { type: "number", min: 0 })),
    field("Nach (Adresse)", inp("to_address", o.to_address || "")),
    field("Etage (nach)", inp("to_floor", o.to_floor ?? "", { type: "number", min: -2, max: 40 })),
    h("div", { class: "field" }, h("label", "Zugang (nach)"), check("to_elevator", o.to_elevator, "Aufzug vorhanden")),
    field("Laufweg nach (m)", inp("to_carry_m", o.to_carry_m ?? "", { type: "number", min: 0 })),
    field("Volumen (m³)", inp("volume_m3", o.volume_m3 ?? "", { type: "number", step: "0.1", min: 0 })),
    field("Wohnfläche (m²)", inp("area_m2", o.area_m2 ?? "", { type: "number", min: 0 })),
    field("Zimmer", inp("rooms", o.rooms ?? "", { type: "number", step: "0.5", min: 0 })),
    field("Entfernung (km)", inp("distance_km", o.distance_km ?? "", { type: "number", min: 0 })),
    h("div", { class: "full" }, field("Notizen", area("notes", o.notes || "", { rows: 4 }))),
    h("div", { class: "full" }, field("Sonderwünsche des Kunden", area("special_wishes", o.special_wishes || "", { rows: 2 })))
  );
}

function newOrder(app) {
  const f = orderForm({}, {});
  modal("Neue Anfrage anlegen", f, [
    { label: "Abbrechen" },
    { label: "Anlegen", kind: "primary", onClick: async () => {
      const d = formData(f);
      if (!d.customer_name) throw new Error("Bitte einen Kundennamen eingeben.");
      const r = await post("/api/orders", { ...d, customer: { name: d.customer_name, email: d.customer_email || null, phone: d.customer_phone || null } });
      toast(`Auftrag ${r.number} angelegt.`);
      app.refreshBadges();
      location.hash = `#/auftrag/${r.id}`;
    } },
  ], { wide: true });
}

// ---------------- Detail ----------------
let cache = { prices: null, settings: null, at: 0 };
async function calcBase() {
  if (!cache.prices || Date.now() - cache.at > 60000) {
    const [p, s] = await Promise.all([get("/api/prices"), get("/api/settings")]);
    cache = { prices: p.rows.filter((x) => x.active), settings: s, at: Date.now() };
  }
  return cache;
}

export async function orderDetail({ app, match }) {
  const id = match[1];
  const tab = match[2] || "uebersicht";
  const d = await get(`/api/orders/${id}`);
  const o = d.order;
  const go = (t) => (location.hash = `#/auftrag/${id}/${t}`);
  const reload = () => app.reload();

  const statusBtns = h("div", { class: "row" }, d.next.map((s) => h("button", {
    class: "btn sm" + (s === "zuschlag" ? " ok" : s === "absage" || s === "storniert" ? " danger" : ""),
    onclick: async () => {
      let note = null;
      if (s === "absage" || s === "storniert") {
        note = prompt(s === "absage" ? "Grund der Absage (optional):" : "Grund der Stornierung (optional):");
        if (note === null) return;
      }
      try { await post(`/api/orders/${id}/status`, { status: s, note }); toast(`Status: ${STATUS[s].label}`); app.refreshBadges(); reload(); } catch (e) { fail(e); }
    },
  }, "→ " + STATUS[s].label)));

  const tabs = [["uebersicht", "Übersicht"], ["angebot", `Kalkulation & Angebot${d.offers.length ? ` (${d.offers.length})` : ""}`], ["planung", "Planung"], ["einsatz", `Einsatz${d.feedback.filter((f) => f.status === "offen").length ? " ●" : ""}`], ["verlauf", "Verlauf"]];
  let content;
  if (tab === "angebot") content = await offerTab(d, reload);
  else if (tab === "planung") content = planTab(d, reload);
  else if (tab === "einsatz") content = einsatzTab(d, reload, app);
  else if (tab === "verlauf") content = historyTab(d, reload);
  else content = overviewTab(d, reload);

  return h("div",
    h("p", { class: "small" }, h("a", { href: "#/auftraege" }, "← Anfragen & Aufträge")),
    h("div", { class: "page-head" },
      h("div", h("h1", `${o.number} · ${d.customer?.name || "Ohne Kunde"}`), h("div", { class: "row small muted" }, chip(o.status), kind(o.kind), o.source ? h("span", { class: "tag" }, o.source) : null, `angelegt ${dt(o.created_at)}`, o.lost_reason ? h("span", { class: "tag red" }, "Grund: " + o.lost_reason) : null)),
      statusBtns),
    h("div", { class: "tabs", role: "tablist" }, tabs.map(([k, l]) => h("button", { role: "tab", "aria-selected": tab === k ? "true" : "false", class: tab === k ? "on" : "", onclick: () => go(k) }, l))),
    content
  );
}

function overviewTab(d, reload) {
  const o = d.order, c = d.customer || {};
  const f = orderForm(o);
  const cust = h("div", { class: "form" },
    field("Name", inp("name", c.name || "")), field("Firma", inp("company", c.company || "")), field("E-Mail", inp("email", c.email || "", { type: "email" })), field("Telefon", inp("phone", c.phone || "", { type: "tel" })),
    field("Straße", inp("street", c.street || "")), field("PLZ", inp("zip", c.zip || "")), field("Ort", inp("city", c.city || "")));
  return h("div", { class: "grid g2" },
    h("div", { class: "card" }, h("h2", "Auftragsdaten"), f,
      h("div", { class: "row", style: { marginTop: "12px" } }, h("button", { class: "btn primary", onclick: async () => { try { await put(`/api/orders/${o.id}`, formData(f)); toast("Gespeichert."); reload(); } catch (e) { fail(e); } } }, "Speichern"))),
    h("div", { class: "grid" },
      h("div", { class: "card" }, h("h2", "Kunde"), cust,
        h("div", { class: "row", style: { marginTop: "12px" } },
          h("button", { class: "btn", onclick: async () => { try { await put(`/api/customers/${c.id}`, formData(cust)); toast("Kunde gespeichert."); reload(); } catch (e) { fail(e); } }, disabled: !c.id }, "Kunde speichern"),
          c.phone ? h("a", { class: "btn", href: `tel:${c.phone}` }, "Anrufen") : null,
          c.email ? h("a", { class: "btn", href: `mailto:${c.email}?subject=${encodeURIComponent("Ihre Anfrage " + o.number)}` }, "E-Mail") : null)),
      h("div", { class: "card" }, h("h2", "Kurzüberblick"),
        h("p", h("b", "Termin: "), o.scheduled_start ? `${dt(o.scheduled_start)}${o.scheduled_end ? " – " + dt(o.scheduled_end) : ""}` : "noch nicht geplant", o.desired_date ? h("span", { class: "muted" }, ` (Wunsch: ${dt(o.desired_date)})`) : null),
        h("p", h("b", "Team: "), d.staff.length ? d.staff.map((s) => s.name + (s.lead ? " (Leitung)" : "")).join(", ") : "–", h("br"), h("b", "Fahrzeuge: "), d.vehicles.length ? d.vehicles.map((v) => v.name).join(", ") : "–"),
        h("p", h("b", "Letztes Angebot: "), d.offers[0] ? `${d.offers[0].number} · ${euro(d.offers[0].gross)} · ${OFFER_STATUS[d.offers[0].status]}` : "–"),
        h("p", h("b", "Erfasste Stunden: "), d.time.length ? d.time.map((t) => `${t.name} ${hm(t.minutes)}`).join(", ") : "–")),
      o.mail_text ? h("details", { class: "card" }, h("summary", h("b", "Original-Anfrage (E-Mail/Formular)")), h("div", { class: "mailbody", style: { marginTop: "8px" } }, o.mail_text)) : null)
  );
}

async function offerTab(d, reload) {
  const o = d.order;
  const { prices, settings } = await calcBase();
  const draft = d.offers.find((x) => x.status === "entwurf");
  let editing = null;
  let state;
  const base = d.offers[0] ? await get(`/api/offers/${(draft || d.offers[0]).id}`) : null;
  if (base) {
    state = structuredClone(base.input);
    if (draft) editing = draft.id;
  } else {
    state = {
      volume_m3: o.volume_m3 || null, inventory: o.inventory || [], staff: null, hours: null, trucks: 1, truck_hours: null, km: o.distance_km || null,
      floors_from: o.from_floor, elevator_from: o.from_elevator, floors_to: o.to_floor, elevator_to: o.to_elevator,
      carry_from_m: o.from_carry_m, carry_to_m: o.to_carry_m, weekend: false, extras: [], custom: [], discount_pct: null,
    };
  }
  state.extras ||= []; state.custom ||= []; state.inventory ||= [];
  let intro = base?.intro ?? settings.offer.intro;
  let terms = base?.terms ?? settings.offer.terms;
  let validUntil = base?.valid_until || "";

  const resultBox = h("div", { class: "card result" });
  const rerender = () => {
    const r = calculate(state, prices, settings.calc);
    const rows = r.positions.map((p) => h("tr", h("td", h("div", p.text), h("div", { class: "small muted" }, p.group)), h("td", { class: "r" }, `${String(p.qty).replace(".", ",")} ${p.unit}`), h("td", { class: "r" }, euro(p.price)), h("td", { class: "r" }, euro(p.total))));
    resultBox.replaceChildren(...[
      h("h2", editing ? "Angebotsentwurf" : "Ergebnis", h("span", { class: "muted small" }, r.volume ? `${String(r.volume).replace(".", ",")} m³` : "")),
      r.suggestion.manHours ? h("p", { class: "small muted" }, `Schätzung: ${String(r.suggestion.manHours).replace(".", ",")} Mann-Std. → ${r.suggestion.staff} Helfer × ${String(r.suggestion.hours).replace(".", ",")} Std.`) : null,
      r.positions.length ? h("div", { class: "tbl-wrap" }, h("table", { class: "tbl" }, h("thead", h("tr", h("th", "Position"), h("th", { class: "r" }, "Menge"), h("th", { class: "r" }, "Preis"), h("th", { class: "r" }, "Gesamt"))), h("tbody", rows))) : empty("Noch keine Positionen – links Umfang und Leistungen eintragen."),
      h("div", { style: { marginTop: "10px" } },
        h("div", { class: "sum-line" }, h("span", "Summe netto"), h("b", euro(r.totals.net))),
        r.totals.vat.map((v) => h("div", { class: "sum-line" }, h("span", `MwSt. ${v.rate} %`), h("span", euro(v.amount)))),
        h("div", { class: "sum-line big" }, h("span", "Festpreis brutto"), h("span", euro(r.totals.gross)))),
      r.hints.length ? h("div", { class: "warnbox small" }, h("ul", r.hints.map((x) => h("li", x)))) : null,
      h("div", { class: "row", style: { marginTop: "12px" } },
        editing ? h("button", { class: "btn primary", onclick: async () => { try { const x = await put(`/api/offers/${editing}`, { input: state, intro, terms, valid_until: validUntil || null }); toast("Entwurf aktualisiert."); reload(); } catch (e) { fail(e); } } }, "Entwurf speichern") : null,
        h("button", { class: "btn" + (editing ? "" : " primary"), disabled: !r.positions.length, onclick: async () => { try { const x = await post(`/api/orders/${o.id}/offers`, { input: state, intro, terms, valid_until: validUntil || null }); toast(`Angebot ${x.number} erstellt.`); reload(); } catch (e) { fail(e); } } }, editing ? "Als neue Version speichern" : "Angebot erstellen"))
    ].filter(Boolean));
  };
  const upd = (k, parse = (v) => (v === "" ? null : v)) => (e) => { state[k] = e.target.type === "checkbox" ? e.target.checked : parse(e.target.value); rerender(); };
  const numIn = (k, attrs = {}) => { const i = inp(k, state[k] ?? "", { type: "number", min: 0, step: "any", ...attrs }); i.addEventListener("input", upd(k)); return i; };
  const cb = (k, label) => { const c = check(k, state[k], label); c.querySelector("input").addEventListener("change", upd(k)); return c; };

  // Umzugsgutliste
  const invBox = h("div", { class: "inv" });
  const invTotal = h("b");
  const drawInv = () => {
    clear(invBox);
    const list = settings.inventory || [];
    const rooms = [...new Set(list.map((i) => i.room))];
    for (const room of rooms) {
      invBox.append(h("h4", room));
      for (const item of list.filter((i) => i.room === room)) {
        const cur = state.inventory.find((x) => x.name === item.name);
        const q = h("input", { type: "number", min: 0, step: 1, value: cur?.qty || "", "aria-label": item.name });
        q.addEventListener("input", () => {
          const qty = Number(q.value) || 0;
          state.inventory = state.inventory.filter((x) => x.name !== item.name);
          if (qty > 0) state.inventory.push({ name: item.name, room, m3: item.m3, qty });
          invTotal.textContent = `${String(inventoryVolume(state.inventory)).replace(".", ",")} m³`;
          if (!volIn.value) rerender();
        });
        invBox.append(h("div", { class: "it" }, h("span", item.name, h("small", { class: "muted" }, ` ${String(item.m3).replace(".", ",")} m³`)), q));
      }
    }
    invTotal.textContent = `${String(inventoryVolume(state.inventory)).replace(".", ",")} m³`;
  };
  const volIn = numIn("volume_m3", { step: "0.1" });
  drawInv();

  // Zusatzleistungen aus dem Preiskatalog
  const extrasCat = prices.filter((p) => !["personal_std", "lkw_std", "km"].includes(p.key));
  const extrasTbl = h("table", { class: "tbl" }, h("thead", h("tr", h("th", "Leistung"), h("th", "Menge"), h("th", "Preis (opt.)"))));
  const etb = h("tbody");
  for (const p of extrasCat) {
    const cur = state.extras.find((x) => x.id === p.id || (p.key && x.key === p.key));
    const q = h("input", { type: "number", min: 0, step: "any", value: cur?.qty || "", "aria-label": p.name + " Menge" });
    const pr = h("input", { type: "number", min: 0, step: "0.01", value: cur?.price ?? "", placeholder: euro(p.price), "aria-label": p.name + " Preis" });
    const sync = () => {
      state.extras = state.extras.filter((x) => x.id !== p.id && !(p.key && x.key === p.key));
      if (Number(q.value) > 0) state.extras.push({ id: p.id, key: p.key, qty: Number(q.value), price: pr.value === "" ? undefined : Number(pr.value) });
      rerender();
    };
    q.addEventListener("input", sync);
    pr.addEventListener("input", sync);
    etb.append(h("tr", h("td", p.name, h("div", { class: "small muted" }, `${p.category} · ${euro(p.price)} / ${p.unit}`)), h("td", q), h("td", pr)));
  }
  extrasTbl.append(etb);

  // Freie Positionen
  const customBox = h("div", { class: "grid" });
  const drawCustom = () => {
    clear(customBox);
    state.custom.forEach((c, i) => {
      const t = inp("t", c.text || "", { placeholder: "Bezeichnung" });
      const q = inp("q", c.qty ?? 1, { type: "number", step: "any", min: 0 });
      const u = inp("u", c.unit || "pauschal");
      const p = inp("p", c.price ?? "", { type: "number", step: "0.01" });
      for (const [el, k] of [[t, "text"], [q, "qty"], [u, "unit"], [p, "price"]]) el.addEventListener("input", () => { state.custom[i][k] = ["qty", "price"].includes(k) ? Number(el.value) : el.value; rerender(); });
      customBox.append(h("div", { class: "row" }, h("div", { class: "grow" }, t), h("div", { style: { width: "90px" } }, q), h("div", { style: { width: "110px" } }, u), h("div", { style: { width: "120px" } }, p), h("button", { class: "btn sm danger", onclick: () => { state.custom.splice(i, 1); drawCustom(); rerender(); } }, "×")));
    });
    customBox.append(h("button", { class: "btn sm", onclick: () => { state.custom.push({ text: "", qty: 1, unit: "pauschal", price: 0 }); drawCustom(); } }, "+ Freie Position"));
  };
  drawCustom();

  const introA = area("intro", intro, { rows: 3 });
  introA.addEventListener("input", () => (intro = introA.value));
  const termsA = area("terms", terms, { rows: 4 });
  termsA.addEventListener("input", () => (terms = termsA.value));
  const validIn = inp("valid_until", validUntil, { type: "date" });
  validIn.addEventListener("input", () => (validUntil = validIn.value));

  const editor = h("div", { class: "grid" },
    h("fieldset", h("legend", "Umfang"), h("div", { class: "form" }, field("Volumen (m³)", volIn, "Leer lassen = aus der Umzugsgutliste"), h("div", { class: "field" }, h("label", "Umzugsgutliste"), invTotal)),
      h("details", { style: { marginTop: "8px" } }, h("summary", "Umzugsgutliste bearbeiten"), invBox)),
    h("fieldset", h("legend", "Personal & Fahrzeuge"), h("div", { class: "form" },
      field("Umzugshelfer", numIn("staff", { step: 1 })), field("Stunden", numIn("hours", { step: "0.5" }), "Leer = Schätzung aus Volumen"),
      field("LKW", numIn("trucks", { step: 1 })), field("LKW-Stunden", numIn("truck_hours", { step: "0.5" }), "Leer = wie Personal"), field("Fahrstrecke (km)", numIn("km")))),
    h("fieldset", h("legend", "Zugang & Zuschläge"), h("div", { class: "form" },
      field("Etage Auszug", numIn("floors_from", { step: 1 })), h("div", { class: "field" }, h("label", "Auszug"), cb("elevator_from", "mit Aufzug")), field("Laufweg Auszug (m)", numIn("carry_from_m")),
      field("Etage Einzug", numIn("floors_to", { step: 1 })), h("div", { class: "field" }, h("label", "Einzug"), cb("elevator_to", "mit Aufzug")), field("Laufweg Einzug (m)", numIn("carry_to_m")),
      h("div", { class: "field" }, h("label", "Termin"), cb("weekend", "Wochenende/Feiertag")), field("Nachlass (%)", numIn("discount_pct", { step: "0.5", max: 100 })))),
    h("fieldset", { class: "extras" }, h("legend", "Zusatzleistungen & Material"), h("div", { class: "tbl-wrap" }, extrasTbl)),
    h("fieldset", h("legend", "Freie Positionen"), customBox),
    h("fieldset", h("legend", "Texte"), h("div", { class: "form" }, h("div", { class: "full" }, field("Einleitung", introA)), h("div", { class: "full" }, field("Bedingungen", termsA)), field("Gültig bis", validIn, `Standard: ${settings.calc.offer_valid_days} Tage`)))
  );
  rerender();
  return h("div", { class: "grid" },
    offersList(d, reload),
    h("div", { class: "calc" }, editor, resultBox));
}

function offersList(d, reload) {
  if (!d.offers.length) return h("div", { class: "card" }, h("h2", "Angebote"), h("p", { class: "muted" }, "Noch kein Angebot. Unten kalkulieren und „Angebot erstellen“."));
  const act = (o) => {
    const b = [h("a", { class: "btn sm", href: `/api/offers/${o.id}/print`, target: "_blank", rel: "noopener" }, "Ansehen/PDF")];
    if (o.status === "entwurf" || o.status === "versendet") {
      b.push(h("button", { class: "btn sm primary", onclick: () => sendDialog(o, d, reload) }, o.status === "entwurf" ? "Senden" : "Erneut senden"));
      if (o.status === "entwurf") b.push(h("button", { class: "btn sm", onclick: async () => { try { const r = await post(`/api/offers/${o.id}/mark-sent`); toast("Als versendet markiert."); if (r.link) navigator.clipboard?.writeText(r.link); reload(); } catch (e) { fail(e); } } }, "Als versendet markieren"));
      b.push(h("button", { class: "btn sm ok", onclick: () => decide(o, "angenommen", reload) }, "Zuschlag"));
      b.push(h("button", { class: "btn sm danger", onclick: () => decide(o, "abgelehnt", reload) }, "Absage"));
    }
    if (o.link) b.push(h("button", { class: "btn sm", onclick: () => { navigator.clipboard?.writeText(o.link); toast("Kundenlink kopiert."); } }, "Kundenlink"));
    return h("div", { class: "row" }, b);
  };
  return h("div", { class: "card" }, h("h2", "Angebote"),
    table([
      { label: "Nr.", render: (o) => h("b", o.number) },
      { label: "Status", render: (o) => h("span", { class: "tag " + (o.status === "angenommen" ? "green" : o.status === "abgelehnt" ? "red" : o.status === "versendet" ? "amber" : "") }, OFFER_STATUS[o.status] || o.status) },
      { label: "Brutto", cls: "r", render: (o) => euro(o.gross) },
      { label: "Erstellt", render: (o) => dt(o.created_at) },
      { label: "Versendet", render: (o) => (o.sent_at ? dt(o.sent_at) : "") },
      { label: "Entscheidung", render: (o) => (o.decided_at ? `${dt(o.decided_at)} · ${o.decided_by || ""}` : o.valid_until ? h("span", { class: "muted" }, "gültig bis " + dt(o.valid_until)) : "") },
      { label: "", render: act },
    ], d.offers));
}

async function sendDialog(o, d, reload) {
  const full = await get(`/api/offers/${o.id}`);
  const to = inp("to", full.customer_email || "", { type: "email", required: true });
  const msg = area("message", "Guten Tag " + (d.customer?.name || "") + ",", { rows: 3 });
  modal(`Angebot ${o.number} senden`, h("div", { class: "grid" }, field("An", to), field("Anrede / Nachricht", msg),
    h("p", { class: "small muted" }, "Das Angebot wird als formatierte E-Mail gesendet. Ist PUBLIC_URL gesetzt, enthält die Mail einen Link zur Online-Annahme.")), [
    { label: "Abbrechen" },
    { label: "Jetzt senden", kind: "primary", onClick: async () => { const r = await post(`/api/offers/${o.id}/send`, { to: to.value, message: msg.value }); toast("Angebot versendet."); reload(); } },
  ]);
}
async function decide(o, decision, reload) {
  const note = prompt(decision === "angenommen" ? "Notiz zum Zuschlag (optional):" : "Grund der Absage (optional):");
  if (note === null) return;
  try {
    await post(`/api/offers/${o.id}/decision`, { decision, note });
    toast(decision === "angenommen" ? "Zuschlag erfasst – jetzt einplanen!" : "Absage erfasst.");
    reload();
  } catch (e) { fail(e); }
}

function planTab(d, reload) {
  const o = d.order;
  return h("div", { class: "grid g2" },
    h("div", { class: "card" }, h("h2", "Einsatz"),
      h("p", h("b", "Termin: "), o.scheduled_start ? `${dt(o.scheduled_start)}${o.scheduled_end ? " bis " + dt(o.scheduled_end) : ""}` : h("span", { class: "tag amber" }, "noch nicht geplant")),
      h("p", h("b", "Team: "), d.staff.length ? d.staff.map((s) => h("span", { class: "tag", style: { marginRight: "4px" } }, s.name + (s.lead ? " ★" : ""))) : "–"),
      h("p", h("b", "Fahrzeuge: "), d.vehicles.length ? d.vehicles.map((v) => `${v.name}${v.plate ? " (" + v.plate + ")" : ""}`).join(", ") : "–"),
      h("button", { class: "btn primary", onclick: () => openSchedule(o, { staff: d.staff, vehicles: d.vehicles, onDone: reload }) }, o.scheduled_start ? "Planung ändern" : "Jetzt einplanen")),
    h("div", { class: "card" }, h("h2", "Hinweise für das Team"),
      h("p", { class: "small muted" }, "Diese Angaben sieht das Team in der Mitarbeiter-App."),
      h("p", h("b", "Adressen: "), [o.from_address, o.to_address].filter(Boolean).join(" → ") || "–"),
      h("p", h("b", "Notizen: "), h("span", { style: { whiteSpace: "pre-wrap" } }, o.notes || "–")),
      h("p", h("b", "Sonderwünsche: "), h("span", { style: { whiteSpace: "pre-wrap" } }, o.special_wishes || "–"))));
}

function einsatzTab(d, reload, app) {
  const o = d.order;
  const upload = h("input", { type: "file", accept: "image/*,application/pdf", multiple: true });
  upload.addEventListener("change", async () => {
    try {
      for (const f of upload.files) await post("/api/files", { ...(await readFileForUpload(f)), order_id: o.id });
      toast("Hochgeladen.");
      reload();
    } catch (e) { fail(e); }
  });
  const imgs = (ids) => h("div", { class: "thumbs" }, ids.map((id) => h("a", { href: `/api/files/${id}`, target: "_blank", rel: "noopener" }, h("img", { src: `/api/files/${id}`, alt: "Foto", loading: "lazy" }))));
  return h("div", { class: "grid g2" },
    h("div", { class: "card" }, h("h2", "Rückmeldungen aus dem Einsatz"),
      d.feedback.length ? h("ul", { class: "timeline" }, d.feedback.map((f) => h("li", { class: f.kind === "problem" || f.kind === "schaden" ? "warnung" : "" },
        h("div", { class: "when" }, dt(f.created_at), " · ", f.employee || "", " · ", h("span", { class: "tag " + (f.status === "offen" ? "amber" : "green") }, f.status)),
        h("b", FEEDBACK[f.kind] || f.kind), h("pre", f.text || ""), f.file_ids.length ? imgs(f.file_ids) : null,
        f.status === "offen" ? h("button", { class: "btn sm", onclick: async () => { await post(`/api/feedback/${f.id}/done`); app.refreshBadges(); reload(); } }, "Erledigt") : null))) : empty("Noch keine Rückmeldungen.")),
    h("div", { class: "grid" },
      h("div", { class: "card" }, h("h2", "Stunden auf diesem Auftrag"),
        d.time.length ? table([{ label: "Mitarbeiter", key: "name" }, { label: "Einträge", key: "entries", cls: "r" }, { label: "Stunden", cls: "r", render: (t) => hm(t.minutes) }], d.time) : empty("Noch keine Zeiten erfasst."),
        d.time.length ? h("p", { class: "small" }, h("b", "Gesamt: "), hm(d.time.reduce((s, t) => s + t.minutes, 0)), " Std.") : null),
      h("div", { class: "card" }, h("h2", "Dateien & Fotos", h("label", { class: "btn sm" }, "Hochladen", upload)),
        d.files.length ? h("ul", { class: "plain" }, d.files.map((f) => h("li", h("a", { href: `/api/files/${f.id}`, target: "_blank", rel: "noopener" }, f.name), h("span", { class: "small muted" }, ` · ${Math.round(f.size / 1024)} KB · ${dt(f.created_at)}`)))) : empty("Keine Dateien."))));
}

function historyTab(d, reload) {
  const note = area("text", "", { rows: 2, placeholder: "Notiz, Telefonat, Absprache …" });
  return h("div", { class: "card" }, h("h2", "Verlauf"),
    h("div", { class: "row", style: { marginBottom: "12px" } }, h("div", { class: "grow" }, note), h("button", { class: "btn primary", onclick: async () => { try { await post(`/api/orders/${d.order.id}/notes`, { text: note.value }); reload(); } catch (e) { fail(e); } } }, "Notiz speichern")),
    h("ul", { class: "timeline" }, d.events.map((e) => h("li", { class: e.kind }, h("div", { class: "when" }, dt(e.created_at), " · ", e.user_name), h("pre", e.text)))),
    h("div", { class: "row", style: { marginTop: "16px" } }, h("button", { class: "btn sm danger", onclick: async () => {
      if (!(await confirmBox(`Auftrag ${d.order.number} endgültig löschen? (nur Admin)`, "Löschen", "danger"))) return;
      try { await del(`/api/orders/${d.order.id}`); toast("Gelöscht."); location.hash = "#/auftraege"; } catch (e) { fail(e); }
    } }, "Auftrag löschen")));
}
