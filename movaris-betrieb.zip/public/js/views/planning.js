// Einsatzplanung: Wochenansicht (Tage) und Teamansicht (Mitarbeiter × Tage) mit Abwesenheiten.
import { h, get, chip, kind, dt, initials, empty } from "../lib.js";
import { addDays, parseDay, isoDay, holidayName, isWorkday } from "../../shared/dates.js";
import { STATUS } from "../../shared/domain.js";
import { openSchedule } from "./schedule.js";

const monday = (s) => {
  const d = parseDay(s);
  const wd = (d.getDay() + 6) % 7;
  d.setDate(d.getDate() - wd);
  return isoDay(d);
};
const DAYS = ["Mo", "Di", "Mi", "Do", "Fr", "Sa", "So"];

export async function planning({ app, params }) {
  const today = isoDay(new Date());
  const from = monday(params.w || today);
  const to = addDays(from, 6);
  const view = params.view || "tage";
  const p = await get(`/api/plan?from=${from}&to=${to}`);
  const days = [...Array(7)].map((_, i) => addDays(from, i));
  const empName = Object.fromEntries(p.employees.map((e) => [e.id, e]));
  const nav = (w, v = view) => (location.hash = `#/planung?w=${w}&view=${v}`);
  const openOrder = (o) => (location.hash = `#/auftrag/${o.id}/planung`);
  const onDay = (o, d) => o.scheduled_start.slice(0, 10) <= d && (o.scheduled_end || o.scheduled_start).slice(0, 10) >= d;

  let body;
  if (view === "team") {
    const t = h("table", { class: "team" });
    t.append(h("thead", h("tr", h("th", "Mitarbeiter"), days.map((d, i) => h("th", { class: d === today ? "today" : "" }, `${DAYS[i]} ${d.slice(8, 10)}.${d.slice(5, 7)}.`, holidayName(d) ? h("div", { class: "small muted" }, holidayName(d)) : null)))));
    const tb = h("tbody");
    for (const e of p.employees) {
      const tr = h("tr", h("td", h("span", { class: "dot", style: { "--c": e.color || "#98a2b3" } }), e.name, e.position ? h("div", { class: "small muted" }, e.position) : null));
      for (const d of days) {
        const cell = h("td");
        for (const a of p.absences.filter((a) => a.employee_id === e.id && a.start_date <= d && a.end_date >= d)) cell.append(h("div", { class: "abs " + a.kind }, a.kind === "krank" ? "krank" : a.kind === "urlaub" ? "Urlaub" : "abwesend", a.status === "beantragt" ? " (beantr.)" : ""));
        for (const o of p.orders.filter((o) => o.staff.includes(e.id) && onDay(o, d))) cell.append(h("span", { class: "cell-job", onclick: () => openOrder(o), title: o.title || "" }, (o.scheduled_start.slice(0, 10) === d ? o.scheduled_start.slice(11, 16) + " " : "") + o.number));
        if (!isWorkday(d)) cell.classList.add("muted");
        tr.append(cell);
      }
      tb.append(tr);
    }
    t.append(tb);
    body = p.employees.length ? h("div", { class: "tbl-wrap" }, t) : empty("Noch keine Mitarbeiter angelegt.");
  } else {
    body = h("div", { class: "week" }, days.map((d, i) => {
      const jobs = p.orders.filter((o) => onDay(o, d));
      const abs = p.absences.filter((a) => a.start_date <= d && a.end_date >= d);
      return h("section", { class: "day" + (d === today ? " today" : "") + (!isWorkday(d) ? " off" : "") },
        h("h3", `${DAYS[i]} ${d.slice(8, 10)}.${d.slice(5, 7)}.`, h("span", { class: "muted" }, jobs.length || "")),
        holidayName(d) ? h("div", { class: "small muted" }, holidayName(d)) : null,
        jobs.map((o) => {
          const j = h("div", { class: "job", onclick: () => openOrder(o), tabindex: 0 },
            h("b", (o.scheduled_start.slice(0, 10) === d ? o.scheduled_start.slice(11, 16) + " · " : "") + o.number),
            h("div", o.customer || ""), h("div", { class: "small muted" }, kind(o.kind), o.volume_m3 ? ` · ${o.volume_m3} m³` : ""),
            h("div", { class: "small" }, o.staff.length ? o.staff.map((id) => initials(empName[id]?.name)).join(" ") : h("span", { class: "tag red" }, "kein Team")));
          j.style.setProperty("--c", STATUS[o.status]?.color);
          return j;
        }),
        abs.map((a) => h("div", { class: "abs " + a.kind }, `${empName[a.employee_id]?.name || "?"}: ${a.kind === "krank" ? "krank" : a.kind === "urlaub" ? "Urlaub" : "abwesend"}${a.status === "beantragt" ? " (beantragt)" : ""}`)));
    }));
  }

  const unplanned = h("div", { class: "card" }, h("h2", `Noch einzuplanen (${p.unplanned.length})`),
    p.unplanned.length ? h("ul", { class: "list" }, p.unplanned.map((o) => h("li", h("div", h("b", o.number), " ", o.customer || "", h("div", { class: "small muted" }, kind(o.kind), o.desired_date ? ` · Wunsch ${dt(o.desired_date)}` : "")),
      h("div", { class: "row" }, chip(o.status), h("button", { class: "btn sm primary", onclick: () => openSchedule(o, { onDone: () => app.reload() }) }, "Einplanen"))))) : h("p", { class: "muted" }, "Alle Zuschläge sind eingeplant."));

  return h("div",
    h("div", { class: "page-head" }, h("h1", "Einsatzplanung"),
      h("div", { class: "row" },
        h("div", { class: "seg" }, [["tage", "Woche"], ["team", "Team"]].map(([v, l]) => h("button", { class: view === v ? "on" : "", onclick: () => nav(from, v) }, l))),
        h("button", { class: "btn", onclick: () => nav(addDays(from, -7)) }, "←"),
        h("button", { class: "btn", onclick: () => nav(monday(today)) }, "Heute"),
        h("button", { class: "btn", onclick: () => nav(addDays(from, 7)) }, "→"),
        h("b", `KW ${kw(from)} · ${dt(from)} – ${dt(to)}`))),
    unplanned,
    h("div", { style: { marginTop: "16px" } }, body));
}

function kw(s) {
  const d = parseDay(s);
  const t = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()));
  const dn = t.getUTCDay() || 7;
  t.setUTCDate(t.getUTCDate() + 4 - dn);
  const y = new Date(Date.UTC(t.getUTCFullYear(), 0, 1));
  return Math.ceil(((t - y) / 864e5 + 1) / 7);
}
