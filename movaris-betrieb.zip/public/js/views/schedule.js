// Dialog: Termin, Team und Fahrzeuge für einen Auftrag festlegen – mit Konfliktprüfung.
import { h, get, post, modal, toast, field, inp, debounce, ApiError } from "../lib.js";
import { addDays } from "../../shared/dates.js";

export async function openSchedule(order, { staff = [], vehicles = [], onDone } = {}) {
  const day = (order.scheduled_start || order.desired_date || new Date().toISOString().slice(0, 10)).slice(0, 10);
  const plan = await get(`/api/plan?from=${addDays(day, -1)}&to=${addDays(day, 1)}`);
  const start = inp("start", order.scheduled_start || `${day}T08:00`, { type: "datetime-local", required: true });
  const end = inp("end", order.scheduled_end || `${day}T16:00`, { type: "datetime-local" });
  const chosen = new Set(staff.map((s) => s.id || s));
  const chosenV = new Set(vehicles.map((v) => v.id || v));
  let lead = (staff.find((s) => s.lead) || {}).id || null;
  const conflictsBox = h("div");
  const empBox = h("div", { class: "pick" });
  const vehBox = h("div", { class: "pick" });
  const leadSel = h("select", { name: "lead" });

  const drawLead = () => {
    leadSel.replaceChildren(h("option", { value: "" }, "– keine –"), ...plan.employees.filter((e) => chosen.has(e.id)).map((e) => h("option", { value: e.id }, e.name)));
    leadSel.value = lead && chosen.has(lead) ? lead : "";
  };
  leadSel.addEventListener("change", () => (lead = leadSel.value || null));

  const check = debounce(async () => {
    try {
      const r = await post("/api/plan/check", { order_id: order.id, start: start.value, end: end.value, employee_ids: [...chosen], vehicle_ids: [...chosenV] });
      conflictsBox.replaceChildren(...(r.conflicts.length ? [h("div", { class: "warnbox" }, h("b", "Achtung – Konflikte:"), h("ul", r.conflicts.map((c) => h("li", c.text))))] : [h("div", { class: "okbox" }, "Keine Konflikte gefunden.")]));
      const bad = new Set(r.conflicts.filter((c) => c.employee_id).map((c) => c.employee_id));
      for (const l of empBox.querySelectorAll("label")) l.classList.toggle("badx", bad.has(l.dataset.id));
    } catch {}
  }, 250);

  for (const e of plan.employees) {
    const cb = h("input", { type: "checkbox", value: e.id });
    cb.checked = chosen.has(e.id);
    cb.addEventListener("change", () => { cb.checked ? chosen.add(e.id) : chosen.delete(e.id); drawLead(); check(); });
    const absent = plan.absences.find((a) => a.employee_id === e.id && a.start_date <= day && a.end_date >= day);
    empBox.append(h("label", { "data-id": e.id, class: absent ? "warn" : "" }, cb, h("span", { class: "dot", style: { "--c": e.color || "#98a2b3" } }), e.name, absent ? h("small", { class: "muted" }, ` (${absent.kind})`) : null));
  }
  for (const v of plan.vehicles) {
    const cb = h("input", { type: "checkbox", value: v.id });
    cb.checked = chosenV.has(v.id);
    cb.addEventListener("change", () => { cb.checked ? chosenV.add(v.id) : chosenV.delete(v.id); check(); });
    vehBox.append(h("label", cb, v.name, v.plate ? h("small", { class: "muted" }, ` ${v.plate}`) : null));
  }
  start.addEventListener("change", () => {
    if (end.value && end.value <= start.value) end.value = start.value.slice(0, 11) + "16:00";
    check();
  });
  end.addEventListener("change", check);
  drawLead();
  check();

  const save = async (force) => {
    try {
      await post(`/api/orders/${order.id}/schedule`, { start: start.value, end: end.value || null, employee_ids: [...chosen], vehicle_ids: [...chosenV], lead_id: lead, force });
      toast("Planung gespeichert.");
      onDone && onDone();
    } catch (e) {
      if (e instanceof ApiError && e.status === 409) {
        if (confirm("Es gibt Konflikte:\n\n" + e.data.conflicts.map((c) => "• " + c.text).join("\n") + "\n\nTrotzdem speichern?")) return save(true);
        return true;
      }
      throw e;
    }
  };

  modal(`Einsatz planen – ${order.number}`, h("div", { class: "grid" },
    h("div", { class: "form" }, field("Beginn", start), field("Ende", end), field("Teamleitung", leadSel)),
    h("fieldset", h("legend", `Team (${plan.employees.length} aktiv)`), plan.employees.length ? empBox : h("p", { class: "muted" }, "Noch keine Mitarbeiter angelegt.")),
    h("fieldset", h("legend", "Fahrzeuge"), plan.vehicles.length ? vehBox : h("p", { class: "muted" }, "Noch keine Fahrzeuge angelegt (Einstellungen → Fahrzeuge).")),
    conflictsBox
  ), [{ label: "Abbrechen" }, { label: "Planung speichern", kind: "primary", onClick: () => save(false) }], { wide: true });
}
