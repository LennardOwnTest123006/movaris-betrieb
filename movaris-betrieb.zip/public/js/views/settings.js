// Einstellungen: Firma & Angebotstexte, Kalkulationsfaktoren, Preise, Umzugsgutliste, Postfach, Benutzer, Fahrzeuge, Daten.
import { h, get, post, put, del, toast, fail, modal, field, inp, area, sel, check, formData, table, dt, euro, empty, clear } from "../lib.js";
import { ROLES } from "../../shared/domain.js";

const TABS = [["firma", "Firma & Angebot", true], ["kalkulation", "Kalkulation", true], ["preise", "Preise", false], ["umzugsgut", "Umzugsgutliste", true], ["postfach", "Postfach", false], ["benutzer", "Benutzer", true], ["fahrzeuge", "Fahrzeuge", false], ["daten", "Daten & Export", false]];

export async function settingsPage({ app, match }) {
  const admin = app.me.user.role === "admin";
  const tabs = TABS.filter(([, , adm]) => admin || !adm);
  const tab = tabs.find(([k]) => k === match[1]) ? match[1] : tabs[0][0];
  const s = await get("/api/settings");
  const save = async (patch) => { try { await put("/api/settings", patch); toast("Gespeichert."); app.reload(); } catch (e) { fail(e); } };
  let body;

  if (tab === "firma") {
    const c = s.company, o = s.offer;
    const f = h("div", { class: "form" },
      field("Firmenname", inp("name", c.name)), field("Straße", inp("street", c.street)), field("PLZ", inp("zip", c.zip)), field("Ort", inp("city", c.city)),
      field("Telefon", inp("phone", c.phone)), field("E-Mail", inp("email", c.email)), field("Web", inp("web", c.web)),
      h("div", { class: "full" }, field("Fußzeile im Angebot", area("footer", c.footer, { rows: 3, placeholder: "z. B. Geschäftsführung, Handelsregister, USt-IdNr., Bankverbindung" }))));
    const g = h("div", { class: "form" },
      field("Betreff der Angebots-Mail", inp("subject", o.subject), "{nummer} wird durch die Angebotsnummer ersetzt."), field("Anrede", inp("greeting", o.greeting)),
      h("div", { class: "full" }, field("Einleitungstext", area("intro", o.intro, { rows: 3 }))), h("div", { class: "full" }, field("Bedingungen", area("terms", o.terms, { rows: 5 }))));
    body = h("div", { class: "grid g2" },
      h("div", { class: "card" }, h("h2", "Firmendaten (Briefkopf)"), f),
      h("div", { class: "card" }, h("h2", "Angebotstexte"), g),
      h("div", h("button", { class: "btn primary", onclick: () => save({ company: formData(f), offer: formData(g) }) }, "Speichern")));
  } else if (tab === "kalkulation") {
    const c = s.calc;
    const n = (k, label, hint, step = "0.5") => field(label, inp(k, c[k] ?? 0, { type: "number", step, min: 0 }), hint);
    const f = h("div", { class: "form" },
      n("vat_rate", "Mehrwertsteuer (%)", null, "0.5"), n("m3_per_man_hour", "m³ je Mitarbeiterstunde", "Für die Stundenschätzung aus dem Umzugsvolumen. 0 = aus."), n("min_hours", "Mindesteinsatz (Std.)"), n("travel_hours", "An-/Abfahrt pauschal (Std.)"),
      n("floor_pct", "Etagenzuschlag je Etage ohne Aufzug (%)"), n("carry_free_m", "Laufweg ohne Zuschlag (m)", null, "1"), n("carry_pct_per_10m", "Zuschlag je weitere 10 m Laufweg (%)"), n("weekend_pct", "Wochenend-/Feiertagszuschlag (%)"), n("offer_valid_days", "Angebot gültig (Tage)", null, "1"));
    body = h("div", { class: "card" }, h("h2", "Kalkulationsfaktoren"), h("p", { class: "muted" }, "Zuschläge in % gelten auf die Personalkosten. Alle Werte legt MOVARIS selbst fest."), f,
      h("button", { class: "btn primary", style: { marginTop: "12px" }, onclick: () => save({ calc: formData(f) }) }, "Speichern"));
  } else if (tab === "preise") {
    const p = await get("/api/prices");
    const missing = p.rows.filter((r) => r.active && !(r.price > 0)).length;
    const rows = p.rows.map((r) => {
      const name = inp("name", r.name), unit = inp("unit", r.unit), price = inp("price", r.price, { type: "number", step: "0.01", min: 0 }), vat = inp("vat_rate", r.vat_rate, { type: "number", step: "0.5", min: 0 }), cat = inp("category", r.category);
      const act = check("active", r.active, "aktiv");
      for (const el of [name, unit, price, vat, cat]) el.disabled = !admin;
      act.querySelector("input").disabled = !admin;
      const tr = h("tr", { class: r.active ? "" : "dim" }, h("td", cat), h("td", name), h("td", unit), h("td", price), h("td", vat), h("td", act),
        h("td", admin ? h("div", { class: "row" },
          h("button", { class: "btn sm primary", onclick: async () => { try { await put(`/api/prices/${r.id}`, { name: name.value, unit: unit.value, price: price.value, vat_rate: vat.value, category: cat.value, active: act.querySelector("input").checked }); toast("Gespeichert."); } catch (e) { fail(e); } } }, "Speichern"),
          !r.key ? h("button", { class: "btn sm danger", onclick: async () => { await del(`/api/prices/${r.id}`); app.reload(); } }, "×") : null) : null));
      return tr;
    });
    body = h("div", { class: "card" }, h("h2", "Preiskatalog", admin ? h("button", { class: "btn sm", onclick: () => {
      const f = h("div", { class: "form" }, field("Kategorie", inp("category", "Leistungen")), field("Bezeichnung", inp("name", "")), field("Einheit", inp("unit", "Stk.")), field("Preis netto (€)", inp("price", "", { type: "number", step: "0.01" })), field("MwSt. (%)", inp("vat_rate", s.calc.vat_rate, { type: "number" })));
      modal("Neue Preisposition", f, [{ label: "Abbrechen" }, { label: "Anlegen", kind: "primary", onClick: async () => { await post("/api/prices", formData(f)); app.reload(); } }]);
    } }, "+ Position") : null),
      missing ? h("div", { class: "warnbox" }, `${missing} aktive Position(en) ohne Preis. Diese erscheinen im Angebot mit 0,00 €.`) : h("div", { class: "okbox" }, "Alle aktiven Positionen haben einen Preis."),
      h("p", { class: "small muted" }, "Alle Preise netto. Standardposten (Personal, LKW, km …) werden von der Kalkulation automatisch genutzt und lassen sich nur deaktivieren."),
      h("div", { class: "tbl-wrap" }, h("table", { class: "tbl" }, h("thead", h("tr", ["Kategorie", "Bezeichnung", "Einheit", "Preis netto €", "MwSt. %", "", ""].map((x) => h("th", x)))), h("tbody", rows))));
  } else if (tab === "umzugsgut") {
    let list = structuredClone(s.inventory || []);
    const box = h("div");
    const draw = () => {
      clear(box).append(h("div", { class: "tbl-wrap" }, h("table", { class: "tbl" }, h("thead", h("tr", h("th", "Raum"), h("th", "Gegenstand"), h("th", "m³ je Stück"), h("th", ""))),
        h("tbody", list.map((it, i) => {
          const r = inp("room", it.room), n = inp("name", it.name), m = inp("m3", it.m3, { type: "number", step: "0.05", min: 0 });
          r.addEventListener("input", () => (it.room = r.value)); n.addEventListener("input", () => (it.name = n.value)); m.addEventListener("input", () => (it.m3 = Number(m.value)));
          return h("tr", h("td", r), h("td", n), h("td", m), h("td", h("button", { class: "btn sm danger", onclick: () => { list.splice(i, 1); draw(); } }, "×")));
        })))));
    };
    draw();
    body = h("div", { class: "card" }, h("h2", "Umzugsgutliste (Richtwerte)"), h("p", { class: "muted" }, "Diese Liste erscheint in der Kalkulation. Volumen je Stück frei anpassbar."), box,
      h("div", { class: "row", style: { marginTop: "12px" } }, h("button", { class: "btn", onclick: () => { list.push({ room: "Sonstiges", name: "", m3: 0.1 }); draw(); } }, "+ Gegenstand"), h("button", { class: "btn primary", onclick: () => save({ inventory: list }) }, "Speichern")));
  } else if (tab === "postfach") {
    const m = await get("/api/mail?status=offen");
    const st = m.status;
    const mode = sel("auto_create", s.mail.auto_create, { erkannt: "Nur erkannte Anfragen automatisch anlegen (empfohlen)", alle: "Jede eingehende Mail als Anfrage anlegen", keine: "Nichts automatisch – alles zur Prüfung" });
    mode.disabled = !admin;
    const line = (label, ok, text) => h("p", h("b", label + ": "), ok ? h("span", { class: "tag green" }, "verbunden") : h("span", { class: "tag amber" }, "nicht eingerichtet"), " ", text || "");
    body = h("div", { class: "grid g2" },
      h("div", { class: "card" }, h("h2", "Verbindungen"),
        line("IMAP-Postfach", st.imap, st.imap ? `${st.imap.user} @ ${st.imap.host} (${st.imap.folder})` : "IMAP_HOST, IMAP_USER, IMAP_PASS"),
        line("AgentMail", st.agentmail, st.agentmail ? st.agentmail.inbox : "AGENTMAIL_API_KEY, AGENTMAIL_INBOX_ID"),
        line("Website-Formular", st.inquiry_endpoint, st.inquiry_endpoint ? "POST /api/public/inquiry" : "INQUIRY_KEY"),
        line("Mailversand", st.send, st.send ? `${st.send.toUpperCase()}${st.smtp ? " · " + st.smtp.from : ""}` : "SMTP_* oder AgentMail"),
        h("p", { class: "small muted" }, `Abruf alle ${st.poll_minutes} Min. · letzter Abruf: ${st.last_run ? dt(st.last_run) : "–"}`),
        st.last_result ? h("pre", { class: "mailbody" }, JSON.stringify(st.last_result, null, 2)) : null,
        h("p", { class: "small muted" }, "Zugangsdaten stehen aus Sicherheitsgründen nur in der .env-Datei auf dem Server (siehe README).")),
      h("div", { class: "card" }, h("h2", "Verarbeitung"), field("Neue E-Mails", mode),
        h("p", { class: "small muted" }, "Erkannt werden Anfragen über Stichworte wie Umzug, Angebot, Besichtigung, Lager, Container, Entrümpelung sowie das Format des Website-Formulars. Antworten mit Auftragsnummer im Betreff werden dem Auftrag zugeordnet."),
        admin ? h("button", { class: "btn primary", onclick: () => save({ mail: { auto_create: mode.value } }) }, "Speichern") : null));
  } else if (tab === "benutzer") {
    const [u, e] = await Promise.all([get("/api/users"), get("/api/employees")]);
    const dialog = (row) => {
      const f = h("div", { class: "form" },
        field("Name", inp("name", row?.name || "")), field("E-Mail", inp("email", row?.email || "", { type: "email", disabled: Boolean(row) })),
        field("Rolle", sel("role", row?.role || "buero", ROLES)), field("Mitarbeiterprofil", sel("employee_id", row?.employee_id || "", [["", "– keins –"], ...e.rows.map((x) => [x.id, x.name])])),
        field(row ? "Neues Passwort (optional)" : "Passwort", inp("password", "", { type: "text", minlength: 10 }), "Mindestens 10 Zeichen."),
        row ? h("div", { class: "field" }, h("label", "Status"), check("active", row.active, "aktiv")) : null);
      modal(row ? "Benutzer bearbeiten" : "Neuer Benutzer", f, [{ label: "Abbrechen" }, { label: "Speichern", kind: "primary", onClick: async () => {
        const v = formData(f);
        if (row) await put(`/api/users/${row.id}`, { ...v, password: v.password || undefined, employee_id: v.employee_id || null });
        else await post("/api/users", { ...v, employee_id: v.employee_id || null });
        toast("Gespeichert.");
        app.reload();
      } }]);
    };
    body = h("div", { class: "card" }, h("h2", "Benutzer & Rollen", h("button", { class: "btn sm primary", onclick: () => dialog(null) }, "+ Benutzer")),
      h("p", { class: "small muted" }, "Admin: alles inkl. Preise und Benutzer · Büro: Aufträge, Planung, Mitarbeiter, Stunden · Mitarbeiter: nur die Mitarbeiter-App."),
      table([{ label: "Name", key: "name" }, { label: "E-Mail", key: "email" }, { label: "Rolle", render: (x) => ROLES[x.role] }, { label: "Mitarbeiter", key: "employee" }, { label: "Status", render: (x) => (x.active ? h("span", { class: "tag green" }, "aktiv") : h("span", { class: "tag red" }, "gesperrt")) }, { label: "Letzte Anmeldung", render: (x) => (x.last_login ? dt(x.last_login) : "–") }], u.rows, { onRow: dialog }));
  } else if (tab === "fahrzeuge") {
    const v = await get("/api/vehicles");
    const dialog = (row) => {
      const f = h("div", { class: "form" }, field("Name", inp("name", row?.name || "", { placeholder: "z. B. Koffer-LKW 1" })), field("Kennzeichen", inp("plate", row?.plate || "")), field("Typ", inp("kind", row?.kind || "", { placeholder: "7,5 t, Sprinter …" })),
        field("Ladevolumen (m³)", inp("capacity_m3", row?.capacity_m3 ?? "", { type: "number", step: "0.5" })), h("div", { class: "field" }, h("label", "Status"), check("active", row ? row.active : true, "aktiv")), h("div", { class: "full" }, field("Notizen", area("notes", row?.notes || ""))));
      modal(row ? "Fahrzeug bearbeiten" : "Neues Fahrzeug", f, [{ label: "Abbrechen" }, { label: "Speichern", kind: "primary", onClick: async () => { row ? await put(`/api/vehicles/${row.id}`, formData(f)) : await post("/api/vehicles", formData(f)); toast("Gespeichert."); app.reload(); } }]);
    };
    body = h("div", { class: "card" }, h("h2", "Fahrzeuge", h("button", { class: "btn sm primary", onclick: () => dialog(null) }, "+ Fahrzeug")),
      table([{ label: "Name", key: "name" }, { label: "Kennzeichen", key: "plate" }, { label: "Typ", key: "kind" }, { label: "m³", key: "capacity_m3", cls: "r" }, { label: "Status", render: (x) => (x.active ? "aktiv" : "inaktiv") }], v.rows, { onRow: dialog }));
  } else {
    body = h("div", { class: "grid g2" },
      h("div", { class: "card" }, h("h2", "Exporte"), h("p", h("a", { class: "btn", href: "/api/export/orders.csv", download: "" }, "Aufträge (CSV)")), h("p", h("a", { class: "btn", href: "/api/export/time.csv", download: "" }, "Stunden aktueller Monat (CSV)")), h("p", { class: "small muted" }, "CSV mit Semikolon – öffnet direkt in Excel.")),
      h("div", { class: "card" }, h("h2", "Datensicherung"), admin ? h("p", h("a", { class: "btn primary", href: "/api/backup", download: "" }, "Sicherung herunterladen (SQLite)")) : h("p", { class: "muted" }, "Nur für Admins."),
        h("p", { class: "small muted" }, "Zusätzlich empfohlen: tägliche automatische Sicherung des Ordners data/ (siehe README). Bei Postgres: pg_dump.")));
  }

  return h("div",
    h("div", { class: "page-head" }, h("h1", "Einstellungen")),
    h("div", { class: "tabs" }, tabs.map(([k, l]) => h("button", { class: tab === k ? "on" : "", onclick: () => (location.hash = `#/einstellungen/${k}`) }, l))),
    body);
}
