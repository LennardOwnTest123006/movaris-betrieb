// Mitarbeiter, Stunden, Urlaub/Krank und Rückmeldungen.
import { h, get, post, put, del, toast, fail, modal, confirmBox, field, inp, area, sel, check, formData, table, dt, hm, empty, readFileForUpload } from "../lib.js";
import { ABSENCE, ABSENCE_STATUS, FEEDBACK, ROLES } from "../../shared/domain.js";
import { monthRange } from "../../shared/dates.js";

const TODAY = { frei: ["frei", ""], eingeplant: ["im Einsatz", "green"], urlaub: ["Urlaub", "amber"], krank: ["krank", "red"], sonstiges: ["abwesend", "amber"] };
const empForm = (e = {}, admin) => h("div", { class: "form" },
  field("Name *", inp("name", e.name || "", { required: true })), field("Position", inp("position", e.position || "", { placeholder: "z. B. Möbelpacker, Fahrer, Teamleiter" })),
  field("Telefon", inp("phone", e.phone || "", { type: "tel" })), field("E-Mail", inp("email", e.email || "", { type: "email" })),
  field("Wochenstunden (Soll)", inp("weekly_hours", e.weekly_hours ?? 40, { type: "number", step: "0.5", min: 0 })),
  field("Urlaubstage / Jahr", inp("vacation_days", e.vacation_days ?? 30, { type: "number", step: "0.5", min: 0 })),
  admin ? field("Stundenlohn (intern, €)", inp("hourly_wage", e.hourly_wage ?? "", { type: "number", step: "0.01", min: 0 })) : null,
  field("Eintritt", inp("entry_date", e.entry_date || "", { type: "date" })),
  field("Farbe im Plan", inp("color", e.color || "#1F7FE0", { type: "color" })),
  h("div", { class: "field" }, h("label", "Status"), check("active", e.active ?? true, "aktiv")),
  h("div", { class: "full" }, field("Notizen (intern)", area("notes", e.notes || ""))));

export async function employees({ app }) {
  const d = await get("/api/employees");
  const admin = app.me.user.role === "admin";
  return h("div",
    h("div", { class: "page-head" }, h("h1", "Mitarbeiter"),
      h("button", { class: "btn primary", onclick: () => { const f = empForm({}, admin); modal("Neuer Mitarbeiter", f, [{ label: "Abbrechen" }, { label: "Anlegen", kind: "primary", onClick: async () => { const r = await post("/api/employees", formData(f)); toast("Angelegt."); location.hash = `#/mitarbeiter/${r.id}`; } }], { wide: true }); } }, "+ Mitarbeiter")),
    table([
      { label: "Name", render: (e) => h("div", h("span", { class: "dot", style: { "--c": e.color || "#98a2b3" } }), h("b", e.name), h("div", { class: "small muted" }, e.position || "")) },
      { label: "Heute", render: (e) => h("span", { class: "tag " + (TODAY[e.today]?.[1] || "") }, TODAY[e.today]?.[0] || e.today) },
      { label: "Stunden Monat (Ist / Soll)", cls: "r", render: (e) => `${hm(e.month_minutes)} / ${hm(e.month_target)}` },
      { label: "Resturlaub", cls: "r", render: (e) => `${String(e.vacation_remaining).replace(".", ",")} Tage` },
      { label: "Krank (Jahr)", cls: "r", render: (e) => `${e.sick_days} Tage` },
      { label: "App-Zugang", render: (e) => (e.login ? h("span", { class: "tag green" }, e.login.email) : h("span", { class: "tag" }, "kein Zugang")) },
    ], d.rows, { onRow: (e) => (location.hash = `#/mitarbeiter/${e.id}`), rowClass: (e) => (e.active ? "" : "dim") }));
}

export async function employeeDetail({ app, match, params }) {
  const id = match[1];
  const now = new Date();
  const y = Number(params.y || now.getFullYear()), m = Number(params.m || now.getMonth() + 1);
  const d = await get(`/api/employees/${id}?year=${y}&month=${m}`);
  const e = d.employee, r = d.report;
  const admin = app.me.user.role === "admin";
  const f = empForm(e, admin);
  const monthSel = inp("month", `${y}-${String(m).padStart(2, "0")}`, { type: "month" });
  monthSel.addEventListener("change", () => { const [yy, mm] = monthSel.value.split("-"); location.hash = `#/mitarbeiter/${id}?y=${yy}&m=${Number(mm)}`; });
  const ov = r.month.overtime_min;
  const kpis = h("div", { class: "grid g4" },
    h("div", { class: "card kpi" }, h("b", hm(r.month.actual_min)), h("span", `Ist-Stunden ${String(m).padStart(2, "0")}/${y}`)),
    h("div", { class: "card kpi" }, h("b", hm(r.month.target_min)), h("span", r.month.soll_until && r.month.soll_until < r.period.to ? `Soll bis ${dt(r.month.soll_until)} (Monat: ${hm(r.month.target_full_min)})` : "Soll-Stunden (abzgl. Urlaub/Krank)")),
    h("div", { class: "card kpi" }, h("b", { style: { color: ov < 0 ? "var(--bad)" : "var(--ok)" } }, (ov > 0 ? "+" : "") + hm(ov)), h("span", "Über-/Minusstunden Monat")),
    h("div", { class: "card kpi" }, h("b", `${String(r.year.vacation_remaining).replace(".", ",")} T.`), h("span", `Resturlaub ${y} (Anspruch ${r.year.vacation_entitlement}, genommen ${String(r.year.vacation_taken).replace(".", ",")}, beantragt ${String(r.year.vacation_planned).replace(".", ",")})`)),
    h("div", { class: "card kpi" }, h("b", `${r.year.sick_days} T.`), h("span", `Krankheitstage ${y} (${r.year.sick_cases} Meldungen)`)),
    h("div", { class: "card kpi" }, h("b", hm(r.year.minutes)), h("span", `Stunden gesamt ${y}`)),
    h("div", { class: "card kpi" }, h("b", r.year.jobs), h("span", `Aufträge mit Stunden ${y}`)),
    h("div", { class: "card kpi" }, h("b", r.year.jobs ? hm(r.year.minutes / r.year.jobs) : "–"), h("span", "Ø Stunden je Auftrag")));

  const loginBox = h("div", { class: "card" }, h("h2", "Zugang zur Mitarbeiter-App"),
    d.login ? h("p", h("span", { class: "tag green" }, d.login.email), " · ", ROLES[d.login.role], d.login.active ? "" : h("span", { class: "tag red" }, " gesperrt")) : h("p", { class: "muted" }, "Noch kein Zugang."),
    admin ? h("button", { class: "btn", onclick: () => loginDialog(e, d.login, app) }, d.login ? "Zugang bearbeiten" : "Zugang anlegen") : h("p", { class: "small muted" }, "Zugänge legt die Geschäftsführung an."));

  const entries = table([
    { label: "Tag", render: (t) => dt(t.day) },
    { label: "Zeit", render: (t) => `${t.start_time}–${t.end_time || "läuft"}` },
    { label: "Pause", cls: "r", render: (t) => `${t.break_min} Min.` },
    { label: "Stunden", cls: "r", render: (t) => hm(t.minutes) },
    { label: "Auftrag", render: (t) => (t.order_id ? h("a", { href: `#/auftrag/${t.order_id}` }, t.order_number) : "–") },
    { label: "Notiz", key: "note" },
    { label: "", render: (t) => h("div", { class: "row" }, !t.approved && t.end_time ? h("button", { class: "btn sm ok", onclick: async () => { await post(`/api/time/${t.id}/approve`); app.refreshBadges(); app.reload(); } }, "Freigeben") : t.approved ? h("span", { class: "tag green" }, "frei") : null, h("button", { class: "btn sm", onclick: () => timeDialog(app, { ...t, employee_id: id }) }, "Bearbeiten")) },
  ], r.month.entries);

  return h("div",
    h("p", { class: "small" }, h("a", { href: "#/mitarbeiter" }, "← Mitarbeiter")),
    h("div", { class: "page-head" }, h("h1", e.name), h("div", { class: "row" }, monthSel,
      h("button", { class: "btn", onclick: () => timeDialog(app, { employee_id: id }) }, "+ Stunden"),
      h("button", { class: "btn", onclick: () => absenceDialog(app, id) }, "+ Urlaub/Krank"),
      h("a", { class: "btn", href: `/api/export/time.csv?from=${monthRange(y, m)[0]}&to=${monthRange(y, m)[1]}`, download: "" }, "CSV"))),
    kpis,
    h("div", { class: "grid g2", style: { marginTop: "16px" } },
      h("div", { class: "card" }, h("h2", "Stunden je Auftrag"), r.month.by_order.length ? table([{ label: "Auftrag", render: (b) => (b.order_id ? h("a", { href: `#/auftrag/${b.order_id}` }, `${b.number} ${b.title}`) : b.title) }, { label: "Stunden", cls: "r", render: (b) => hm(b.minutes) }], r.month.by_order) : empty("Keine Stunden in diesem Monat.")),
      h("div", { class: "card" }, h("h2", `Abwesenheiten ${y}`), r.absences.length ? table([{ label: "Art", render: (a) => ABSENCE[a.kind] }, { label: "Zeitraum", render: (a) => `${dt(a.start_date)} – ${dt(a.end_date)}` }, { label: "Tage", cls: "r", render: (a) => String(a.days).replace(".", ",") }, { label: "Status", render: (a) => ABSENCE_STATUS[a.status] }], r.absences) : empty("Keine."))),
    h("div", { class: "card", style: { marginTop: "16px" } }, h("h2", `Zeiteinträge ${String(m).padStart(2, "0")}/${y}`, r.month.unapproved ? h("span", { class: "tag amber" }, `${r.month.unapproved} offen`) : null), entries),
    h("div", { class: "grid g2", style: { marginTop: "16px" } },
      h("div", { class: "card" }, h("h2", "Stammdaten"), f, h("button", { class: "btn primary", style: { marginTop: "12px" }, onclick: async () => { try { await put(`/api/employees/${id}`, formData(f)); toast("Gespeichert."); app.reload(); } catch (er) { fail(er); } } }, "Speichern")),
      loginBox));
}

function loginDialog(emp, login, app) {
  const f = h("div", { class: "form" },
    field("E-Mail (Benutzername)", inp("email", login?.email || emp.email || "", { type: "email", disabled: Boolean(login) })),
    field(login ? "Neues Passwort (optional)" : "Passwort", inp("password", "", { type: "text", minlength: 10, autocomplete: "new-password" }), "Mindestens 10 Zeichen – dem Mitarbeiter persönlich mitteilen."),
    field("Rolle", sel("role", login?.role || "mitarbeiter", ROLES)),
    login ? h("div", { class: "field" }, h("label", "Status"), check("active", login.active, "aktiv")) : null);
  modal(login ? "Zugang bearbeiten" : "Zugang anlegen", f, [{ label: "Abbrechen" }, { label: "Speichern", kind: "primary", onClick: async () => {
    const v = formData(f);
    if (login) await put(`/api/users/${login.id}`, { role: v.role, active: v.active, password: v.password || undefined, employee_id: emp.id });
    else await post("/api/users", { email: v.email, name: emp.name, role: v.role, password: v.password, employee_id: emp.id });
    toast("Zugang gespeichert.");
    app.reload();
  } }]);
}

async function timeDialog(app, t) {
  const jobs = (await get(`/api/orders?status=zuschlag,geplant,in_durchfuehrung,erledigt&limit=100`)).rows;
  const f = h("div", { class: "form" },
    field("Tag", inp("day", t.day || new Date().toISOString().slice(0, 10), { type: "date", required: true })),
    field("Beginn", inp("start_time", t.start_time || "08:00", { type: "time", required: true })),
    field("Ende", inp("end_time", t.end_time || "16:30", { type: "time" })),
    field("Pause (Min.)", inp("break_min", t.break_min ?? 30, { type: "number", min: 0 })),
    field("Auftrag", sel("order_id", t.order_id || "", [["", "– ohne Auftrag –"], ...jobs.map((o) => [o.id, `${o.number} ${o.customer || ""}`])])),
    h("div", { class: "full" }, field("Notiz", inp("note", t.note || ""))));
  const acts = [{ label: "Abbrechen" }];
  if (t.id) acts.push({ label: "Löschen", kind: "danger", onClick: async () => { await del(`/api/time/${t.id}`); toast("Gelöscht."); app.reload(); } });
  acts.push({ label: "Speichern", kind: "primary", onClick: async () => {
    const v = { ...formData(f), employee_id: t.employee_id };
    const r = t.id ? await put(`/api/time/${t.id}`, v) : await post("/api/time", v);
    if (r.warn) toast(r.warn, "bad");
    else toast("Gespeichert.");
    app.reload();
  } });
  modal(t.id ? "Zeiteintrag bearbeiten" : "Stunden erfassen", f, acts);
}

export async function absenceDialog(app, employeeId) {
  const emps = employeeId ? null : (await get("/api/employees")).rows.filter((e) => e.active);
  const file = h("input", { type: "file", accept: "image/*,application/pdf" });
  const f = h("div", { class: "form" },
    emps ? field("Mitarbeiter", sel("employee_id", "", emps.map((e) => [e.id, e.name]))) : null,
    field("Art", sel("kind", "urlaub", ABSENCE)),
    field("Von", inp("start_date", new Date().toISOString().slice(0, 10), { type: "date", required: true })),
    field("Bis", inp("end_date", new Date().toISOString().slice(0, 10), { type: "date", required: true })),
    h("div", { class: "field" }, h("label", "Umfang"), check("half_day", false, "halber Tag")),
    field("Nachweis (AU, optional)", file),
    h("div", { class: "full" }, field("Notiz", inp("note", ""))));
  modal("Abwesenheit eintragen", f, [{ label: "Abbrechen" }, { label: "Speichern", kind: "primary", onClick: async () => {
    const v = formData(f);
    if (employeeId) v.employee_id = employeeId;
    if (file.files[0]) v.file = await readFileForUpload(file.files[0]);
    const r = await post("/api/absences", v);
    toast(`Eingetragen (${String(r.days).replace(".", ",")} Arbeitstage).`);
    if (r.conflicts.length) toast("Achtung, eingeplant bei: " + r.conflicts.join(", "), "bad");
    app.reload();
  } }]);
}

export async function timesPage({ app, params }) {
  const now = new Date();
  const from = params.from || `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-01`;
  const to = params.to || now.toISOString().slice(0, 10);
  const unapproved = params.unapproved === "1";
  const emps = (await get("/api/employees")).rows;
  const qs = new URLSearchParams({ from, to });
  if (params.employee) qs.set("employee", params.employee);
  if (unapproved) qs.set("unapproved", "1");
  const d = await get("/api/time?" + qs);
  const fFrom = inp("from", from, { type: "date" }), fTo = inp("to", to, { type: "date" });
  const fEmp = sel("employee", params.employee || "", [["", "Alle Mitarbeiter"], ...emps.map((e) => [e.id, e.name])]);
  const fUn = check("unapproved", unapproved, "nur offene");
  const apply = () => { const p = new URLSearchParams({ from: fFrom.value, to: fTo.value }); if (fEmp.value) p.set("employee", fEmp.value); if (fUn.querySelector("input").checked) p.set("unapproved", "1"); location.hash = "#/zeiten?" + p; };
  for (const el of [fFrom, fTo, fEmp, fUn.querySelector("input")]) el.addEventListener("change", apply);
  const total = d.rows.reduce((s, t) => s + (t.minutes || 0), 0);
  const open = d.rows.filter((t) => !t.approved && t.end_time);
  return h("div",
    h("div", { class: "page-head" }, h("h1", "Stunden"),
      h("div", { class: "row" },
        open.length ? h("button", { class: "btn ok", onclick: async () => { if (!(await confirmBox(`${open.length} Einträge freigeben?`, "Freigeben", "ok"))) return; await post("/api/time/approve-all", { ids: open.map((t) => t.id) }); toast("Freigegeben."); app.refreshBadges(); app.reload(); } }, `Alle ${open.length} freigeben`) : null,
        h("a", { class: "btn", href: `/api/export/time.csv?from=${from}&to=${to}`, download: "" }, "CSV für Lohnbuchhaltung"),
        h("button", { class: "btn primary", onclick: () => timeDialog(app, { employee_id: params.employee || emps[0]?.id }) }, "+ Stunden"))),
    h("div", { class: "row", style: { marginBottom: "12px" } }, field("Von", fFrom), field("Bis", fTo), field("Mitarbeiter", fEmp), fUn, h("b", `Summe: ${hm(total)} Std.`)),
    table([
      { label: "Tag", render: (t) => dt(t.day) },
      { label: "Mitarbeiter", key: "employee" },
      { label: "Zeit", render: (t) => `${t.start_time}–${t.end_time || "läuft"}` },
      { label: "Pause", cls: "r", render: (t) => `${t.break_min}′` },
      { label: "Std.", cls: "r", render: (t) => hm(t.minutes) },
      { label: "Auftrag", render: (t) => (t.order_id ? h("a", { href: `#/auftrag/${t.order_id}` }, t.order_number) : "–") },
      { label: "Quelle", render: (t) => h("span", { class: "tag" }, t.source === "app" ? "App" : "Büro") },
      { label: "", render: (t) => h("div", { class: "row" }, !t.approved && t.end_time ? h("button", { class: "btn sm ok", onclick: async () => { await post(`/api/time/${t.id}/approve`); app.refreshBadges(); app.reload(); } }, "Freigeben") : t.approved ? h("span", { class: "tag green" }, "frei") : h("span", { class: "tag amber" }, "läuft"), h("button", { class: "btn sm", onclick: () => timeDialog(app, t) }, "…")) },
    ], d.rows));
}

export async function absencesPage({ app, params }) {
  const year = Number(params.y || new Date().getFullYear());
  const [pending, all, emps] = await Promise.all([get("/api/absences?status=beantragt"), get(`/api/absences?year=${year}`), get("/api/employees")]);
  const decide = (a, status) => async () => { await post(`/api/absences/${a.id}/decide`, { status }); toast(status === "genehmigt" ? "Genehmigt." : "Abgelehnt."); app.refreshBadges(); app.reload(); };
  return h("div",
    h("div", { class: "page-head" }, h("h1", "Urlaub & Krankmeldungen"), h("div", { class: "row" },
      h("button", { class: "btn", onclick: () => (location.hash = `#/abwesenheiten?y=${year - 1}`) }, "←"), h("b", year), h("button", { class: "btn", onclick: () => (location.hash = `#/abwesenheiten?y=${year + 1}`) }, "→"),
      h("button", { class: "btn primary", onclick: () => absenceDialog(app) }, "+ Eintragen"))),
    h("div", { class: "card" }, h("h2", `Offene Anträge (${pending.rows.length})`),
      pending.rows.length ? table([
        { label: "Mitarbeiter", key: "employee" }, { label: "Art", render: (a) => ABSENCE[a.kind] }, { label: "Zeitraum", render: (a) => `${dt(a.start_date)} – ${dt(a.end_date)}` },
        { label: "Arbeitstage", cls: "r", render: (a) => String(a.days).replace(".", ",") }, { label: "Notiz", key: "note" },
        { label: "", render: (a) => h("div", { class: "row" }, h("button", { class: "btn sm ok", onclick: decide(a, "genehmigt") }, "Genehmigen"), h("button", { class: "btn sm danger", onclick: decide(a, "abgelehnt") }, "Ablehnen")) },
      ], pending.rows) : h("p", { class: "muted" }, "Keine offenen Anträge.")),
    h("div", { class: "card", style: { marginTop: "16px" } }, h("h2", "Urlaubskonten " + year),
      table([{ label: "Mitarbeiter", key: "name" }, { label: "Resturlaub", cls: "r", render: (e) => `${String(e.vacation_remaining).replace(".", ",")} Tage` }, { label: "Krank (Jahr)", cls: "r", render: (e) => `${e.sick_days} Tage` }], emps.rows.filter((e) => e.active), { onRow: (e) => (location.hash = `#/mitarbeiter/${e.id}`) })),
    h("div", { class: "card", style: { marginTop: "16px" } }, h("h2", "Alle Einträge " + year),
      table([
        { label: "Mitarbeiter", key: "employee" }, { label: "Art", render: (a) => h("span", { class: "tag " + (a.kind === "krank" ? "red" : "amber") }, ABSENCE[a.kind]) },
        { label: "Zeitraum", render: (a) => `${dt(a.start_date)} – ${dt(a.end_date)}` }, { label: "Tage", cls: "r", render: (a) => String(a.days).replace(".", ",") },
        { label: "Status", render: (a) => ABSENCE_STATUS[a.status] }, { label: "Nachweis", render: (a) => (a.file_id ? h("a", { href: `/api/files/${a.file_id}`, target: "_blank", rel: "noopener" }, "ansehen") : "") },
        { label: "", render: (a) => h("button", { class: "btn sm danger", onclick: async () => { if (await confirmBox("Eintrag löschen?", "Löschen", "danger")) { await del(`/api/absences/${a.id}`); app.reload(); } } }, "Löschen") },
      ], all.rows)));
}

export async function feedbackPage({ app, params }) {
  const st = params.status || "offen";
  const d = await get(`/api/feedback?status=${st}`);
  return h("div",
    h("div", { class: "page-head" }, h("h1", "Rückmeldungen aus dem Einsatz"),
      h("div", { class: "seg" }, [["offen", "Offen"], ["erledigt", "Erledigt"], ["alle", "Alle"]].map(([k, l]) => h("button", { class: st === k ? "on" : "", onclick: () => (location.hash = "#/rueckmeldungen?status=" + k) }, l)))),
    d.rows.length ? h("div", { class: "grid g2" }, d.rows.map((f) => h("div", { class: "card" },
      h("div", { class: "row" }, h("span", { class: "tag " + (f.kind === "problem" || f.kind === "schaden" ? "red" : f.kind === "sonderwunsch" ? "amber" : "") }, FEEDBACK[f.kind] || f.kind), h("span", { class: "grow" }), h("span", { class: "small muted" }, dt(f.created_at))),
      h("p", h("b", f.employee || ""), " · ", f.order_id ? h("a", { href: `#/auftrag/${f.order_id}/einsatz` }, `${f.order_number} ${f.order_title || ""}`) : ""),
      h("p", { style: { whiteSpace: "pre-wrap" } }, f.text || ""),
      f.file_ids.length ? h("div", { class: "thumbs" }, f.file_ids.map((id) => h("a", { href: `/api/files/${id}`, target: "_blank", rel: "noopener" }, h("img", { src: `/api/files/${id}`, alt: "Foto", loading: "lazy" })))) : null,
      f.status === "offen" ? h("button", { class: "btn sm ok", onclick: async () => { await post(`/api/feedback/${f.id}/done`); app.refreshBadges(); app.reload(); } }, "Als erledigt markieren") : h("p", { class: "small muted" }, `Erledigt ${dt(f.done_at)} · ${f.done_by || ""}`)))) : empty("Keine Rückmeldungen."));
}
