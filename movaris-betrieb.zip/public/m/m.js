// Mitarbeiter-App (PWA): Heute, Aufträge, Rückmeldungen mit Fotos, Stunden, Urlaub/Krank, Profil.
import { h, $, clear, api, get, post, del, toast, fail, field, inp, area, sel, check, dt, hm, empty, readFileForUpload, ApiError } from "../js/lib.js";
import { FEEDBACK, ABSENCE, ABSENCE_STATUS, KINDS } from "../shared/domain.js";

const root = $("#app");
let me = null;

// ---------- Offline-Warteschlange für Rückmeldungen, Stunden und Anträge ----------
const OUT = "mv-outbox";
const outbox = () => { try { return JSON.parse(localStorage.getItem(OUT) || "[]"); } catch { return []; } };
const saveOut = (q) => { try { localStorage.setItem(OUT, JSON.stringify(q)); } catch { toast("Speicher voll – bitte Fotos verkleinern.", "bad"); } };
async function send(path, body, label) {
  try {
    return await post(path, body);
  } catch (e) {
    if (e instanceof ApiError) throw e; // Server hat geantwortet → echter Fehler
    saveOut([...outbox(), { path, body, label, at: new Date().toISOString() }]);
    toast("Keine Verbindung – wird automatisch gesendet, sobald Netz da ist.");
    return { queued: true };
  }
}
async function flush() {
  const q = outbox();
  if (!q.length || !navigator.onLine) return;
  const rest = [];
  for (const item of q) {
    try { await post(item.path, item.body); } catch (e) { if (!(e instanceof ApiError)) rest.push(item); else toast(`${item.label}: ${e.message}`, "bad"); }
  }
  saveOut(rest);
  if (rest.length < q.length) toast(`${q.length - rest.length} gespeicherte Meldung(en) gesendet.`);
  render();
}
window.addEventListener("online", flush);

// ---------- Rahmen ----------
const ICON = {
  heute: "M12 3v2M12 19v2M4.2 4.2l1.4 1.4M18.4 18.4l1.4 1.4M3 12h2M19 12h2M4.2 19.8l1.4-1.4M18.4 5.6l1.4-1.4M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8z",
  auftraege: "M4 7h16v12H4zM9 7V5h6v2M4 12h16",
  stunden: "M12 7v5l3 2M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18z",
  frei: "M4 8h16v12H4zM8 4v4M16 4v4M4 12h16",
  profil: "M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM4 21a8 8 0 0 1 16 0",
};
const icon = (k) => { const s = document.createElementNS("http://www.w3.org/2000/svg", "svg"); s.setAttribute("viewBox", "0 0 24 24"); s.setAttribute("fill", "none"); s.setAttribute("stroke", "currentColor"); s.setAttribute("stroke-width", "2"); s.setAttribute("stroke-linecap", "round"); const p = document.createElementNS("http://www.w3.org/2000/svg", "path"); p.setAttribute("d", ICON[k]); s.append(p); return s; };
const TABS = [["#heute", "Heute", "heute"], ["#auftraege", "Aufträge", "auftraege"], ["#stunden", "Stunden", "stunden"], ["#frei", "Urlaub/Krank", "frei"], ["#profil", "Profil", "profil"]];

function frame(title, content) {
  const hash = location.hash.split("/")[0] || "#heute";
  const q = outbox();
  clear(root).append(
    h("header", { class: "m-top" }, h("img", { src: "/img/icon.svg", alt: "" }), h("h1", title), navigator.onLine ? null : h("span", { class: "net" }, "offline")),
    h("main", { class: "m-main" }, q.length ? h("div", { class: "outbox" }, `${q.length} Meldung(en) warten auf Netz. `, h("button", { class: "btn sm", onclick: flush }, "Jetzt senden")) : null, content),
    h("nav", { class: "m-tabs", "aria-label": "Navigation" }, TABS.map(([href, label, ic]) => h("a", { href, class: hash === href ? "on" : "", "aria-current": hash === href ? "page" : null }, icon(ic), label)))
  );
  window.scrollTo(0, 0);
}

function loginScreen() {
  const msg = h("p", { class: "badbox", hidden: true });
  const f = h("form", { class: "grid" },
    field("E-Mail", inp("email", "", { type: "email", required: true, autocomplete: "username" })),
    field("Passwort", inp("password", "", { type: "password", required: true, autocomplete: "current-password" })),
    msg, h("button", { class: "btn primary block", type: "submit" }, "Anmelden"));
  f.addEventListener("submit", async (e) => {
    e.preventDefault();
    try { await post("/api/login", Object.fromEntries(new FormData(f))); start(); } catch (err) { msg.textContent = err.message; msg.hidden = false; }
  });
  clear(root).append(h("div", { class: "auth" }, h("div", { class: "card" }, h("div", { class: "logo" }, h("img", { src: "/img/icon.svg", alt: "" }), "MOVARIS Team"), h("p", { class: "muted" }, "Anmeldung für Mitarbeiter. Zugangsdaten bekommst du vom Büro."), f)));
}

const mapLink = (addr) => (addr ? h("a", { href: `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(addr)}`, target: "_blank", rel: "noopener" }, addr) : "–");
const jobCard = (j) => h("a", { class: "jobc", href: `#auftrag/${j.id}` },
  h("div", { class: "when" }, dt(j.scheduled_start), j.scheduled_end ? ` – ${j.scheduled_end.slice(11, 16)}` : ""),
  h("div", h("b", j.customer || "Kunde"), " · ", KINDS[j.kind] || j.kind, " · ", j.number),
  h("div", { class: "addr" }, [j.from_address, j.to_address].filter(Boolean).join(" → ")));

// ---------- Heute ----------
let timerInt = null;
async function pageToday() {
  const o = await get("/api/my/overview");
  const today = o.now.day;
  const todays = o.jobs.filter((j) => j.scheduled_start.slice(0, 10) <= today && (j.scheduled_end || j.scheduled_start).slice(0, 10) >= today);
  const later = o.jobs.filter((j) => !todays.includes(j));
  const run = o.open_entry;
  const timer = h("div", { class: "timer" }, "0:00");
  if (timerInt) clearInterval(timerInt);
  if (run) {
    const tick = () => {
      const [hh, mm] = run.start_time.split(":").map(Number);
      const n = new Date();
      let m = n.getHours() * 60 + n.getMinutes() - (hh * 60 + mm);
      if (m < 0) m += 1440;
      timer.textContent = hm(m);
    };
    tick();
    timerInt = setInterval(tick, 20000);
  }
  const jobSel = sel("order_id", todays[0]?.id || "", [["", "– ohne Auftrag (Lager, Werkstatt …) –"], ...o.jobs.map((j) => [j.id, `${j.number} · ${j.customer || ""} (${dt(j.scheduled_start).slice(0, 10)})`])]);
  const brk = inp("break_min", "", { type: "number", min: 0, placeholder: "automatisch nach ArbZG", inputmode: "numeric" });
  const clock = h("div", { class: "m-card clock" + (run ? " run" : "") },
    h("h2", run ? "Zeiterfassung läuft" : "Arbeitszeit"),
    run ? [timer, h("p", { class: "muted" }, `seit ${run.start_time} Uhr${run.order_number ? " · Auftrag " + run.order_number : ""}`), field("Pause (Minuten)", brk),
      h("button", { class: "btn danger block", onclick: async (e) => { e.target.disabled = true; try { const r = await post("/api/my/clock", { action: "stop", break_min: brk.value === "" ? null : brk.value }); toast(`Gestoppt: ${hm(r.minutes)} Std. (Pause ${r.break_min} Min.)`); render(); } catch (er) { fail(er); e.target.disabled = false; } } }, "Feierabend / Stopp")]
      : [field("Auftrag", jobSel), h("button", { class: "btn ok block", onclick: async (e) => { e.target.disabled = true; try { await post("/api/my/clock", { action: "start", order_id: jobSel.value || null }); toast("Zeiterfassung gestartet."); render(); } catch (er) { fail(er); e.target.disabled = false; } } }, "▶ Arbeitsbeginn")]
  );
  frame(`Hallo ${o.employee.name.split(" ")[0]}`, h("div",
    installHint(),
    clock,
    h("div", { class: "m-card" }, h("h2", "Diesen Monat"), h("div", { class: "stat3" },
      h("div", h("b", hm(o.month.actual_min)), h("span", "Ist")), h("div", h("b", hm(o.month.target_min)), h("span", "Soll")), h("div", h("b", (o.month.overtime_min > 0 ? "+" : "") + hm(o.month.overtime_min)), h("span", "Saldo")))),
    h("h2", `Heute (${todays.length})`), todays.length ? todays.map(jobCard) : h("p", { class: "muted" }, "Heute ist kein Auftrag für dich eingeplant."),
    h("h2", "Demnächst"), later.length ? later.map(jobCard) : h("p", { class: "muted" }, "Keine weiteren Einsätze in den nächsten 14 Tagen."),
    o.absences.length ? h("div", { class: "m-card" }, h("h2", "Deine Abwesenheiten"), o.absences.map((a) => h("div", { class: "entry" }, h("span", ABSENCE[a.kind]), h("span", `${dt(a.start_date)} – ${dt(a.end_date)} · ${ABSENCE_STATUS[a.status]}`)))) : null));
}

let deferredPrompt = null;
window.addEventListener("beforeinstallprompt", (e) => { e.preventDefault(); deferredPrompt = e; });
function installHint() {
  if (window.matchMedia("(display-mode: standalone)").matches || localStorage.getItem("mv-install-hide")) return null;
  const ios = /iphone|ipad/i.test(navigator.userAgent);
  return h("div", { class: "install" }, h("b", "Tipp: "), ios ? "In Safari auf „Teilen“ → „Zum Home-Bildschirm“ tippen – dann startet die App wie eine normale App." : "Die App lässt sich auf dem Startbildschirm installieren.",
    " ", deferredPrompt ? h("button", { class: "btn sm primary", onclick: async () => { deferredPrompt.prompt(); deferredPrompt = null; } }, "Installieren") : null,
    " ", h("button", { class: "btn sm", onclick: (e) => { localStorage.setItem("mv-install-hide", "1"); e.target.closest(".install").remove(); } }, "Ausblenden"));
}

// ---------- Aufträge ----------
async function pageJobs() {
  const [up, past] = await Promise.all([get("/api/my/jobs"), get("/api/my/jobs?scope=past")]);
  frame("Meine Aufträge", h("div", h("h2", "Anstehend"), up.rows.length ? up.rows.map(jobCard) : empty("Keine anstehenden Aufträge."), h("h2", "Erledigt / vergangen"), past.rows.length ? past.rows.slice(0, 20).map(jobCard) : empty("Noch keine.")));
}

async function pageJob(id) {
  const j = await get(`/api/my/jobs/${id}`);
  const fb = (kind) => feedbackDialog(j, kind);
  frame(`Auftrag ${j.number}`, h("div",
    h("p", h("a", { href: "#auftraege" }, "← Aufträge")),
    h("div", { class: "m-card" }, h("h2", j.customer || "Kunde", h("span", { class: "tag" }, KINDS[j.kind] || j.kind)),
      h("div", { class: "facts" },
        h("div", h("b", "Termin"), h("span", dt(j.scheduled_start), j.scheduled_end ? ` – ${dt(j.scheduled_end)}` : "")),
        h("div", h("b", "Von"), h("span", mapLink(j.from_address), j.from_floor != null ? ` · ${j.from_floor}. OG${j.from_elevator ? " (Aufzug)" : " ohne Aufzug"}` : "")),
        h("div", h("b", "Nach"), h("span", mapLink(j.to_address), j.to_floor != null ? ` · ${j.to_floor}. OG${j.to_elevator ? " (Aufzug)" : " ohne Aufzug"}` : "")),
        j.volume_m3 ? h("div", h("b", "Volumen"), h("span", `ca. ${String(j.volume_m3).replace(".", ",")} m³`)) : null,
        h("div", h("b", "Kunde"), h("span", j.customer_phone ? h("a", { href: `tel:${j.customer_phone}` }, j.customer_phone) : "–")),
        h("div", h("b", "Team"), h("span", j.team.map((t) => t.name + (t.lead ? " ★" : "")).join(", "))),
        h("div", h("b", "Fahrzeuge"), h("span", j.vehicles.map((v) => v.name + (v.plate ? ` (${v.plate})` : "")).join(", ") || "–")))),
    j.notes ? h("div", { class: "m-card" }, h("h2", "Hinweise vom Büro"), h("p", { style: { whiteSpace: "pre-wrap" } }, j.notes)) : null,
    j.special_wishes ? h("div", { class: "m-card" }, h("h2", "Sonderwünsche"), h("p", { style: { whiteSpace: "pre-wrap" } }, j.special_wishes)) : null,
    h("div", { class: "m-card" }, h("h2", "Rückmeldung ans Büro"),
      h("div", { class: "big-actions" },
        h("button", { class: "btn danger", onclick: () => fb("problem") }, "⚠ Problem"),
        h("button", { class: "btn", onclick: () => fb("sonderwunsch") }, "✚ Sonderwunsch"),
        h("button", { class: "btn", onclick: () => fb("schaden") }, "Schaden melden"),
        h("button", { class: "btn", onclick: () => fb("info") }, "Info / Foto")),
      h("button", { class: "btn ok block", style: { marginTop: "10px" }, onclick: () => fb("abschluss") }, "✓ Auftrag abgeschlossen")),
    h("div", { class: "m-card" }, h("h2", "Meine Zeiten hier"), j.my_time.length ? j.my_time.map((t) => h("div", { class: "entry" }, h("span", `${dt(t.day)} ${t.start_time}–${t.end_time || "läuft"}`), h("b", hm(t.minutes)))) : h("p", { class: "muted" }, "Noch keine."),
      h("button", { class: "btn sm", onclick: async () => { try { await post("/api/my/clock", { action: "start", order_id: j.id }); toast("Zeiterfassung gestartet."); location.hash = "#heute"; } catch (e) { fail(e); } } }, "▶ Zeit für diesen Auftrag starten")),
    j.feedback.length ? h("div", { class: "m-card" }, h("h2", "Meine Meldungen"), j.feedback.map((f) => h("div", { class: "entry" }, h("span", h("b", FEEDBACK[f.kind]), " ", f.text || ""), h("span", { class: "tag " + (f.status === "offen" ? "amber" : "green") }, f.status)))) : null));
}

function feedbackDialog(j, kind) {
  const photos = [];
  const prev = h("div", { class: "photo-prev" });
  const cam = h("input", { type: "file", accept: "image/*", capture: "environment", multiple: true, hidden: true });
  cam.addEventListener("change", async () => {
    for (const f of cam.files) {
      if (photos.length >= 6) break;
      try { const p = await readFileForUpload(f, 1600); photos.push(p); prev.append(h("img", { src: `data:${p.mime};base64,${p.data}`, alt: "Foto" })); } catch (e) { fail(e); }
    }
    cam.value = "";
  });
  const text = area("text", "", { rows: 4, placeholder: kind === "abschluss" ? "Optional: Bemerkungen zum Abschluss" : "Was ist los? Was wünscht der Kunde?" });
  const dlg = h("dialog", { class: "modal" },
    h("div", { class: "modal-head" }, h("h2", FEEDBACK[kind]), h("button", { class: "x", "aria-label": "Schließen", onclick: () => dlg.close() }, "×")),
    h("div", { class: "modal-body grid" }, text, h("button", { class: "btn", onclick: () => cam.click() }, "📷 Foto aufnehmen / auswählen"), cam, prev),
    h("div", { class: "modal-foot" }, h("button", { class: "btn", onclick: () => dlg.close() }, "Abbrechen"),
      h("button", { class: "btn primary", onclick: async (e) => {
        e.target.disabled = true;
        try {
          const r = await send("/api/my/feedback", { order_id: j.id, kind, text: text.value, files: photos }, FEEDBACK[kind]);
          if (!r.queued) toast("Gesendet – das Büro ist informiert.");
          dlg.close();
          render();
        } catch (er) { fail(er); e.target.disabled = false; }
      } }, "Senden")));
  dlg.addEventListener("close", () => dlg.remove());
  document.body.append(dlg);
  dlg.showModal();
}

// ---------- Stunden ----------
async function pageTime(month) {
  const d = await get("/api/my/time" + (month ? `?month=${month}` : ""));
  const mIn = inp("month", d.month, { type: "month" });
  mIn.addEventListener("change", () => (location.hash = `#stunden/${mIn.value}`));
  const jobs = (await get("/api/my/jobs?scope=past")).rows.concat((await get("/api/my/jobs")).rows);
  const f = h("div", { class: "grid" },
    field("Tag", inp("day", new Date().toISOString().slice(0, 10), { type: "date", max: new Date().toISOString().slice(0, 10) })),
    h("div", { class: "row" }, h("div", { class: "grow" }, field("Beginn", inp("start_time", "07:30", { type: "time" }))), h("div", { class: "grow" }, field("Ende", inp("end_time", "16:00", { type: "time" })))),
    field("Pause (Min.)", inp("break_min", "30", { type: "number", min: 0, inputmode: "numeric" })),
    field("Auftrag", sel("order_id", "", [["", "– ohne Auftrag –"], ...jobs.map((j) => [j.id, `${j.number} · ${j.customer || ""}`])])),
    field("Notiz", inp("note", "")));
  frame("Meine Stunden", h("div",
    h("div", { class: "m-card" }, h("h2", "Monat", mIn),
      h("div", { class: "stat3" }, h("div", h("b", hm(d.actual_min)), h("span", "Ist")), h("div", h("b", hm(d.target_min)), h("span", "Soll")), h("div", h("b", (d.overtime_min > 0 ? "+" : "") + hm(d.overtime_min)), h("span", "Saldo"))),
      d.by_order.length ? h("div", { style: { marginTop: "10px" } }, h("b", "Je Auftrag"), d.by_order.map((b) => h("div", { class: "entry" }, h("span", `${b.number} ${b.title}`), h("b", hm(b.minutes))))) : null),
    h("div", { class: "m-card" }, h("h2", "Einträge"),
      d.entries.length ? d.entries.slice().reverse().map((t) => h("div", { class: "entry" },
        h("div", h("b", dt(t.day)), h("div", { class: "small muted" }, `${t.start_time}–${t.end_time || "läuft"} · Pause ${t.break_min} Min.${t.order_number ? " · " + t.order_number : ""}`)),
        h("div", { style: { textAlign: "right" } }, h("b", hm(t.minutes)), h("div", t.approved ? h("span", { class: "tag green" }, "freigegeben") : t.end_time ? h("button", { class: "btn sm", onclick: async () => { if (!confirm("Eintrag löschen?")) return; try { await del(`/api/my/time/${t.id}`); render(); } catch (e) { fail(e); } } }, "Löschen") : null)))) : h("p", { class: "muted" }, "Keine Einträge.")),
    h("div", { class: "m-card" }, h("h2", "Stunden nachtragen"), f,
      h("button", { class: "btn primary block", style: { marginTop: "10px" }, onclick: async (e) => {
        const v = Object.fromEntries([...f.querySelectorAll("[name]")].map((x) => [x.name, x.value]));
        e.target.disabled = true;
        try { const r = await send("/api/my/time", v, "Stunden"); if (!r.queued) toast(r.warn || `Gespeichert: ${hm(r.minutes)} Std.`, r.warn ? "bad" : "ok"); render(); } catch (er) { fail(er); } finally { e.target.disabled = false; }
      } }, "Speichern"))));
}

// ---------- Urlaub & Krank ----------
async function pageAbsence() {
  const d = await get("/api/my/absences");
  const y = d.year;
  const form = (kind) => {
    const file = h("input", { type: "file", accept: "image/*,application/pdf", capture: kind === "krank" ? "environment" : undefined });
    const today = new Date().toISOString().slice(0, 10);
    const f = h("div", { class: "grid" },
      h("div", { class: "row" }, h("div", { class: "grow" }, field("Von", inp("start_date", today, { type: "date", min: kind === "urlaub" ? today : undefined }))), h("div", { class: "grow" }, field("Bis (voraussichtlich)", inp("end_date", today, { type: "date" })))),
      kind === "urlaub" ? check("half_day", false, "nur halber Tag") : null,
      kind === "krank" ? field("AU-Bescheinigung (optional, Foto)", file) : null,
      field("Notiz", inp("note", "", { placeholder: kind === "krank" ? "z. B. Arzttermin, voraussichtlich zurück am …" : "" })));
    return h("div", { class: "m-card" }, h("h2", kind === "urlaub" ? "Urlaub beantragen" : "Krank melden"), f,
      h("button", { class: "btn block " + (kind === "urlaub" ? "primary" : "danger"), style: { marginTop: "10px" }, onclick: async (e) => {
        const v = { kind };
        for (const x of f.querySelectorAll("[name]")) v[x.name] = x.type === "checkbox" ? x.checked : x.value;
        e.target.disabled = true;
        try {
          if (file.files && file.files[0]) v.file = await readFileForUpload(file.files[0], 1800);
          const r = await send("/api/my/absences", v, kind === "urlaub" ? "Urlaubsantrag" : "Krankmeldung");
          if (!r.queued) toast(kind === "urlaub" ? `Antrag gestellt (${String(r.days).replace(".", ",")} Arbeitstage).` : "Krankmeldung ist beim Büro. Gute Besserung!");
          render();
        } catch (er) { fail(er); } finally { e.target.disabled = false; }
      } }, kind === "urlaub" ? "Antrag senden" : "Krankmeldung senden"));
  };
  frame("Urlaub & Krank", h("div",
    h("div", { class: "m-card" }, h("h2", `Urlaubskonto ${new Date().getFullYear()}`), h("div", { class: "stat3" },
      h("div", h("b", String(y.vacation_entitlement).replace(".", ",")), h("span", "Anspruch")), h("div", h("b", String(y.vacation_taken + y.vacation_planned).replace(".", ",")), h("span", "genommen/beantragt")), h("div", h("b", String(y.vacation_remaining).replace(".", ",")), h("span", "Rest")))),
    form("urlaub"), form("krank"),
    h("div", { class: "m-card" }, h("h2", "Meine Einträge"), d.rows.length ? d.rows.map((a) => h("div", { class: "entry" },
      h("div", h("b", ABSENCE[a.kind]), h("div", { class: "small muted" }, `${dt(a.start_date)} – ${dt(a.end_date)} · ${String(a.days).replace(".", ",")} T.`)),
      h("div", h("span", { class: "tag " + (a.status === "genehmigt" ? "green" : a.status === "abgelehnt" ? "red" : "amber") }, ABSENCE_STATUS[a.status]), a.status === "beantragt" ? h("button", { class: "btn sm", onclick: async () => { try { await post(`/api/my/absences/${a.id}/cancel`); render(); } catch (e) { fail(e); } } }, "Zurückziehen") : null))) : h("p", { class: "muted" }, "Keine."))));
}

// ---------- Profil ----------
function pageProfile() {
  const f = h("div", { class: "grid" }, field("Bisheriges Passwort", inp("old", "", { type: "password", autocomplete: "current-password" })), field("Neues Passwort (mind. 10 Zeichen)", inp("new", "", { type: "password", autocomplete: "new-password" })));
  frame("Profil", h("div",
    h("div", { class: "m-card" }, h("h2", me.user.name), h("p", { class: "muted" }, me.user.email), me.user.role !== "mitarbeiter" ? h("a", { class: "btn block", href: "/" }, "Zur Büro-App") : null),
    h("div", { class: "m-card" }, h("h2", "Passwort ändern"), f, h("button", { class: "btn primary block", style: { marginTop: "10px" }, onclick: async () => {
      try { await post("/api/me/password", Object.fromEntries([...f.querySelectorAll("[name]")].map((x) => [x.name, x.value]))); toast("Passwort geändert."); render(); } catch (e) { fail(e); }
    } }, "Ändern")),
    h("button", { class: "btn danger block", onclick: async () => { await post("/api/logout").catch(() => {}); localStorage.removeItem(OUT); location.reload(); } }, "Abmelden")));
}

async function render() {
  const [page, arg] = (location.hash || "#heute").slice(1).split("/");
  try {
    if (page === "auftraege") await pageJobs();
    else if (page === "auftrag") await pageJob(arg);
    else if (page === "stunden") await pageTime(arg);
    else if (page === "frei") await pageAbsence();
    else if (page === "profil") pageProfile();
    else await pageToday();
  } catch (e) {
    if (e instanceof ApiError && e.status === 401) return loginScreen();
    frame("MOVARIS Team", h("div", { class: "badbox" }, e instanceof ApiError ? e.message : "Keine Verbindung zum Server. Bitte später erneut versuchen.", h("p", h("button", { class: "btn sm", onclick: render }, "Erneut versuchen"))));
  }
}

async function start() {
  try { me = await get("/api/me"); } catch (e) { return e instanceof ApiError ? loginScreen() : frame("MOVARIS Team", h("div", { class: "badbox" }, "Keine Verbindung. ", h("button", { class: "btn sm", onclick: start }, "Erneut versuchen"))); }
  if (!me.user) return loginScreen();
  if (!me.employee) {
    clear(root).append(h("div", { class: "auth" }, h("div", { class: "card" }, h("h2", "Kein Mitarbeiterprofil"), h("p", "Ihrem Zugang ist noch kein Mitarbeiterprofil zugeordnet. Bitte im Büro melden."), me.user.role !== "mitarbeiter" ? h("a", { class: "btn primary", href: "/" }, "Zur Büro-App") : null, h("button", { class: "btn", onclick: async () => { await post("/api/logout"); location.reload(); } }, "Abmelden"))));
    return;
  }
  render();
  flush();
}
window.addEventListener("hashchange", render);
window.addEventListener("mv:logout", loginScreen);
// Netzstatus nur im Kopf anzeigen – die aktuelle Seite bleibt bedienbar (Eingaben gehen in die Warteschlange)
const updateNet = () => {
  const top = $(".m-top");
  if (!top) return;
  let n = top.querySelector(".net");
  if (navigator.onLine) n && n.remove();
  else if (!n) top.append(h("span", { class: "net" }, "offline"));
};
window.addEventListener("online", updateNet);
window.addEventListener("offline", updateNet);
if ("serviceWorker" in navigator) navigator.serviceWorker.register("/m/sw.js", { scope: "/m/" }).catch(() => {});
start();
