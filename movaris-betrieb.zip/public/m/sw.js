// Service Worker der Mitarbeiter-App: App-Hülle offline verfügbar, API immer live.
const CACHE = "mv-team-v1";
const SHELL = ["/m/", "/m/index.html", "/m/m.css", "/m/m.js", "/app.css", "/js/lib.js", "/shared/calc.js", "/shared/dates.js", "/shared/domain.js", "/img/icon.svg", "/m/manifest.webmanifest"];

self.addEventListener("install", (e) => {
  e.waitUntil(caches.open(CACHE).then((c) => c.addAll(SHELL)).then(() => self.skipWaiting()));
});
self.addEventListener("activate", (e) => {
  e.waitUntil(caches.keys().then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener("fetch", (e) => {
  const url = new URL(e.request.url);
  if (e.request.method !== "GET" || url.origin !== location.origin || url.pathname.startsWith("/api/")) return;
  // Netz zuerst, bei Funkloch aus dem Speicher
  e.respondWith(
    fetch(e.request)
      .then((r) => {
        if (r.ok && SHELL.includes(url.pathname)) {
          const copy = r.clone();
          caches.open(CACHE).then((c) => c.put(e.request, copy));
        }
        return r;
      })
      .catch(() => caches.match(e.request).then((m) => m || caches.match("/m/index.html")))
  );
});
