// Angebotskalkulation (gleicher Rechenkern im Browser und auf dem Server).
// Alle Preise und Faktoren kommen aus den Einstellungen von MOVARIS – hier sind keine Preise hinterlegt.

export const CALC_DEFAULTS = {
  vat_rate: 19, // Mehrwertsteuer in %
  m3_per_man_hour: 0, // Umzugsvolumen je Mitarbeiterstunde (0 = keine Stundenschätzung)
  min_hours: 0, // Mindesteinsatzzeit in Stunden
  travel_hours: 0, // Pauschale An-/Abfahrtszeit in Stunden
  floor_pct: 0, // Zuschlag je Etage ohne Aufzug in % auf Personal
  carry_free_m: 10, // Laufweg ohne Zuschlag (m)
  carry_pct_per_10m: 0, // Zuschlag je weitere 10 m Laufweg in % auf Personal
  weekend_pct: 0, // Wochenend-/Feiertagszuschlag in % auf Personal
  offer_valid_days: 14,
};

export const round2 = (n) => Math.round((Number(n) || 0) * 100 + Number.EPSILON * 100) / 100;
const num = (v) => {
  const n = typeof v === "string" ? parseFloat(v.replace(",", ".")) : Number(v);
  return Number.isFinite(n) ? n : 0;
};
export const euro = (n) =>
  (Number(n) || 0).toLocaleString("de-DE", { style: "currency", currency: "EUR" });

export function inventoryVolume(inv) {
  return round2((inv || []).reduce((s, i) => s + num(i.m3) * num(i.qty), 0));
}

export function suggest(input, settings) {
  const s = { ...CALC_DEFAULTS, ...(settings || {}) };
  const volume = num(input.volume_m3) || inventoryVolume(input.inventory);
  const out = { volume, staff: num(input.staff) || 0, hours: num(input.hours) || 0, manHours: 0 };
  if (num(s.m3_per_man_hour) > 0 && volume > 0) {
    out.manHours = round2(volume / num(s.m3_per_man_hour));
    if (!out.staff) out.staff = Math.min(8, Math.max(2, Math.ceil(out.manHours / 8)));
    if (!out.hours) {
      const h = Math.ceil((out.manHours / out.staff) * 2) / 2 + num(s.travel_hours);
      out.hours = Math.max(num(s.min_hours), h);
    }
  }
  return out;
}

export function calculate(input, priceItems, settings) {
  const s = { ...CALC_DEFAULTS, ...(settings || {}) };
  const byKey = new Map((priceItems || []).map((p) => [p.key || p.id, p]));
  const byId = new Map((priceItems || []).map((p) => [p.id, p]));
  const vatDefault = num(s.vat_rate);
  const positions = [];
  const hints = [];
  const sug = suggest(input, s);

  const add = (group, item, text, qty, unit, priceOverride) => {
    if (!(qty > 0)) return;
    const price = priceOverride !== undefined && priceOverride !== null && priceOverride !== "" ? num(priceOverride) : num(item?.price);
    if (!item && priceOverride === undefined) return;
    if (!(price > 0)) hints.push(`Preis fehlt: „${item?.name || text}“ – bitte unter Einstellungen → Preise eintragen.`);
    positions.push({
      group,
      key: item?.key || null,
      text,
      qty: round2(qty),
      unit: unit || item?.unit || "",
      price: round2(price),
      vat_rate: item?.vat_rate !== undefined && item?.vat_rate !== null ? num(item.vat_rate) : vatDefault,
      total: round2(qty * price),
    });
  };

  const staff = num(input.staff) || sug.staff;
  const hours = num(input.hours) || sug.hours;
  if (staff > 0 && hours > 0) {
    const it = byKey.get("personal_std");
    add("Personal", it || { name: "Umzugshelfer je Std.", unit: "Std." }, `${staff} Umzugshelfer × ${String(hours).replace(".", ",")} Std.`, staff * hours, "Std.", it ? undefined : 0);
  } else if (sug.volume > 0 && !(num(s.m3_per_man_hour) > 0)) {
    hints.push("Für eine Stundenschätzung bitte „m³ je Mitarbeiterstunde“ in den Einstellungen festlegen oder Personal und Stunden eintragen.");
  }
  const trucks = num(input.trucks);
  if (trucks > 0) {
    const th = num(input.truck_hours) || hours;
    const it = byKey.get("lkw_std");
    add("Fahrzeuge", it || { name: "LKW je Std.", unit: "Std." }, `${trucks} LKW × ${String(th).replace(".", ",")} Std.`, trucks * th, "Std.", it ? undefined : 0);
  }
  const km = num(input.km);
  if (km > 0) {
    const it = byKey.get("km");
    add("Fahrzeuge", it || { name: "Fahrtkosten je km", unit: "km" }, it?.name || "Fahrtkosten", km, "km", it ? undefined : 0);
  }
  for (const x of input.extras || []) {
    const it = byId.get(x.id) || byKey.get(x.key);
    if (!it) continue;
    add(it.category || "Leistungen", it, x.text || it.name, num(x.qty), it.unit, x.price);
  }
  for (const c of input.custom || []) {
    if (!c || !c.text) continue;
    add(c.group || "Sonstiges", { name: c.text, unit: c.unit, vat_rate: c.vat_rate ?? vatDefault, price: c.price }, c.text, num(c.qty) || 1, c.unit || "pauschal", c.price ?? 0);
  }

  // Zuschläge auf Personalkosten
  const personal = positions.filter((p) => p.group === "Personal").reduce((a, p) => a + p.total, 0);
  const sur = [];
  const floors = (input.elevator_from ? 0 : num(input.floors_from)) + (input.elevator_to ? 0 : num(input.floors_to));
  if (floors > 0 && num(s.floor_pct) > 0) sur.push([`Etagenzuschlag (${floors} Etage${floors > 1 ? "n" : ""} ohne Aufzug)`, floors * num(s.floor_pct)]);
  const extraCarry = (m) => Math.ceil(Math.max(0, num(m) - num(s.carry_free_m)) / 10);
  const carrySteps = extraCarry(input.carry_from_m) + extraCarry(input.carry_to_m);
  if (carrySteps > 0 && num(s.carry_pct_per_10m) > 0) sur.push([`Laufwegzuschlag (${carrySteps} × 10 m)`, carrySteps * num(s.carry_pct_per_10m)]);
  if (input.weekend && num(s.weekend_pct) > 0) sur.push(["Wochenend-/Feiertagszuschlag", num(s.weekend_pct)]);
  for (const [text, pct] of sur) {
    if (personal > 0) positions.push({ group: "Zuschläge", key: null, text: `${text}: ${String(round2(pct)).replace(".", ",")} %`, qty: 1, unit: "pauschal", price: round2((personal * pct) / 100), vat_rate: vatDefault, total: round2((personal * pct) / 100) });
  }

  const subtotal = round2(positions.reduce((a, p) => a + p.total, 0));
  const disc = num(input.discount_pct);
  if (disc > 0 && subtotal > 0) {
    const amount = -round2((subtotal * Math.min(disc, 100)) / 100);
    positions.push({ group: "Nachlass", key: null, text: `Nachlass ${String(disc).replace(".", ",")} %`, qty: 1, unit: "pauschal", price: amount, vat_rate: vatDefault, total: amount });
  }

  const net = round2(positions.reduce((a, p) => a + p.total, 0));
  const vatMap = new Map();
  if (disc > 0 && subtotal > 0) {
    // Nachlass anteilig auf die Steuersätze verteilen
    const factor = net / subtotal;
    for (const p of positions) if (p.group !== "Nachlass") vatMap.set(p.vat_rate, (vatMap.get(p.vat_rate) || 0) + p.total * factor);
  } else {
    for (const p of positions) vatMap.set(p.vat_rate, (vatMap.get(p.vat_rate) || 0) + p.total);
  }
  const vat = [...vatMap.entries()].filter(([, base]) => Math.abs(base) > 0.004).map(([rate, base]) => ({ rate, base: round2(base), amount: round2((base * rate) / 100) }));
  const vatSum = round2(vat.reduce((a, v) => a + v.amount, 0));
  return {
    positions,
    totals: { subtotal, discount_pct: disc, net, vat, vat_sum: vatSum, gross: round2(net + vatSum) },
    hints: [...new Set(hints)],
    suggestion: sug,
    volume: sug.volume,
  };
}

// Richtwerte für die Umzugsgutliste (m³ je Stück) – in den Einstellungen anpassbar.
export const DEFAULT_INVENTORY = [
  ["Wohnzimmer", "Sofa 3-Sitzer", 1.5], ["Wohnzimmer", "Sofa 2-Sitzer", 1.0], ["Wohnzimmer", "Sessel", 0.6],
  ["Wohnzimmer", "Couchtisch", 0.3], ["Wohnzimmer", "Wohnwand je Meter", 0.8], ["Wohnzimmer", "Regal", 0.5],
  ["Wohnzimmer", "Fernseher", 0.2], ["Wohnzimmer", "Teppich", 0.1],
  ["Schlafzimmer", "Doppelbett", 1.5], ["Schlafzimmer", "Einzelbett", 0.8], ["Schlafzimmer", "Kleiderschrank je Tür", 0.5],
  ["Schlafzimmer", "Kommode", 0.5], ["Schlafzimmer", "Nachttisch", 0.2],
  ["Küche", "Kühlschrank", 0.8], ["Küche", "Waschmaschine", 0.5], ["Küche", "Küchenzeile je Meter", 0.6],
  ["Küche", "Esstisch", 0.6], ["Küche", "Stuhl", 0.2],
  ["Arbeitszimmer", "Schreibtisch", 0.7], ["Arbeitszimmer", "Bürostuhl", 0.3], ["Arbeitszimmer", "Aktenschrank", 0.6],
  ["Sonstiges", "Umzugskarton", 0.1], ["Sonstiges", "Fahrrad", 0.5], ["Sonstiges", "Gartenmöbel-Set", 1.0], ["Sonstiges", "Klavier", 1.5],
].map(([room, name, m3]) => ({ room, name, m3 }));

export const DEFAULT_PRICE_ITEMS = [
  ["personal_std", "Personal", "Umzugshelfer je Stunde", "Std."],
  ["lkw_std", "Fahrzeuge", "LKW mit Ausrüstung je Stunde", "Std."],
  ["km", "Fahrzeuge", "Fahrtkosten je km", "km"],
  ["anfahrt", "Fahrzeuge", "Anfahrtspauschale", "pauschal"],
  ["montage_std", "Leistungen", "Möbelmontage je Stunde", "Std."],
  ["kueche_std", "Leistungen", "Küchenmontage je Stunde", "Std."],
  ["einpack_std", "Leistungen", "Einpackservice je Stunde", "Std."],
  ["moebellift", "Leistungen", "Möbellift-Einsatz", "Einsatz"],
  ["halteverbot", "Leistungen", "Halteverbotszone je Seite", "Stk."],
  ["klavier", "Leistungen", "Klaviertransport", "pauschal"],
  ["entsorgung_m3", "Entsorgung", "Entsorgung je m³", "m³"],
  ["entruempelung_std", "Entsorgung", "Entrümpelung je Stunde", "Std."],
  ["karton", "Material", "Umzugskarton", "Stk."],
  ["kleiderbox", "Material", "Kleiderbox", "Stk."],
  ["papier", "Material", "Einschlagpapier", "Pack"],
  ["lager_20", "Lagerung", "Lagercontainer 20 Fuß je Monat", "Monat"],
  ["lager_40", "Lagerung", "Möbelhotel 40 Fuß je Monat", "Monat"],
  ["lager_corlette", "Lagerung", "Hallenlagerplatz (Möbelcorlette) je Monat", "Monat"],
].map(([key, category, name, unit], i) => ({ key, category, name, unit, price: 0, vat_rate: 19, sort: i }));
