// Datums-Hilfen (Server und Browser): Arbeitstage, Feiertage Niedersachsen, ISO-Daten.
export const pad = (n) => String(n).padStart(2, "0");
export const isoDay = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
export const parseDay = (s) => {
  const [y, m, d] = String(s).slice(0, 10).split("-").map(Number);
  return new Date(y, m - 1, d, 12);
};
export const addDays = (s, n) => {
  const d = parseDay(s);
  d.setDate(d.getDate() + n);
  return isoDay(d);
};
export const deDate = (s) => {
  if (!s) return "";
  const d = parseDay(s);
  return `${pad(d.getDate())}.${pad(d.getMonth() + 1)}.${d.getFullYear()}`;
};

function easter(y) {
  const a = y % 19, b = Math.floor(y / 100), c = y % 100, d = Math.floor(b / 4), e = b % 4;
  const f = Math.floor((b + 8) / 25), g = Math.floor((b - f + 1) / 3), h = (19 * a + b - d - g + 15) % 30;
  const i = Math.floor(c / 4), k = c % 4, l = (32 + 2 * e + 2 * i - h - k) % 7, m = Math.floor((a + 11 * h + 22 * l) / 451);
  const month = Math.floor((h + l - 7 * m + 114) / 31), day = ((h + l - 7 * m + 114) % 31) + 1;
  return new Date(y, month - 1, day, 12);
}

const holidayCache = new Map();
// Gesetzliche Feiertage Niedersachsen (inkl. Reformationstag seit 2018)
export function holidays(year) {
  if (holidayCache.has(year)) return holidayCache.get(year);
  const e = easter(year);
  const rel = (n) => {
    const d = new Date(e);
    d.setDate(d.getDate() + n);
    return isoDay(d);
  };
  const map = new Map([
    [`${year}-01-01`, "Neujahr"],
    [rel(-2), "Karfreitag"],
    [rel(1), "Ostermontag"],
    [`${year}-05-01`, "Tag der Arbeit"],
    [rel(39), "Christi Himmelfahrt"],
    [rel(50), "Pfingstmontag"],
    [`${year}-10-03`, "Tag der Deutschen Einheit"],
    [`${year}-12-25`, "1. Weihnachtstag"],
    [`${year}-12-26`, "2. Weihnachtstag"],
  ]);
  if (year >= 2018) map.set(`${year}-10-31`, "Reformationstag");
  holidayCache.set(year, map);
  return map;
}
export const holidayName = (s) => holidays(parseDay(s).getFullYear()).get(String(s).slice(0, 10)) || null;
export const isWorkday = (s) => {
  const wd = parseDay(s).getDay();
  return wd !== 0 && wd !== 6 && !holidayName(s);
};
// Arbeitstage zwischen zwei Daten (inklusive), optional begrenzt auf ein Fenster
export function workdays(from, to, winFrom, winTo) {
  let a = String(from).slice(0, 10), b = String(to).slice(0, 10);
  if (winFrom && a < winFrom) a = winFrom;
  if (winTo && b > winTo) b = winTo;
  if (a > b) return 0;
  let n = 0;
  for (let d = a; d <= b; d = addDays(d, 1)) if (isWorkday(d)) n++;
  return n;
}
export const monthRange = (y, m) => {
  const last = new Date(y, m, 0, 12).getDate();
  return [`${y}-${pad(m)}-01`, `${y}-${pad(m)}-${pad(last)}`];
};
export const minutesBetween = (start, end) => {
  const t = (s) => {
    const [h, m] = String(s).split(":").map(Number);
    return h * 60 + (m || 0);
  };
  let d = t(end) - t(start);
  if (d < 0) d += 24 * 60; // über Mitternacht
  return d;
};
// Pausen nach Arbeitszeitgesetz: > 6 Std. 30 Min., > 9 Std. 45 Min.
export const legalBreak = (grossMinutes) => (grossMinutes > 540 ? 45 : grossMinutes > 360 ? 30 : 0);
export const hm = (min) => {
  const sign = min < 0 ? "-" : "";
  const a = Math.abs(Math.round(min));
  return `${sign}${Math.floor(a / 60)}:${pad(a % 60)}`;
};
