// Gemeinsame Fachbegriffe für Server, Büro-App und Mitarbeiter-App.
export const KINDS = {
  umzug: "Umzug",
  besichtigung: "Besichtigung",
  moebelhotel: "Möbelhotel / Einlagerung",
  selfstorage: "Lagercontainer",
  entruempelung: "Entrümpelung / Entsorgung",
  firma: "Firmenumzug",
  verpackung: "Verpackung",
  sonstiges: "Sonstiges",
};

export const STATUS = {
  neu: { label: "Neu eingegangen", color: "#1F7FE0" },
  in_bearbeitung: { label: "In Bearbeitung", color: "#7a5af8" },
  besichtigung: { label: "Besichtigung", color: "#0e9384" },
  angebot_erstellt: { label: "Angebot erstellt", color: "#c4320a" },
  angebot_versendet: { label: "Angebot versendet", color: "#dc6803" },
  zuschlag: { label: "Zuschlag", color: "#079455" },
  absage: { label: "Absage", color: "#98a2b3" },
  geplant: { label: "Geplant", color: "#155eef" },
  in_durchfuehrung: { label: "In Durchführung", color: "#6938ef" },
  erledigt: { label: "Erledigt", color: "#067647" },
  abgerechnet: { label: "Abgerechnet", color: "#344054" },
  storniert: { label: "Storniert", color: "#d92d20" },
};

// Erlaubte Statuswechsel (Admins dürfen jeden Status setzen)
export const NEXT = {
  neu: ["in_bearbeitung", "besichtigung", "angebot_erstellt", "absage", "storniert"],
  in_bearbeitung: ["besichtigung", "angebot_erstellt", "absage", "storniert"],
  besichtigung: ["in_bearbeitung", "angebot_erstellt", "absage", "storniert"],
  angebot_erstellt: ["angebot_versendet", "in_bearbeitung", "absage", "storniert"],
  angebot_versendet: ["zuschlag", "absage", "angebot_erstellt", "storniert"],
  zuschlag: ["geplant", "in_durchfuehrung", "storniert"],
  absage: ["in_bearbeitung"],
  geplant: ["in_durchfuehrung", "erledigt", "storniert"],
  in_durchfuehrung: ["erledigt", "geplant"],
  erledigt: ["abgerechnet", "in_durchfuehrung"],
  abgerechnet: [],
  storniert: ["in_bearbeitung"],
};

// Spalten der Auftragstafel
export const PIPELINE = [
  ["Eingang", ["neu", "in_bearbeitung", "besichtigung"]],
  ["Angebot", ["angebot_erstellt", "angebot_versendet"]],
  ["Beauftragt", ["zuschlag", "geplant", "in_durchfuehrung"]],
  ["Abschluss", ["erledigt", "abgerechnet"]],
];

export const ROLES = { admin: "Geschäftsführung (Admin)", buero: "Büro / Disposition", mitarbeiter: "Mitarbeiter" };
export const ABSENCE = { urlaub: "Urlaub", krank: "Krankmeldung", sonstiges: "Sonstige Abwesenheit" };
export const ABSENCE_STATUS = { beantragt: "Beantragt", genehmigt: "Genehmigt", abgelehnt: "Abgelehnt", gemeldet: "Gemeldet" };
export const FEEDBACK = { problem: "Problem", sonderwunsch: "Sonderwunsch Kunde", info: "Info", schaden: "Schaden", abschluss: "Auftrag abgeschlossen" };
export const OFFER_STATUS = { entwurf: "Entwurf", versendet: "Versendet", angenommen: "Angenommen", abgelehnt: "Abgelehnt" };
