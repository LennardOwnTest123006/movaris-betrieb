document.querySelectorAll("[data-print]").forEach(function (b) { b.addEventListener("click", function () { window.print(); }); });
if (/[?&]auto=1/.test(location.search)) setTimeout(function () { window.print(); }, 400);
