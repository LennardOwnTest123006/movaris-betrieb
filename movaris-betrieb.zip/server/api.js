// Geschützte API für Büro-App und Mitarbeiter-App.
import { readFile, unlink } from "node:fs/promises";
import { join } from "node:path";
import { tmpdir } from "node:os";
import { HttpError, bad, forbidden, notFound } from "./http.js";
import { hashPassword, verifyPassword, passwordProblem, uid, token32, sessionHash, readCookie } from "./auth.js";
import {
  str, num, int, flag, day, time, dateTime, email, oneOf, nowIso, nowLocal, getSettings, putSetting, DEFAULT_SETTINGS,
  createOrder, setStatus, logEvent, nextNumber, ORDER_FIELDS, storeFile, planConflicts, employeeReport,
  todayStatusForEmployees, csv, findOrCreateCustomer,
} from "./services.js";
import { calculate, CALC_DEFAULTS, round2 } from "../public/shared/calc.js";
import { KINDS, STATUS, NEXT, ABSENCE, FEEDBACK, ROLES } from "../public/shared/domain.js";
import { workdays, minutesBetween, legalBreak, addDays, monthRange } from "../public/shared/dates.js";
import { offerEmail, printPage, offerMarkup } from "./offerdoc.js";
import { sendConfigured } from "./mail.js";

const OFFICE = ["admin", "buero"];
const ADMIN = ["admin"];
const page = (q) => {
  const limit = Math.min(200, Math.max(1, int(q.limit) || 50));
  return { limit, offset: Math.max(0, int(q.offset) || 0) };
};
const raw = (body, headers, status = 200) => ({ __raw: true, body, headers, status });

export function registerRoutes(r, { db, cfg, mail }) {
  const getOrder = async (id) => {
    const o = await db.get("SELECT * FROM orders WHERE id = ?", [id]);
    if (!o) throw notFound("Auftrag nicht gefunden.");
    return o;
  };
  const myEmployee = async (user) => {
    if (!user.employee_id) throw forbidden("Ihrem Zugang ist kein Mitarbeiterprofil zugeordnet.");
    const e = await db.get("SELECT * FROM employees WHERE id = ?", [user.employee_id]);
    if (!e) throw forbidden("Mitarbeiterprofil nicht gefunden.");
    return e;
  };
  const assigned = async (orderId, employeeId) => Boolean(await db.get("SELECT 1 AS x FROM order_staff WHERE order_id = ? AND employee_id = ?", [orderId, employeeId]));
  const priceItems = () => db.all("SELECT * FROM price_items WHERE active = 1 ORDER BY sort, name");

  // ---------- Profil ----------
  r.get("/api/me", async ({ user }) => {
    if (!user) return { user: null };
    const s = await getSettings(db);
    const emp = user.employee_id ? await db.get("SELECT id, name, weekly_hours, vacation_days FROM employees WHERE id = ?", [user.employee_id]) : null;
    return { user, employee: emp, company: s.company.name, roles: ROLES };
  }, { auth: false });
  r.post("/api/me/password", async (ctx) => {
    const b = await ctx.body();
    const u = await db.get("SELECT password_hash FROM users WHERE id = ?", [ctx.user.id]);
    if (!(await verifyPassword(b.old || "", u.password_hash))) throw bad("Das bisherige Passwort stimmt nicht.");
    const p = passwordProblem(b.new);
    if (p) throw bad(p);
    await db.run("UPDATE users SET password_hash = ? WHERE id = ?", [await hashPassword(b.new), ctx.user.id]);
    await db.run("DELETE FROM sessions WHERE user_id = ? AND id <> ?", [ctx.user.id, sessionHash(readCookie(ctx.req))]);
    return { ok: true };
  });

  // ---------- Dashboard & Zähler ----------
  r.get("/api/badges", async () => {
    const q = async (sql, p) => (await db.get(sql, p))?.n || 0;
    return {
      new_orders: await q("SELECT COUNT(*) AS n FROM orders WHERE status = 'neu'"),
      mail_open: await q("SELECT COUNT(*) AS n FROM mail_log WHERE status = 'offen'"),
      feedback_open: await q("SELECT COUNT(*) AS n FROM feedback WHERE status = 'offen'"),
      absences_pending: await q("SELECT COUNT(*) AS n FROM absences WHERE status = 'beantragt'"),
      time_unapproved: await q("SELECT COUNT(*) AS n FROM time_entries WHERE approved = 0 AND end_time IS NOT NULL"),
    };
  }, { roles: OFFICE });

  r.get("/api/dashboard", async () => {
    const today = nowLocal().day;
    const yearStart = today.slice(0, 4) + "-01-01";
    const byStatus = await db.all("SELECT status, COUNT(*) AS n FROM orders GROUP BY status");
    const won = await db.get("SELECT COUNT(*) AS n, COALESCE(SUM(gross),0) AS sum FROM offers WHERE status = 'angenommen' AND decided_at >= ?", [yearStart]);
    const lost = await db.get("SELECT COUNT(*) AS n FROM orders WHERE status = 'absage' AND updated_at >= ?", [yearStart]);
    const openOffers = await db.get("SELECT COUNT(*) AS n, COALESCE(SUM(gross),0) AS sum FROM offers WHERE status = 'versendet'");
    const upcoming = await db.all(
      "SELECT o.id, o.number, o.title, o.kind, o.status, o.scheduled_start, o.scheduled_end, o.from_address, o.to_address, c.name AS customer FROM orders o LEFT JOIN customers c ON c.id = o.customer_id WHERE o.scheduled_start >= ? AND o.scheduled_start < ? AND o.status NOT IN ('storniert','absage') ORDER BY o.scheduled_start LIMIT 20",
      [today, addDays(today, 8)]
    );
    for (const u of upcoming) u.staff = (await db.all("SELECT e.name FROM order_staff s JOIN employees e ON e.id = s.employee_id WHERE s.order_id = ?", [u.id])).map((x) => x.name);
    const absent = await db.all("SELECT a.kind, a.end_date, e.name FROM absences a JOIN employees e ON e.id = a.employee_id WHERE a.status IN ('genehmigt','gemeldet') AND a.start_date <= ? AND a.end_date >= ?", [today, today]);
    const newest = await db.all("SELECT o.id, o.number, o.title, o.kind, o.source, o.created_at, c.name AS customer FROM orders o LEFT JOIN customers c ON c.id = o.customer_id WHERE o.status = 'neu' ORDER BY o.created_at DESC LIMIT 8");
    const monthFrom = today.slice(0, 8) + "01";
    const hours = await db.get("SELECT COALESCE(SUM(minutes),0) AS m FROM time_entries WHERE day >= ?", [monthFrom]);
    const decided = (won?.n || 0) + (lost?.n || 0);
    return {
      today,
      by_status: Object.fromEntries(byStatus.map((x) => [x.status, x.n])),
      won: { count: won?.n || 0, gross: round2(won?.sum) },
      lost: lost?.n || 0,
      win_rate: decided ? Math.round(((won?.n || 0) / decided) * 100) : null,
      open_offers: { count: openOffers?.n || 0, gross: round2(openOffers?.sum) },
      upcoming,
      absent,
      newest,
      month_minutes: hours?.m || 0,
      mail: mail.status(),
    };
  }, { roles: OFFICE });

  // ---------- Kunden ----------
  r.get("/api/customers", async ({ query }) => {
    const { limit, offset } = page(query);
    const q = str(query.q, 80);
    const where = q ? "WHERE lower(c.name) LIKE ? OR lower(COALESCE(c.email,'')) LIKE ? OR lower(COALESCE(c.city,'')) LIKE ? OR COALESCE(c.phone,'') LIKE ?" : "";
    const p = q ? [`%${q.toLowerCase()}%`, `%${q.toLowerCase()}%`, `%${q.toLowerCase()}%`, `%${q}%`] : [];
    const rows = await db.all(`SELECT c.*, (SELECT COUNT(*) FROM orders o WHERE o.customer_id = c.id) AS orders FROM customers c ${where} ORDER BY c.created_at DESC LIMIT ? OFFSET ?`, [...p, limit, offset]);
    return { rows };
  }, { roles: OFFICE });
  r.get("/api/customers/:id", async ({ params }) => {
    const c = await db.get("SELECT * FROM customers WHERE id = ?", [params.id]);
    if (!c) throw notFound();
    c.orders = await db.all("SELECT id, number, title, kind, status, created_at, scheduled_start FROM orders WHERE customer_id = ? ORDER BY created_at DESC", [params.id]);
    return c;
  }, { roles: OFFICE });
  const CUSTOMER = { name: (v) => str(v, 120), company: (v) => str(v, 120), email, phone: (v) => str(v, 40), street: (v) => str(v, 160), zip: (v) => str(v, 10), city: (v) => str(v, 80), notes: (v) => str(v, 4000) };
  r.post("/api/customers", async (ctx) => {
    const b = await ctx.body();
    if (!str(b.name)) throw bad("Name fehlt.");
    const id = await db.tx((t) => findOrCreateCustomer(t, Object.fromEntries(Object.entries(CUSTOMER).map(([k, f]) => [k, f(b[k])]))));
    return { id };
  }, { roles: OFFICE });
  r.put("/api/customers/:id", async (ctx) => {
    const b = await ctx.body();
    const sets = [], vals = [];
    for (const [k, f] of Object.entries(CUSTOMER)) if (b[k] !== undefined) { sets.push(`${k} = ?`); vals.push(f(b[k])); }
    if (b.name !== undefined && !str(b.name)) throw bad("Name darf nicht leer sein.");
    if (!sets.length) return { ok: true };
    const r2 = await db.run(`UPDATE customers SET ${sets.join(", ")} WHERE id = ?`, [...vals, ctx.params.id]);
    if (!r2.changes) throw notFound();
    return { ok: true };
  }, { roles: OFFICE });

  // ---------- Aufträge ----------
  r.get("/api/orders", async ({ query }) => {
    const { limit, offset } = page(query);
    const w = [], p = [];
    if (query.status) {
      const list = String(query.status).split(",").filter((s) => STATUS[s]);
      if (list.length) { w.push(`o.status IN (${list.map(() => "?").join(",")})`); p.push(...list); }
    }
    if (query.kind && KINDS[query.kind]) { w.push("o.kind = ?"); p.push(query.kind); }
    if (query.q) {
      const q = `%${String(query.q).toLowerCase().slice(0, 80)}%`;
      w.push("(lower(o.number) LIKE ? OR lower(COALESCE(o.title,'')) LIKE ? OR lower(COALESCE(c.name,'')) LIKE ? OR lower(COALESCE(c.email,'')) LIKE ? OR lower(COALESCE(o.from_address,'')) LIKE ? OR lower(COALESCE(o.to_address,'')) LIKE ?)");
      p.push(q, q, q, q, q, q);
    }
    if (query.from) { w.push("COALESCE(o.scheduled_start, o.desired_date, o.created_at) >= ?"); p.push(day(query.from)); }
    if (query.to) { w.push("COALESCE(o.scheduled_start, o.desired_date, o.created_at) <= ?"); p.push(day(query.to) + "T23:59"); }
    const where = w.length ? "WHERE " + w.join(" AND ") : "";
    const rows = await db.all(
      `SELECT o.id, o.number, o.title, o.kind, o.status, o.source, o.desired_date, o.scheduled_start, o.from_address, o.to_address, o.volume_m3, o.created_at, o.updated_at,
       c.name AS customer, c.phone AS customer_phone,
       (SELECT gross FROM offers f WHERE f.order_id = o.id ORDER BY f.created_at DESC LIMIT 1) AS offer_gross
       FROM orders o LEFT JOIN customers c ON c.id = o.customer_id ${where} ORDER BY o.updated_at DESC LIMIT ? OFFSET ?`,
      [...p, limit, offset]
    );
    const total = await db.get(`SELECT COUNT(*) AS n FROM orders o LEFT JOIN customers c ON c.id = o.customer_id ${where}`, p);
    return { rows, total: total?.n || 0 };
  }, { roles: OFFICE });

  r.post("/api/orders", async (ctx) => {
    const b = await ctx.body();
    if (!b.customer_id && !str(b.customer?.name)) throw bad("Bitte Kunde angeben.");
    if (b.customer?.email) b.customer.email = email(b.customer.email);
    const res = await db.tx((t) => createOrder(t, { ...b, source: "manuell", status: "neu" }, ctx.user.name));
    return res;
  }, { roles: OFFICE });

  r.get("/api/orders/:id", async ({ params }) => {
    const o = await getOrder(params.id);
    const [customer, staff, vehicles, offers, events, feedback, files, time] = await Promise.all([
      o.customer_id ? db.get("SELECT * FROM customers WHERE id = ?", [o.customer_id]) : null,
      db.all("SELECT e.id, e.name, e.phone, s.lead FROM order_staff s JOIN employees e ON e.id = s.employee_id WHERE s.order_id = ? ORDER BY s.lead DESC, e.name", [o.id]),
      db.all("SELECT v.id, v.name, v.plate FROM order_vehicles x JOIN vehicles v ON v.id = x.vehicle_id WHERE x.order_id = ?", [o.id]),
      db.all("SELECT id, number, version, status, net, gross, valid_until, created_at, sent_at, decided_at, decided_by, decision_note, token FROM offers WHERE order_id = ? ORDER BY created_at DESC", [o.id]),
      db.all("SELECT * FROM order_events WHERE order_id = ? ORDER BY created_at DESC LIMIT 200", [o.id]),
      db.all("SELECT f.*, e.name AS employee FROM feedback f LEFT JOIN employees e ON e.id = f.employee_id WHERE f.order_id = ? ORDER BY f.created_at DESC", [o.id]),
      db.all("SELECT id, name, mime, size, created_at FROM files WHERE order_id = ? ORDER BY created_at DESC", [o.id]),
      db.all("SELECT t.employee_id, e.name, SUM(t.minutes) AS minutes, COUNT(*) AS entries FROM time_entries t JOIN employees e ON e.id = t.employee_id WHERE t.order_id = ? GROUP BY t.employee_id, e.name", [o.id]),
    ]);
    o.inventory = o.inventory ? JSON.parse(o.inventory) : [];
    for (const f of feedback) f.file_ids = f.file_ids ? JSON.parse(f.file_ids) : [];
    for (const f of offers) f.link = f.token && cfg.publicUrl ? `${cfg.publicUrl}/angebot/${f.token}` : null;
    return { order: o, customer, staff, vehicles, offers, events, feedback, files, time, next: NEXT[o.status] || [] };
  }, { roles: OFFICE });

  r.put("/api/orders/:id", async (ctx) => {
    const o = await getOrder(ctx.params.id);
    const b = await ctx.body();
    const sets = [], vals = [], changed = [];
    for (const [k, f] of Object.entries(ORDER_FIELDS)) {
      if (b[k] === undefined) continue;
      const v = f(b[k]);
      if (String(v ?? "") !== String(o[k] ?? "")) { sets.push(`${k} = ?`); vals.push(v); changed.push(k); }
    }
    if (!sets.length) return { ok: true };
    await db.tx(async (t) => {
      await t.run(`UPDATE orders SET ${sets.join(", ")}, updated_at = ? WHERE id = ?`, [...vals, nowIso(), o.id]);
      await logEvent(t, o.id, "bearbeitet", `Geändert: ${changed.join(", ")}`, ctx.user.name);
    });
    return { ok: true };
  }, { roles: OFFICE });

  r.post("/api/orders/:id/status", async (ctx) => {
    const o = await getOrder(ctx.params.id);
    const b = await ctx.body();
    const s = oneOf(b.status, Object.keys(STATUS), "Status");
    if (ctx.user.role !== "admin" && !(NEXT[o.status] || []).includes(s)) throw bad(`Wechsel von „${STATUS[o.status].label}“ zu „${STATUS[s].label}“ ist nicht vorgesehen.`);
    await db.tx((t) => setStatus(t, o, s, ctx.user.name, str(b.note, 500)));
    return { ok: true, status: s };
  }, { roles: OFFICE });

  r.post("/api/orders/:id/notes", async (ctx) => {
    const o = await getOrder(ctx.params.id);
    const b = await ctx.body();
    const text = str(b.text, 4000);
    if (!text) throw bad("Notiz ist leer.");
    await db.tx((t) => logEvent(t, o.id, "notiz", text, ctx.user.name));
    return { ok: true };
  }, { roles: OFFICE });

  r.del("/api/orders/:id", async ({ params }) => {
    const o = await getOrder(params.id);
    await db.tx(async (t) => {
      await t.run("DELETE FROM time_entries WHERE order_id = ?", [o.id]);
      await t.run("UPDATE mail_log SET order_id = NULL WHERE order_id = ?", [o.id]);
      await t.run("DELETE FROM orders WHERE id = ?", [o.id]);
    });
    return { ok: true };
  }, { roles: ADMIN });

  // Planung: Termin, Team, Fahrzeuge
  r.post("/api/orders/:id/schedule", async (ctx) => {
    const o = await getOrder(ctx.params.id);
    const b = await ctx.body();
    const start = dateTime(b.start, "Beginn");
    const end = dateTime(b.end, "Ende");
    if (start && end && end <= start) throw bad("Das Ende muss nach dem Beginn liegen.");
    const employeeIds = [...new Set((b.employee_ids || []).map(String))].slice(0, 30);
    const vehicleIds = [...new Set((b.vehicle_ids || []).map(String))].slice(0, 10);
    const conflicts = await planConflicts(db, { orderId: o.id, start, end, employeeIds, vehicleIds });
    if (conflicts.length && !b.force) throw new HttpError(409, "Es gibt Planungskonflikte.", { conflicts });
    await db.tx(async (t) => {
      await t.run("UPDATE orders SET scheduled_start = ?, scheduled_end = ?, updated_at = ? WHERE id = ?", [start, end, nowIso(), o.id]);
      await t.run("DELETE FROM order_staff WHERE order_id = ?", [o.id]);
      for (const eid of employeeIds) await t.run("INSERT INTO order_staff (order_id, employee_id, lead) VALUES (?, ?, ?)", [o.id, eid, eid === b.lead_id ? 1 : 0]);
      await t.run("DELETE FROM order_vehicles WHERE order_id = ?", [o.id]);
      for (const vid of vehicleIds) await t.run("INSERT INTO order_vehicles (order_id, vehicle_id) VALUES (?, ?)", [o.id, vid]);
      const names = employeeIds.length ? (await t.all(`SELECT name FROM employees WHERE id IN (${employeeIds.map(() => "?").join(",")})`, employeeIds)).map((x) => x.name).join(", ") : "–";
      await logEvent(t, o.id, "planung", `Planung: ${start ? start.replace("T", " ") : "ohne Termin"}${end ? " bis " + end.replace("T", " ") : ""} · Team: ${names}${conflicts.length ? ` · trotz ${conflicts.length} Konflikt(en)` : ""}`, ctx.user.name);
      if (start && o.status === "zuschlag") await setStatus(t, o, "geplant", ctx.user.name);
    });
    return { ok: true, conflicts };
  }, { roles: OFFICE });

  r.post("/api/plan/check", async (ctx) => {
    const b = await ctx.body();
    return { conflicts: await planConflicts(db, { orderId: b.order_id, start: dateTime(b.start), end: dateTime(b.end), employeeIds: b.employee_ids || [], vehicleIds: b.vehicle_ids || [] }) };
  }, { roles: OFFICE });

  r.get("/api/plan", async ({ query }) => {
    const from = day(query.from) || nowLocal().day;
    const to = day(query.to) || addDays(from, 6);
    const orders = await db.all(
      "SELECT o.id, o.number, o.title, o.kind, o.status, o.scheduled_start, o.scheduled_end, o.from_address, o.to_address, o.volume_m3, c.name AS customer FROM orders o LEFT JOIN customers c ON c.id = o.customer_id WHERE o.scheduled_start IS NOT NULL AND o.scheduled_start <= ? AND COALESCE(o.scheduled_end, o.scheduled_start) >= ? AND o.status NOT IN ('storniert','absage') ORDER BY o.scheduled_start",
      [to + "T23:59", from]
    );
    for (const o of orders) {
      o.staff = (await db.all("SELECT employee_id FROM order_staff WHERE order_id = ?", [o.id])).map((x) => x.employee_id);
      o.vehicles = (await db.all("SELECT vehicle_id FROM order_vehicles WHERE order_id = ?", [o.id])).map((x) => x.vehicle_id);
    }
    const unplanned = await db.all("SELECT o.id, o.number, o.title, o.kind, o.status, o.desired_date, c.name AS customer FROM orders o LEFT JOIN customers c ON c.id = o.customer_id WHERE o.status IN ('zuschlag','besichtigung') AND o.scheduled_start IS NULL ORDER BY COALESCE(o.desired_date, o.created_at) LIMIT 50");
    const absences = await db.all("SELECT a.id, a.employee_id, a.kind, a.start_date, a.end_date, a.status FROM absences a WHERE a.status IN ('beantragt','genehmigt','gemeldet') AND a.start_date <= ? AND a.end_date >= ?", [to, from]);
    const employees = await db.all("SELECT id, name, color, position FROM employees WHERE active = 1 ORDER BY name");
    const vehicles = await db.all("SELECT id, name, plate FROM vehicles WHERE active = 1 ORDER BY name");
    return { from, to, orders, unplanned, absences, employees, vehicles };
  }, { roles: OFFICE });

  // ---------- Angebote ----------
  const offerData = async (offerId) => {
    const offer = await db.get("SELECT * FROM offers WHERE id = ?", [offerId]);
    if (!offer) throw notFound("Angebot nicht gefunden.");
    const order = await getOrder(offer.order_id);
    const customer = order.customer_id ? await db.get("SELECT * FROM customers WHERE id = ?", [order.customer_id]) : null;
    const settings = await getSettings(db);
    return { offer, order, customer, company: settings.company, settings };
  };
  const cleanInput = (i = {}) => ({
    volume_m3: num(i.volume_m3), staff: num(i.staff), hours: num(i.hours), trucks: num(i.trucks), truck_hours: num(i.truck_hours), km: num(i.km),
    floors_from: num(i.floors_from), elevator_from: flag(i.elevator_from), floors_to: num(i.floors_to), elevator_to: flag(i.elevator_to),
    carry_from_m: num(i.carry_from_m), carry_to_m: num(i.carry_to_m), weekend: flag(i.weekend), discount_pct: num(i.discount_pct),
    inventory: (i.inventory || []).slice(0, 300).map((x) => ({ name: str(x.name, 80), room: str(x.room, 40), m3: num(x.m3) || 0, qty: num(x.qty) || 0 })).filter((x) => x.qty > 0),
    extras: (i.extras || []).slice(0, 60).map((x) => ({ id: str(x.id, 60), key: str(x.key, 60), qty: num(x.qty) || 0, price: num(x.price) ?? undefined, text: str(x.text, 200) || undefined })).filter((x) => x.qty > 0),
    custom: (i.custom || []).slice(0, 40).map((x) => ({ text: str(x.text, 200), qty: num(x.qty) || 1, unit: str(x.unit, 20) || "pauschal", price: num(x.price) || 0, group: str(x.group, 40) || "Sonstiges", vat_rate: num(x.vat_rate) ?? undefined })).filter((x) => x.text),
  });

  r.post("/api/calc", async (ctx) => {
    const b = await ctx.body();
    const s = await getSettings(db);
    return calculate(cleanInput(b.input || b), await priceItems(), s.calc);
  }, { roles: OFFICE });

  r.post("/api/orders/:id/offers", async (ctx) => {
    const o = await getOrder(ctx.params.id);
    const b = await ctx.body();
    const s = await getSettings(db);
    const input = cleanInput(b.input);
    const result = calculate(input, await priceItems(), s.calc);
    if (!result.positions.length) throw bad("Das Angebot hat noch keine Positionen.");
    const id = uid();
    const today = nowLocal().day;
    const out = await db.tx(async (t) => {
      const number = await nextNumber(t, "offers", "A");
      const v = await t.get("SELECT COUNT(*) AS n FROM offers WHERE order_id = ?", [o.id]);
      await t.run(
        "INSERT INTO offers (id, order_id, number, version, status, input, positions, totals, net, gross, valid_until, intro, terms, created_at) VALUES (?, ?, ?, ?, 'entwurf', ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        [id, o.id, number, (v?.n || 0) + 1, JSON.stringify(input), JSON.stringify(result.positions), JSON.stringify(result.totals), result.totals.net, result.totals.gross,
          day(b.valid_until) || addDays(today, Number(s.calc.offer_valid_days) || 14), str(b.intro, 3000) ?? s.offer.intro, str(b.terms, 5000) ?? s.offer.terms, nowIso()]
      );
      const upd = [];
      if (result.volume && !o.volume_m3) upd.push(["volume_m3", result.volume]);
      if (input.inventory.length) upd.push(["inventory", JSON.stringify(input.inventory)]);
      if (upd.length) await t.run(`UPDATE orders SET ${upd.map(([k]) => `${k} = ?`).join(", ")} WHERE id = ?`, [...upd.map(([, v2]) => v2), o.id]);
      await logEvent(t, o.id, "angebot", `Angebot ${number} erstellt (${result.totals.gross.toFixed(2).replace(".", ",")} € brutto).`, ctx.user.name);
      if (["neu", "in_bearbeitung", "besichtigung"].includes(o.status)) await setStatus(t, o, "angebot_erstellt", ctx.user.name);
      return { id, number };
    });
    return { ...out, hints: result.hints };
  }, { roles: OFFICE });

  r.get("/api/offers/:id", async ({ params }) => {
    const d = await offerData(params.id);
    const o = d.offer;
    return { ...o, input: JSON.parse(o.input || "{}"), positions: JSON.parse(o.positions || "[]"), totals: JSON.parse(o.totals || "{}"), link: o.token && cfg.publicUrl ? `${cfg.publicUrl}/angebot/${o.token}` : null, customer_email: d.customer?.email || null };
  }, { roles: OFFICE });

  r.put("/api/offers/:id", async (ctx) => {
    const d = await offerData(ctx.params.id);
    if (d.offer.status !== "entwurf") throw bad("Nur Entwürfe können geändert werden. Bitte eine neue Version anlegen.");
    const b = await ctx.body();
    const input = cleanInput(b.input);
    const result = calculate(input, await priceItems(), d.settings.calc);
    await db.run("UPDATE offers SET input = ?, positions = ?, totals = ?, net = ?, gross = ?, valid_until = ?, intro = ?, terms = ? WHERE id = ?", [
      JSON.stringify(input), JSON.stringify(result.positions), JSON.stringify(result.totals), result.totals.net, result.totals.gross,
      day(b.valid_until) || d.offer.valid_until, str(b.intro, 3000) ?? d.offer.intro, str(b.terms, 5000) ?? d.offer.terms, d.offer.id,
    ]);
    return { ok: true, hints: result.hints, totals: result.totals };
  }, { roles: OFFICE });

  r.get("/api/offers/:id/print", async ({ params }) => raw(printPage(await offerData(params.id)), { "content-type": "text/html; charset=utf-8" }), { roles: OFFICE });

  const markSent = async (t, d, userName, how) => {
    const token = d.offer.token || token32();
    await t.run("UPDATE offers SET status = 'versendet', sent_at = ?, token = ? WHERE id = ?", [nowIso(), token, d.offer.id]);
    await logEvent(t, d.order.id, "angebot", `Angebot ${d.offer.number} versendet (${how}).`, userName);
    if (["neu", "in_bearbeitung", "besichtigung", "angebot_erstellt"].includes(d.order.status)) await setStatus(t, d.order, "angebot_versendet", userName);
    return token;
  };
  r.post("/api/offers/:id/send", async (ctx) => {
    const d = await offerData(ctx.params.id);
    if (!["entwurf", "versendet"].includes(d.offer.status)) throw bad("Dieses Angebot wurde bereits entschieden.");
    const b = await ctx.body();
    const to = email(b.to) || d.customer?.email;
    if (!to) throw bad("Keine E-Mail-Adresse für den Kunden hinterlegt.");
    if (!sendConfigured(cfg)) throw bad("E-Mail-Versand ist nicht eingerichtet (SMTP oder AgentMail in der .env). Alternativ: drucken/als PDF speichern und „Als versendet markieren“.");
    const token = d.offer.token || token32();
    d.offer.token = token;
    const link = cfg.publicUrl ? `${cfg.publicUrl}/angebot/${token}` : null;
    const subject = (str(b.subject, 200) || d.settings.offer.subject || "Ihr Angebot {nummer}").replace("{nummer}", d.offer.number);
    const html = offerEmail({ ...d, greeting: str(b.message, 3000) || d.settings.offer.greeting }, link);
    await mail.send({ to, subject, html, text: `${d.settings.offer.greeting}\n\nanbei unser Angebot ${d.offer.number} über ${d.offer.gross.toFixed(2).replace(".", ",")} € (brutto).${link ? `\nOnline ansehen und annehmen: ${link}` : ""}`, replyTo: cfg.smtp.from || undefined });
    await db.tx((t) => markSent(t, d, ctx.user.name, `per E-Mail an ${to}`));
    return { ok: true, link };
  }, { roles: OFFICE });

  r.post("/api/offers/:id/mark-sent", async (ctx) => {
    const d = await offerData(ctx.params.id);
    if (d.offer.status !== "entwurf") throw bad("Das Angebot ist kein Entwurf mehr.");
    const token = await db.tx((t) => markSent(t, d, ctx.user.name, "manuell"));
    return { ok: true, link: cfg.publicUrl ? `${cfg.publicUrl}/angebot/${token}` : null };
  }, { roles: OFFICE });

  r.post("/api/offers/:id/decision", async (ctx) => {
    const d = await offerData(ctx.params.id);
    const b = await ctx.body();
    const dec = oneOf(b.decision, ["angenommen", "abgelehnt"], "Entscheidung");
    if (!["versendet", "entwurf"].includes(d.offer.status)) throw bad("Für dieses Angebot liegt bereits eine Entscheidung vor.");
    await db.tx(async (t) => {
      await t.run("UPDATE offers SET status = ?, decided_at = ?, decided_by = ?, decision_note = ?, token = COALESCE(token, ?) WHERE id = ?", [dec, nowIso(), ctx.user.name, str(b.note, 1000), token32(), d.offer.id]);
      await logEvent(t, d.order.id, "angebot", `Angebot ${d.offer.number} ${dec}${b.note ? ` (${str(b.note, 300)})` : ""}.`, ctx.user.name);
      if (dec === "angenommen") await setStatus(t, d.order, "zuschlag", ctx.user.name);
      else await setStatus(t, d.order, "absage", ctx.user.name, str(b.note, 500));
    });
    return { ok: true };
  }, { roles: OFFICE });

  // ---------- Mitarbeiter ----------
  const EMP = {
    name: (v) => str(v, 120), phone: (v) => str(v, 40), email: (v) => email(v), position: (v) => str(v, 80),
    hourly_wage: num, weekly_hours: num, vacation_days: num, entry_date: (v) => day(v, "Eintrittsdatum"), color: (v) => (/^#[0-9a-f]{6}$/i.test(v || "") ? v : null), notes: (v) => str(v, 4000), active: flag,
  };
  r.get("/api/employees", async () => {
    const today = nowLocal().day;
    const [y, m] = [Number(today.slice(0, 4)), Number(today.slice(5, 7))];
    const emps = await db.all("SELECT * FROM employees ORDER BY active DESC, name");
    const abs = await db.all("SELECT employee_id, kind, start_date, end_date, status FROM absences WHERE start_date <= ? AND end_date >= ?", [today, today]);
    const plan = await db.all("SELECT s.employee_id FROM order_staff s JOIN orders o ON o.id = s.order_id WHERE o.scheduled_start <= ? AND COALESCE(o.scheduled_end, o.scheduled_start) >= ? AND o.status NOT IN ('storniert','absage')", [today + "T23:59", today]);
    const st = todayStatusForEmployees(abs, [{ staff: plan.map((p) => p.employee_id) }], today);
    const users = await db.all("SELECT employee_id, email, role FROM users WHERE employee_id IS NOT NULL");
    for (const e of emps) {
      const rep = await employeeReport(db, e, y, m);
      e.today = st[e.id] || "frei";
      e.month_minutes = rep.month.actual_min;
      e.month_target = rep.month.target_min;
      e.vacation_remaining = rep.year.vacation_remaining;
      e.sick_days = rep.year.sick_days;
      e.login = users.find((u) => u.employee_id === e.id) || null;
      delete e.hourly_wage;
    }
    return { rows: emps };
  }, { roles: OFFICE });
  r.get("/api/employees/:id", async ({ params, query, user }) => {
    const e = await db.get("SELECT * FROM employees WHERE id = ?", [params.id]);
    if (!e) throw notFound();
    const today = nowLocal().day;
    const y = int(query.year) || Number(today.slice(0, 4));
    const m = int(query.month) || Number(today.slice(5, 7));
    const report = await employeeReport(db, e, y, m);
    if (user.role !== "admin") delete e.hourly_wage;
    const login = await db.get("SELECT id, email, role, active FROM users WHERE employee_id = ?", [e.id]);
    return { employee: e, report, login };
  }, { roles: OFFICE });
  r.post("/api/employees", async (ctx) => {
    const b = await ctx.body();
    if (!str(b.name)) throw bad("Name fehlt.");
    const id = uid();
    const row = {};
    for (const [k, f] of Object.entries(EMP)) if (b[k] !== undefined) row[k] = f(b[k]);
    if (ctx.user.role !== "admin") delete row.hourly_wage;
    row.active ??= 1;
    await db.run(`INSERT INTO employees (id, created_at, ${Object.keys(row).join(", ")}) VALUES (?, ?, ${Object.keys(row).map(() => "?").join(", ")})`, [id, nowIso(), ...Object.values(row)]);
    return { id };
  }, { roles: OFFICE });
  r.put("/api/employees/:id", async (ctx) => {
    const b = await ctx.body();
    const sets = [], vals = [];
    for (const [k, f] of Object.entries(EMP)) if (b[k] !== undefined && !(k === "hourly_wage" && ctx.user.role !== "admin")) { sets.push(`${k} = ?`); vals.push(f(b[k])); }
    if (b.name !== undefined && !str(b.name)) throw bad("Name darf nicht leer sein.");
    if (!sets.length) return { ok: true };
    const r2 = await db.run(`UPDATE employees SET ${sets.join(", ")} WHERE id = ?`, [...vals, ctx.params.id]);
    if (!r2.changes) throw notFound();
    return { ok: true };
  }, { roles: OFFICE });

  // ---------- Zeiten ----------
  const timeRow = (b) => {
    const d = day(b.day, "Tag");
    const s = time(b.start_time, "Beginn"), e = time(b.end_time, "Ende");
    if (!d || !s) throw bad("Tag und Beginn sind Pflicht.");
    const brk = Math.max(0, int(b.break_min) || 0);
    const gross = e ? minutesBetween(s, e) : 0;
    if (e && gross > 16 * 60) throw bad("Mehr als 16 Stunden an einem Stück sind nicht plausibel.");
    const minutes = e ? Math.max(0, gross - brk) : 0;
    const warn = e && brk < legalBreak(gross) ? `Hinweis: Laut Arbeitszeitgesetz sind bei ${Math.floor(gross / 60)} Std. mind. ${legalBreak(gross)} Min. Pause vorgesehen.` : null;
    return { day: d, start_time: s, end_time: e, break_min: brk, minutes, note: str(b.note, 1000), order_id: str(b.order_id, 60), warn };
  };
  r.get("/api/time", async ({ query }) => {
    const w = [], p = [];
    if (query.employee) { w.push("t.employee_id = ?"); p.push(query.employee); }
    if (query.order) { w.push("t.order_id = ?"); p.push(query.order); }
    if (query.from) { w.push("t.day >= ?"); p.push(day(query.from)); }
    if (query.to) { w.push("t.day <= ?"); p.push(day(query.to)); }
    if (query.unapproved === "1") w.push("t.approved = 0 AND t.end_time IS NOT NULL");
    const rows = await db.all(`SELECT t.*, e.name AS employee, o.number AS order_number, o.title AS order_title FROM time_entries t JOIN employees e ON e.id = t.employee_id LEFT JOIN orders o ON o.id = t.order_id ${w.length ? "WHERE " + w.join(" AND ") : ""} ORDER BY t.day DESC, t.start_time DESC LIMIT 1000`, p);
    return { rows };
  }, { roles: OFFICE });
  r.post("/api/time", async (ctx) => {
    const b = await ctx.body();
    const row = timeRow(b);
    if (!b.employee_id) throw bad("Mitarbeiter fehlt.");
    const id = uid();
    await db.run("INSERT INTO time_entries (id, employee_id, order_id, day, start_time, end_time, break_min, minutes, note, source, approved, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'buero', 1, ?)", [id, b.employee_id, row.order_id, row.day, row.start_time, row.end_time, row.break_min, row.minutes, row.note, nowIso()]);
    return { id, warn: row.warn };
  }, { roles: OFFICE });
  r.put("/api/time/:id", async (ctx) => {
    const b = await ctx.body();
    const row = timeRow(b);
    const r2 = await db.run("UPDATE time_entries SET order_id = ?, day = ?, start_time = ?, end_time = ?, break_min = ?, minutes = ?, note = ? WHERE id = ?", [row.order_id, row.day, row.start_time, row.end_time, row.break_min, row.minutes, row.note, ctx.params.id]);
    if (!r2.changes) throw notFound();
    return { ok: true, warn: row.warn };
  }, { roles: OFFICE });
  r.post("/api/time/:id/approve", async (ctx) => {
    await db.run("UPDATE time_entries SET approved = 1 WHERE id = ? AND end_time IS NOT NULL", [ctx.params.id]);
    return { ok: true };
  }, { roles: OFFICE });
  r.post("/api/time/approve-all", async (ctx) => {
    const b = await ctx.body();
    const ids = (b.ids || []).slice(0, 500);
    for (const id of ids) await db.run("UPDATE time_entries SET approved = 1 WHERE id = ? AND end_time IS NOT NULL", [id]);
    return { ok: true, count: ids.length };
  }, { roles: OFFICE });
  r.del("/api/time/:id", async ({ params }) => {
    await db.run("DELETE FROM time_entries WHERE id = ?", [params.id]);
    return { ok: true };
  }, { roles: OFFICE });

  // ---------- Abwesenheiten ----------
  const absenceConflicts = async (employeeId, from, to) =>
    db.all("SELECT o.id, o.number, o.scheduled_start FROM orders o JOIN order_staff s ON s.order_id = o.id WHERE s.employee_id = ? AND o.scheduled_start <= ? AND COALESCE(o.scheduled_end, o.scheduled_start) >= ? AND o.status NOT IN ('storniert','absage','erledigt','abgerechnet')", [employeeId, to + "T23:59", from]);
  const createAbsence = async (b, employeeId, byOffice, userName) => {
    const kind = oneOf(b.kind, Object.keys(ABSENCE), "Art");
    const from = day(b.start_date, "Von"), to = day(b.end_date || b.start_date, "Bis");
    if (!from || !to || to < from) throw bad("Bitte einen gültigen Zeitraum angeben.");
    const half = flag(b.half_day) && from === to ? 1 : 0;
    const days = half ? (workdays(from, to) ? 0.5 : 0) : workdays(from, to);
    if (kind === "urlaub" && days === 0) throw bad("Im gewählten Zeitraum liegen keine Arbeitstage (Wochenende/Feiertag).");
    const status = kind === "krank" ? "gemeldet" : byOffice ? "genehmigt" : "beantragt";
    const id = uid();
    const conflicts = await absenceConflicts(employeeId, from, to);
    await db.tx(async (t) => {
      let fileId = null;
      if (b.file && b.file.data) fileId = await storeFile(t, cfg.dataDir, { ...b.file, owner_employee_id: employeeId }, cfg.maxUploadMb * 1048576);
      await t.run("INSERT INTO absences (id, employee_id, kind, start_date, end_date, days, half_day, status, note, file_id, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [id, employeeId, kind, from, to, days, half, status, str(b.note, 1000), fileId, nowIso()]);
      if (kind !== "urlaub" || status === "genehmigt") {
        const emp = await t.get("SELECT name FROM employees WHERE id = ?", [employeeId]);
        for (const c of conflicts) await logEvent(t, c.id, "warnung", `${emp?.name || "Mitarbeiter"} fällt aus (${ABSENCE[kind]} ${from} bis ${to}) – Team prüfen!`, userName);
      }
    });
    return { id, days, status, conflicts: conflicts.map((c) => `Auftrag ${c.number} am ${c.scheduled_start.slice(0, 10)}`) };
  };
  r.get("/api/absences", async ({ query }) => {
    const w = [], p = [];
    if (query.status) { w.push("a.status = ?"); p.push(query.status); }
    if (query.employee) { w.push("a.employee_id = ?"); p.push(query.employee); }
    if (query.year) { w.push("a.start_date <= ? AND a.end_date >= ?"); p.push(`${int(query.year)}-12-31`, `${int(query.year)}-01-01`); }
    const rows = await db.all(`SELECT a.*, e.name AS employee FROM absences a JOIN employees e ON e.id = a.employee_id ${w.length ? "WHERE " + w.join(" AND ") : ""} ORDER BY a.start_date DESC LIMIT 500`, p);
    return { rows };
  }, { roles: OFFICE });
  r.post("/api/absences", async (ctx) => {
    const b = await ctx.body();
    if (!b.employee_id) throw bad("Mitarbeiter fehlt.");
    return createAbsence(b, b.employee_id, true, ctx.user.name);
  }, { roles: OFFICE, maxBody: 20_000_000 });
  r.post("/api/absences/:id/decide", async (ctx) => {
    const b = await ctx.body();
    const st = oneOf(b.status, ["genehmigt", "abgelehnt"], "Entscheidung");
    const a = await db.get("SELECT * FROM absences WHERE id = ?", [ctx.params.id]);
    if (!a) throw notFound();
    await db.run("UPDATE absences SET status = ?, decided_at = ?, decided_by = ? WHERE id = ?", [st, nowIso(), ctx.user.name, a.id]);
    return { ok: true };
  }, { roles: OFFICE });
  r.del("/api/absences/:id", async ({ params }) => {
    await db.run("DELETE FROM absences WHERE id = ?", [params.id]);
    return { ok: true };
  }, { roles: OFFICE });

  // ---------- Rückmeldungen ----------
  r.get("/api/feedback", async ({ query }) => {
    const st = query.status === "erledigt" ? "erledigt" : query.status === "alle" ? null : "offen";
    const rows = await db.all(
      `SELECT f.*, e.name AS employee, o.number AS order_number, o.title AS order_title FROM feedback f LEFT JOIN employees e ON e.id = f.employee_id LEFT JOIN orders o ON o.id = f.order_id ${st ? "WHERE f.status = ?" : ""} ORDER BY f.created_at DESC LIMIT 300`,
      st ? [st] : []
    );
    for (const f of rows) f.file_ids = f.file_ids ? JSON.parse(f.file_ids) : [];
    return { rows };
  }, { roles: OFFICE });
  r.post("/api/feedback/:id/done", async (ctx) => {
    await db.run("UPDATE feedback SET status = 'erledigt', done_at = ?, done_by = ? WHERE id = ?", [nowIso(), ctx.user.name, ctx.params.id]);
    return { ok: true };
  }, { roles: OFFICE });

  // ---------- Dateien ----------
  r.post("/api/files", async (ctx) => {
    const b = await ctx.body();
    if (b.order_id) await getOrder(b.order_id);
    const id = await db.tx((t) => storeFile(t, cfg.dataDir, { name: b.name, mime: b.mime, data: b.data, order_id: b.order_id }, cfg.maxUploadMb * 1048576));
    if (b.order_id) await db.tx((t) => logEvent(t, b.order_id, "datei", `Datei hochgeladen: ${str(b.name, 120)}`, ctx.user.name));
    return { id };
  }, { roles: OFFICE, maxBody: 20_000_000 });
  r.get("/api/files/:id", async ({ params, user }) => {
    const f = await db.get("SELECT * FROM files WHERE id = ?", [params.id]);
    if (!f) throw notFound();
    if (!OFFICE.includes(user.role)) {
      const ok = (user.employee_id && f.owner_employee_id === user.employee_id) || (f.order_id && user.employee_id && (await assigned(f.order_id, user.employee_id)));
      if (!ok) throw forbidden();
    }
    const data = await readFile(join(cfg.dataDir, f.path));
    return raw(data, {
      "content-type": f.mime,
      "content-disposition": `inline; filename*=UTF-8''${encodeURIComponent(f.name)}`,
      "cache-control": "private, max-age=3600",
      "content-security-policy": "sandbox; default-src 'none'; img-src 'self'; style-src 'unsafe-inline'",
    });
  });

  // ---------- Fahrzeuge ----------
  r.get("/api/vehicles", async () => ({ rows: await db.all("SELECT * FROM vehicles ORDER BY active DESC, name") }), { roles: OFFICE });
  const VEH = { name: (v) => str(v, 80), plate: (v) => str(v, 20), kind: (v) => str(v, 60), capacity_m3: num, active: flag, notes: (v) => str(v, 1000) };
  r.post("/api/vehicles", async (ctx) => {
    const b = await ctx.body();
    if (!str(b.name)) throw bad("Name fehlt.");
    const id = uid();
    await db.run("INSERT INTO vehicles (id, name, plate, kind, capacity_m3, active, notes) VALUES (?, ?, ?, ?, ?, ?, ?)", [id, VEH.name(b.name), VEH.plate(b.plate), VEH.kind(b.kind), num(b.capacity_m3), b.active === undefined ? 1 : flag(b.active), VEH.notes(b.notes)]);
    return { id };
  }, { roles: OFFICE });
  r.put("/api/vehicles/:id", async (ctx) => {
    const b = await ctx.body();
    const sets = [], vals = [];
    for (const [k, f] of Object.entries(VEH)) if (b[k] !== undefined) { sets.push(`${k} = ?`); vals.push(f(b[k])); }
    if (sets.length) await db.run(`UPDATE vehicles SET ${sets.join(", ")} WHERE id = ?`, [...vals, ctx.params.id]);
    return { ok: true };
  }, { roles: OFFICE });

  // ---------- Preise & Einstellungen ----------
  r.get("/api/prices", async () => ({ rows: await db.all("SELECT * FROM price_items ORDER BY sort, name") }), { roles: OFFICE });
  const PRICE = { category: (v) => str(v, 40), name: (v) => str(v, 120), unit: (v) => str(v, 20), price: num, vat_rate: num, active: flag, sort: int };
  r.post("/api/prices", async (ctx) => {
    const b = await ctx.body();
    if (!str(b.name)) throw bad("Bezeichnung fehlt.");
    const id = uid();
    await db.run("INSERT INTO price_items (id, key, category, name, unit, price, vat_rate, active, sort) VALUES (?, NULL, ?, ?, ?, ?, ?, 1, ?)", [id, PRICE.category(b.category) || "Leistungen", PRICE.name(b.name), PRICE.unit(b.unit) || "Stk.", num(b.price) || 0, num(b.vat_rate) ?? 19, int(b.sort) || 100]);
    return { id };
  }, { roles: ADMIN });
  r.put("/api/prices/:id", async (ctx) => {
    const b = await ctx.body();
    const sets = [], vals = [];
    for (const [k, f] of Object.entries(PRICE)) if (b[k] !== undefined) { sets.push(`${k} = ?`); vals.push(f(b[k]) ?? 0); }
    if (sets.length) await db.run(`UPDATE price_items SET ${sets.join(", ")} WHERE id = ?`, [...vals, ctx.params.id]);
    return { ok: true };
  }, { roles: ADMIN });
  r.del("/api/prices/:id", async ({ params }) => {
    const p = await db.get("SELECT key FROM price_items WHERE id = ?", [params.id]);
    if (p?.key) await db.run("UPDATE price_items SET active = 0 WHERE id = ?", [params.id]); // Standardposten nur deaktivieren
    else await db.run("DELETE FROM price_items WHERE id = ?", [params.id]);
    return { ok: true };
  }, { roles: ADMIN });

  r.get("/api/settings", async () => getSettings(db), { roles: OFFICE });
  r.put("/api/settings", async (ctx) => {
    const b = await ctx.body();
    for (const key of Object.keys(DEFAULT_SETTINGS)) {
      if (b[key] === undefined) continue;
      if (key === "inventory") {
        if (!Array.isArray(b.inventory)) throw bad("Umzugsgutliste ungültig.");
        await putSetting(db, key, b.inventory.slice(0, 300).map((i) => ({ room: str(i.room, 40) || "Sonstiges", name: str(i.name, 80), m3: num(i.m3) || 0 })).filter((i) => i.name));
      } else if (key === "calc") {
        const c = {};
        for (const k of Object.keys(CALC_DEFAULTS)) if (b.calc[k] !== undefined) c[k] = num(b.calc[k]) ?? CALC_DEFAULTS[k];
        await putSetting(db, key, c);
      } else if (key === "mail") {
        await putSetting(db, key, { auto_create: oneOf(b.mail.auto_create, ["alle", "erkannt", "keine"], "Postfach-Modus") });
      } else {
        const v = {};
        for (const [k, val] of Object.entries(b[key] || {})) if (k in DEFAULT_SETTINGS[key]) v[k] = str(val, 5000) ?? "";
        await putSetting(db, key, v);
      }
    }
    return getSettings(db);
  }, { roles: ADMIN });

  // ---------- Benutzer ----------
  r.get("/api/users", async () => ({ rows: await db.all("SELECT u.id, u.email, u.name, u.role, u.active, u.employee_id, u.last_login, e.name AS employee FROM users u LEFT JOIN employees e ON e.id = u.employee_id ORDER BY u.name") }), { roles: ADMIN });
  r.post("/api/users", async (ctx) => {
    const b = await ctx.body();
    const mailAddr = email(b.email);
    if (!mailAddr || !str(b.name)) throw bad("Name und E-Mail sind Pflicht.");
    const role = oneOf(b.role, Object.keys(ROLES), "Rolle");
    const p = passwordProblem(b.password);
    if (p) throw bad(p);
    if (await db.get("SELECT id FROM users WHERE lower(email) = ?", [mailAddr])) throw bad("Diese E-Mail hat bereits einen Zugang.");
    const id = uid();
    await db.run("INSERT INTO users (id, email, name, role, password_hash, employee_id, active, created_at) VALUES (?, ?, ?, ?, ?, ?, 1, ?)", [id, mailAddr, str(b.name, 120), role, await hashPassword(b.password), str(b.employee_id, 60), nowIso()]);
    return { id };
  }, { roles: ADMIN });
  r.put("/api/users/:id", async (ctx) => {
    const b = await ctx.body();
    const u = await db.get("SELECT * FROM users WHERE id = ?", [ctx.params.id]);
    if (!u) throw notFound();
    const role = b.role !== undefined ? oneOf(b.role, Object.keys(ROLES), "Rolle") : u.role;
    const active = b.active !== undefined ? flag(b.active) : u.active;
    if (u.role === "admin" && (role !== "admin" || !active)) {
      const n = await db.get("SELECT COUNT(*) AS n FROM users WHERE role = 'admin' AND active = 1");
      if ((n?.n || 0) <= 1) throw bad("Es muss mindestens ein aktiver Admin bleiben.");
    }
    await db.run("UPDATE users SET name = ?, role = ?, active = ?, employee_id = ? WHERE id = ?", [str(b.name, 120) || u.name, role, active, b.employee_id !== undefined ? str(b.employee_id, 60) : u.employee_id, u.id]);
    if (b.password) {
      const p = passwordProblem(b.password);
      if (p) throw bad(p);
      await db.run("UPDATE users SET password_hash = ? WHERE id = ?", [await hashPassword(b.password), u.id]);
      await db.run("DELETE FROM sessions WHERE user_id = ?", [u.id]);
    }
    if (!active) await db.run("DELETE FROM sessions WHERE user_id = ?", [u.id]);
    return { ok: true };
  }, { roles: ADMIN });

  // ---------- Postfach ----------
  r.get("/api/mail", async ({ query }) => {
    const st = ["offen", "angelegt", "zugeordnet", "ignoriert"].includes(query.status) ? query.status : null;
    const rows = await db.all(`SELECT m.id, m.source, m.from_addr, m.subject, m.received_at, m.status, m.order_id, o.number AS order_number FROM mail_log m LEFT JOIN orders o ON o.id = m.order_id ${st ? "WHERE m.status = ?" : ""} ORDER BY m.received_at DESC LIMIT 200`, st ? [st] : []);
    return { rows, status: mail.status() };
  }, { roles: OFFICE });
  r.get("/api/mail/:id", async ({ params }) => {
    const m = await db.get("SELECT * FROM mail_log WHERE id = ?", [params.id]);
    if (!m) throw notFound();
    return m;
  }, { roles: OFFICE });
  r.post("/api/mail/fetch", async () => mail.runFetch(), { roles: OFFICE });
  r.post("/api/mail/:id/create-order", async (ctx) => {
    const m = await db.get("SELECT * FROM mail_log WHERE id = ?", [ctx.params.id]);
    if (!m) throw notFound();
    const fm = String(m.from_addr || "").match(/^(.*?)\s*<([^>]*)>$/);
    const res = await mail.ingest({ source: m.source, messageId: m.message_id, subject: m.subject, text: m.body, fromName: fm ? fm[1] : "", fromEmail: fm ? fm[2] : "", date: m.received_at }, { force: true, userName: ctx.user.name });
    if (!res.orderId) throw bad("Aus dieser Mail konnte kein Auftrag angelegt werden (keine Absender-Adresse).");
    return res;
  }, { roles: OFFICE });
  r.post("/api/mail/:id/ignore", async ({ params }) => {
    await db.run("UPDATE mail_log SET status = 'ignoriert' WHERE id = ?", [params.id]);
    return { ok: true };
  }, { roles: OFFICE });

  // ---------- Export & Sicherung ----------
  r.get("/api/export/time.csv", async ({ query }) => {
    const from = day(query.from) || monthRange(...nowLocal().day.split("-").slice(0, 2).map(Number))[0];
    const to = day(query.to) || nowLocal().day;
    const rows = await db.all("SELECT t.day, e.name, t.start_time, t.end_time, t.break_min, t.minutes, o.number, o.title, t.note, t.approved, t.source FROM time_entries t JOIN employees e ON e.id = t.employee_id LEFT JOIN orders o ON o.id = t.order_id WHERE t.day BETWEEN ? AND ? ORDER BY e.name, t.day, t.start_time", [from, to]);
    const body = csv([["Datum", "Mitarbeiter", "Beginn", "Ende", "Pause (Min.)", "Arbeitszeit (Std.)", "Auftrag", "Auftragstitel", "Notiz", "Freigegeben", "Quelle"], ...rows.map((x) => [x.day, x.name, x.start_time, x.end_time, x.break_min, round2(x.minutes / 60), x.number, x.title, x.note, x.approved ? "ja" : "nein", x.source])]);
    return raw(body, { "content-type": "text/csv; charset=utf-8", "content-disposition": `attachment; filename="zeiten_${from}_${to}.csv"` });
  }, { roles: OFFICE });
  r.get("/api/export/orders.csv", async () => {
    const rows = await db.all("SELECT o.number, o.created_at, o.kind, o.status, c.name, c.email, c.phone, o.from_address, o.to_address, o.desired_date, o.scheduled_start, o.volume_m3, (SELECT gross FROM offers f WHERE f.order_id = o.id ORDER BY f.created_at DESC LIMIT 1) AS gross, o.source FROM orders o LEFT JOIN customers c ON c.id = o.customer_id ORDER BY o.created_at DESC");
    const body = csv([["Nummer", "Angelegt", "Art", "Status", "Kunde", "E-Mail", "Telefon", "Von", "Nach", "Wunschtermin", "Termin", "Volumen m³", "Angebot brutto", "Quelle"], ...rows.map((x) => [x.number, x.created_at.slice(0, 10), KINDS[x.kind] || x.kind, STATUS[x.status]?.label || x.status, x.name, x.email, x.phone, x.from_address, x.to_address, x.desired_date, x.scheduled_start, x.volume_m3, x.gross, x.source])]);
    return raw(body, { "content-type": "text/csv; charset=utf-8", "content-disposition": 'attachment; filename="auftraege.csv"' });
  }, { roles: OFFICE });
  r.get("/api/backup", async () => {
    if (db.kind !== "sqlite") throw bad("Sicherung bei Postgres bitte mit pg_dump (siehe README).");
    const file = join(tmpdir(), `movaris-backup-${Date.now()}.db`);
    await db.backup(file);
    const data = await readFile(file);
    await unlink(file).catch(() => {});
    return raw(data, { "content-type": "application/octet-stream", "content-disposition": `attachment; filename="movaris-sicherung-${nowLocal().day}.db"` });
  }, { roles: ADMIN });

  // =================== Mitarbeiter-App ===================
  const jobSelect = "SELECT o.id, o.number, o.title, o.kind, o.status, o.scheduled_start, o.scheduled_end, o.from_address, o.from_floor, o.from_elevator, o.to_address, o.to_floor, o.to_elevator, o.volume_m3, o.notes, o.special_wishes, c.name AS customer, c.phone AS customer_phone FROM orders o JOIN order_staff s ON s.order_id = o.id LEFT JOIN customers c ON c.id = o.customer_id";
  r.get("/api/my/overview", async ({ user }) => {
    const e = await myEmployee(user);
    const now = nowLocal();
    const [y, m] = [Number(now.day.slice(0, 4)), Number(now.day.slice(5, 7))];
    const rep = await employeeReport(db, e, y, m);
    const open = await db.get("SELECT t.*, o.number AS order_number FROM time_entries t LEFT JOIN orders o ON o.id = t.order_id WHERE t.employee_id = ? AND t.end_time IS NULL ORDER BY t.created_at DESC LIMIT 1", [e.id]);
    const jobs = await db.all(`${jobSelect} WHERE s.employee_id = ? AND o.scheduled_start IS NOT NULL AND COALESCE(o.scheduled_end, o.scheduled_start) >= ? AND o.scheduled_start <= ? AND o.status NOT IN ('storniert','absage') ORDER BY o.scheduled_start LIMIT 30`, [e.id, now.day, addDays(now.day, 14) + "T23:59"]);
    const absences = await db.all("SELECT * FROM absences WHERE employee_id = ? AND end_date >= ? ORDER BY start_date LIMIT 10", [e.id, now.day]);
    return { employee: { id: e.id, name: e.name }, now, open_entry: open || null, jobs, month: rep.month && { target_min: rep.month.target_min, actual_min: rep.month.actual_min, overtime_min: rep.month.overtime_min }, year: rep.year, absences };
  });
  r.get("/api/my/jobs/:id", async ({ params, user }) => {
    const e = await myEmployee(user);
    const job = await db.get(`${jobSelect} WHERE s.employee_id = ? AND o.id = ?`, [e.id, params.id]);
    if (!job) throw notFound("Auftrag nicht gefunden oder nicht zugeteilt.");
    job.team = await db.all("SELECT e.name, e.phone, s.lead FROM order_staff s JOIN employees e ON e.id = s.employee_id WHERE s.order_id = ? ORDER BY s.lead DESC, e.name", [job.id]);
    job.vehicles = await db.all("SELECT v.name, v.plate FROM order_vehicles x JOIN vehicles v ON v.id = x.vehicle_id WHERE x.order_id = ?", [job.id]);
    job.my_time = await db.all("SELECT * FROM time_entries WHERE order_id = ? AND employee_id = ? ORDER BY day, start_time", [job.id, e.id]);
    job.feedback = await db.all("SELECT kind, text, status, created_at, file_ids FROM feedback WHERE order_id = ? AND employee_id = ? ORDER BY created_at DESC", [job.id, e.id]);
    job.files = await db.all("SELECT id, name, mime FROM files WHERE order_id = ? AND mime LIKE 'image/%' ORDER BY created_at DESC LIMIT 30", [job.id]);
    return job;
  });
  r.get("/api/my/jobs", async ({ user, query }) => {
    const e = await myEmployee(user);
    const today = nowLocal().day;
    const past = query.scope === "past";
    const rows = await db.all(`${jobSelect} WHERE s.employee_id = ? AND o.scheduled_start IS NOT NULL AND ${past ? "o.scheduled_start < ?" : "COALESCE(o.scheduled_end, o.scheduled_start) >= ?"} AND o.status NOT IN ('storniert','absage') ORDER BY o.scheduled_start ${past ? "DESC" : ""} LIMIT 60`, [e.id, today]);
    return { rows };
  });
  r.post("/api/my/clock", async (ctx) => {
    const e = await myEmployee(ctx.user);
    const b = await ctx.body();
    const now = nowLocal();
    const open = await db.get("SELECT * FROM time_entries WHERE employee_id = ? AND end_time IS NULL ORDER BY created_at DESC LIMIT 1", [e.id]);
    if (b.action === "start") {
      if (open) throw bad("Es läuft bereits eine Zeiterfassung. Bitte zuerst beenden.");
      const orderId = str(b.order_id, 60);
      if (orderId && !(await assigned(orderId, e.id))) throw forbidden("Dieser Auftrag ist Ihnen nicht zugeteilt.");
      const id = uid();
      await db.tx(async (t) => {
        await t.run("INSERT INTO time_entries (id, employee_id, order_id, day, start_time, end_time, break_min, minutes, source, approved, created_at) VALUES (?, ?, ?, ?, ?, NULL, 0, 0, 'app', 0, ?)", [id, e.id, orderId, now.day, now.time, nowIso()]);
        if (orderId) {
          const o = await t.get("SELECT * FROM orders WHERE id = ?", [orderId]);
          if (o && ["zuschlag", "geplant"].includes(o.status)) await setStatus(t, o, "in_durchfuehrung", e.name);
        }
      });
      return { ok: true, id, start: now.time };
    }
    if (b.action === "stop") {
      if (!open) throw bad("Es läuft keine Zeiterfassung.");
      const gross = minutesBetween(open.start_time, now.time);
      const brk = b.break_min !== undefined && b.break_min !== null && b.break_min !== "" ? Math.max(0, int(b.break_min)) : legalBreak(gross);
      await db.run("UPDATE time_entries SET end_time = ?, break_min = ?, minutes = ?, note = COALESCE(?, note) WHERE id = ?", [now.time, brk, Math.max(0, gross - brk), str(b.note, 1000), open.id]);
      return { ok: true, minutes: Math.max(0, gross - brk), break_min: brk };
    }
    throw bad("Unbekannte Aktion.");
  });
  r.get("/api/my/time", async ({ user, query }) => {
    const e = await myEmployee(user);
    const mo = /^\d{4}-\d{2}$/.test(query.month || "") ? query.month : nowLocal().day.slice(0, 7);
    const rep = await employeeReport(db, e, Number(mo.slice(0, 4)), Number(mo.slice(5, 7)));
    return { month: mo, ...rep.month, year: rep.year };
  });
  r.post("/api/my/time", async (ctx) => {
    const e = await myEmployee(ctx.user);
    const b = await ctx.body();
    const row = timeRow(b);
    if (!row.end_time) throw bad("Bitte Beginn und Ende angeben.");
    if (row.order_id && !(await assigned(row.order_id, e.id))) throw forbidden("Dieser Auftrag ist Ihnen nicht zugeteilt.");
    if (row.day > nowLocal().day) throw bad("Zeiten in der Zukunft können nicht erfasst werden.");
    const id = uid();
    await db.run("INSERT INTO time_entries (id, employee_id, order_id, day, start_time, end_time, break_min, minutes, note, source, approved, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'app', 0, ?)", [id, e.id, row.order_id, row.day, row.start_time, row.end_time, row.break_min, row.minutes, row.note, nowIso()]);
    return { id, warn: row.warn, minutes: row.minutes };
  });
  r.del("/api/my/time/:id", async ({ user, params }) => {
    const e = await myEmployee(user);
    const r2 = await db.run("DELETE FROM time_entries WHERE id = ? AND employee_id = ? AND approved = 0", [params.id, e.id]);
    if (!r2.changes) throw bad("Freigegebene Einträge kann nur das Büro ändern.");
    return { ok: true };
  });
  r.get("/api/my/absences", async ({ user }) => {
    const e = await myEmployee(user);
    const y = Number(nowLocal().day.slice(0, 4));
    const rep = await employeeReport(db, e, y, 1);
    return { rows: await db.all("SELECT * FROM absences WHERE employee_id = ? ORDER BY start_date DESC LIMIT 100", [e.id]), year: rep.year };
  });
  r.post("/api/my/absences", async (ctx) => {
    const e = await myEmployee(ctx.user);
    const b = await ctx.body();
    if (b.kind === "urlaub" && day(b.start_date) < nowLocal().day) throw bad("Urlaub kann nicht rückwirkend beantragt werden.");
    return createAbsence(b, e.id, false, e.name);
  }, { maxBody: 20_000_000 });
  r.post("/api/my/absences/:id/cancel", async ({ user, params }) => {
    const e = await myEmployee(user);
    const r2 = await db.run("DELETE FROM absences WHERE id = ? AND employee_id = ? AND status = 'beantragt'", [params.id, e.id]);
    if (!r2.changes) throw bad("Nur offene Anträge können zurückgezogen werden.");
    return { ok: true };
  });
  r.post("/api/my/feedback", async (ctx) => {
    const e = await myEmployee(ctx.user);
    const b = await ctx.body();
    const kind = oneOf(b.kind, Object.keys(FEEDBACK), "Art");
    const orderId = str(b.order_id, 60);
    if (!orderId || !(await assigned(orderId, e.id))) throw forbidden("Dieser Auftrag ist Ihnen nicht zugeteilt.");
    const text = str(b.text, 4000);
    if (!text && kind !== "abschluss" && !(b.files || []).length) throw bad("Bitte eine Beschreibung oder ein Foto hinzufügen.");
    const id = uid();
    await db.tx(async (t) => {
      const fileIds = [];
      for (const f of (b.files || []).slice(0, 8)) fileIds.push(await storeFile(t, cfg.dataDir, { ...f, order_id: orderId, owner_employee_id: e.id }, cfg.maxUploadMb * 1048576));
      await t.run("INSERT INTO feedback (id, order_id, employee_id, kind, text, file_ids, status, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)", [id, orderId, e.id, kind, text, JSON.stringify(fileIds), kind === "info" ? "erledigt" : "offen", nowIso()]);
      await logEvent(t, orderId, "rueckmeldung", `${FEEDBACK[kind]}: ${text || "(ohne Text)"}${fileIds.length ? ` · ${fileIds.length} Foto(s)` : ""}`, e.name);
      if (kind === "sonderwunsch") {
        const cur = await t.get("SELECT special_wishes FROM orders WHERE id = ?", [orderId]);
        await t.run("UPDATE orders SET special_wishes = ? WHERE id = ? ", [[cur?.special_wishes, `• ${text} (${e.name}, ${nowLocal().day})`].filter(Boolean).join("\n").slice(0, 5000), orderId]);
      }
      if (kind === "abschluss") {
        const o = await t.get("SELECT * FROM orders WHERE id = ?", [orderId]);
        if (o && ["zuschlag", "geplant", "in_durchfuehrung"].includes(o.status)) await setStatus(t, o, "erledigt", e.name);
      }
    });
    return { id };
  }, { maxBody: 40_000_000 });
}
