// Anwendung zusammenbauen: Datenbank, Routen, Sicherheit, Postfach-Abruf.
import { fileURLToPath } from "node:url";
import { createRouter, staticServer, send, readJson, HttpError, SECURITY_HEADERS, limiter } from "./http.js";
import { readCookie, sessionUser } from "./auth.js";
import { migrate } from "./schema.js";
import { seed } from "./services.js";
import { registerRoutes } from "./api.js";
import { registerPublic } from "./public-routes.js";
import { createMailService } from "./mailservice.js";

const PUBLIC_DIR = fileURLToPath(new URL("../public/", import.meta.url));

export async function createApp({ db, cfg, log = console }) {
  await migrate(db);
  await seed(db);
  const r = createRouter();
  const serve = staticServer(PUBLIC_DIR);
  const mail = createMailService({ db, cfg, log });
  const deps = { db, cfg, mail, log, limits: { login: limiter(10, 15 * 60e3), inquiry: limiter(10, 60 * 60e3), offer: limiter(20, 60 * 60e3) } };
  registerRoutes(r, deps);
  registerPublic(r, deps);

  async function handler(req, res) {
    const url = new URL(req.url, "http://localhost");
    const pathname = url.pathname;
    const ip = (cfg.trustProxy && String(req.headers["x-forwarded-for"] || "").split(",")[0].trim()) || req.socket.remoteAddress || "?";
    try {
      const m = r.match(req.method === "HEAD" ? "GET" : req.method, pathname);
      if (req.method === "OPTIONS" && pathname === "/api/public/inquiry") {
        const origin = req.headers.origin || "";
        const ok = cfg.inquiryOrigins.includes(origin);
        res.writeHead(204, ok ? { "access-control-allow-origin": origin, "access-control-allow-methods": "POST", "access-control-allow-headers": "content-type, x-inquiry-key", "access-control-max-age": "600", vary: "origin" } : {});
        return res.end();
      }
      if (m && m.methodNotAllowed) throw new HttpError(405, "Methode nicht erlaubt.");
      if (!m) {
        if (pathname.startsWith("/api/")) throw new HttpError(404, "Nicht gefunden.");
        if (req.method !== "GET" && req.method !== "HEAD") throw new HttpError(405, "Methode nicht erlaubt.");
        if (await serve(req, res, pathname)) return;
        // SPA-Fallback
        if (pathname.startsWith("/m/") || pathname === "/m") return void (await serve(req, res, "/m/index.html"));
        if (!pathname.includes(".")) return void (await serve(req, res, "/index.html"));
        throw new HttpError(404, "Nicht gefunden.");
      }
      const { route, params } = m;
      const opts = route.opts;
      // CSRF-Schutz: schreibende API-Aufrufe brauchen den eigenen Header (Browser senden ihn nicht seitenübergreifend)
      if (pathname.startsWith("/api/") && req.method !== "GET" && !opts.public && req.headers["x-mv"] !== "1") {
        throw new HttpError(403, "Ungültige Anfrage.");
      }
      let user = null;
      if (!opts.public) {
        user = await sessionUser(db, readCookie(req));
        if (opts.auth !== false && !user) throw new HttpError(401, "Bitte anmelden.");
        if (opts.roles && user && !opts.roles.includes(user.role)) throw new HttpError(403, "Keine Berechtigung.");
      }
      let bodyCache;
      const ctx = {
        req,
        res,
        url,
        params,
        query: Object.fromEntries(url.searchParams),
        user,
        ip,
        body: async () => (bodyCache ??= await readJson(req, opts.maxBody || 1_000_000)),
      };
      const out = await route.handler(ctx);
      if (res.headersSent || res.writableEnded) return;
      if (out === undefined) return send(res, 204, "");
      if (out && out.__raw) return send(res, out.status || 200, out.body, out.headers || {});
      return send(res, 200, out);
    } catch (e) {
      if (res.headersSent) return res.end();
      const status = e instanceof HttpError ? e.status : 500;
      if (status === 500) log.error?.("Fehler", req.method, pathname, e);
      const msg = status === 500 ? "Interner Fehler. Bitte erneut versuchen." : e.message;
      if (pathname.startsWith("/api/")) return send(res, status, { error: msg, ...(e.extra || {}) });
      res.writeHead(status, { ...SECURITY_HEADERS, "content-type": "text/plain; charset=utf-8" });
      res.end(msg);
    }
  }
  return { handler, mail, db };
}
