// Passwörter (scrypt) und Sitzungen (zufälliges Token, in der DB nur als SHA-256 gespeichert).
import { scrypt, randomBytes, timingSafeEqual, createHash, randomUUID } from "node:crypto";
import { promisify } from "node:util";

const scryptAsync = promisify(scrypt);
const N = 16384;

export async function hashPassword(pw) {
  const salt = randomBytes(16);
  const key = await scryptAsync(String(pw), salt, 64, { N, r: 8, p: 1 });
  return `scrypt$${N}$${salt.toString("base64")}$${key.toString("base64")}`;
}
export async function verifyPassword(pw, stored) {
  try {
    const [, n, saltB64, keyB64] = String(stored).split("$");
    const key = Buffer.from(keyB64, "base64");
    const test = await scryptAsync(String(pw), Buffer.from(saltB64, "base64"), key.length, { N: Number(n), r: 8, p: 1 });
    return timingSafeEqual(key, test);
  } catch {
    return false;
  }
}
export const passwordProblem = (pw) =>
  !pw || String(pw).length < 10 ? "Das Passwort braucht mindestens 10 Zeichen." : null;

const sha = (s) => createHash("sha256").update(s).digest("hex");
export const sessionHash = (token) => sha(token || "");
export const SESSION_DAYS = 30;
export const COOKIE = "mv_sid";

export async function createSession(db, userId) {
  const token = randomBytes(32).toString("base64url");
  const now = new Date();
  const exp = new Date(now.getTime() + SESSION_DAYS * 864e5);
  await db.run("INSERT INTO sessions (id, user_id, expires_at, created_at) VALUES (?, ?, ?, ?)", [sha(token), userId, exp.toISOString(), now.toISOString()]);
  return { token, expires: exp };
}
export async function sessionUser(db, token) {
  if (!token || token.length > 100) return null;
  const row = await db.get(
    "SELECT u.id, u.email, u.name, u.role, u.employee_id, u.active, s.expires_at FROM sessions s JOIN users u ON u.id = s.user_id WHERE s.id = ?",
    [sha(token)]
  );
  if (!row || !row.active || row.expires_at < new Date().toISOString()) return null;
  return { id: row.id, email: row.email, name: row.name, role: row.role, employee_id: row.employee_id };
}
export const destroySession = (db, token) => db.run("DELETE FROM sessions WHERE id = ?", [sha(token || "")]);
export const cookieHeader = (token, expires, secure) =>
  `${COOKIE}=${token}; Path=/; HttpOnly; SameSite=Lax; Expires=${expires.toUTCString()}${secure ? "; Secure" : ""}`;
export const clearCookie = (secure) => `${COOKIE}=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0${secure ? "; Secure" : ""}`;
export const readCookie = (req) => {
  const m = (req.headers.cookie || "").match(new RegExp(`(?:^|;\\s*)${COOKIE}=([^;]+)`));
  return m ? m[1] : null;
};
export const uid = () => randomUUID();
export const token32 = () => randomBytes(24).toString("base64url");
