// Konfiguration aus Umgebungsvariablen (.env wird beim Start eingelesen, siehe README).
import { readFileSync, existsSync } from "node:fs";

export function loadEnvFile(file = ".env") {
  if (!existsSync(file)) return;
  for (const line of readFileSync(file, "utf8").split(/\r?\n/)) {
    const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/);
    if (!m || process.env[m[1]] !== undefined) continue;
    let v = m[2];
    if ((v.startsWith('"') && v.endsWith('"')) || (v.startsWith("'") && v.endsWith("'"))) v = v.slice(1, -1);
    process.env[m[1]] = v;
  }
}

const bool = (v, d = false) => (v === undefined || v === "" ? d : /^(1|true|ja|yes|on)$/i.test(v));
const int = (v, d) => (v === undefined || v === "" || isNaN(Number(v)) ? d : Number(v));

export function config(env = process.env) {
  return {
    port: int(env.PORT, 8080),
    host: env.HOST || "0.0.0.0",
    databaseUrl: env.DATABASE_URL || "sqlite:./data/movaris.db",
    dataDir: env.DATA_DIR || "./data",
    publicUrl: (env.PUBLIC_URL || "").replace(/\/$/, ""),
    secureCookies: bool(env.SECURE_COOKIES, (env.PUBLIC_URL || "").startsWith("https://")),
    trustProxy: bool(env.TRUST_PROXY, false),
    inquiryKey: env.INQUIRY_KEY || "",
    inquiryOrigins: (env.INQUIRY_ORIGINS || "").split(",").map((s) => s.trim()).filter(Boolean),
    mailPollMinutes: int(env.MAIL_POLL_MINUTES, 5),
    imap: {
      host: env.IMAP_HOST || "",
      port: int(env.IMAP_PORT, 993),
      secure: bool(env.IMAP_SECURE, true),
      user: env.IMAP_USER || "",
      pass: env.IMAP_PASS || "",
      folder: env.IMAP_FOLDER || "INBOX",
      doneFolder: env.IMAP_DONE_FOLDER || "",
    },
    smtp: {
      host: env.SMTP_HOST || "",
      port: int(env.SMTP_PORT, 587),
      secure: bool(env.SMTP_SECURE, false),
      user: env.SMTP_USER || "",
      pass: env.SMTP_PASS || "",
      from: env.SMTP_FROM || env.SMTP_USER || "",
    },
    agentmail: {
      key: env.AGENTMAIL_API_KEY || "",
      inbox: env.AGENTMAIL_INBOX_ID || "",
      base: env.AGENTMAIL_BASE || "https://api.agentmail.to/v0",
    },
    officeNotify: env.OFFICE_NOTIFY_EMAIL || "",
    maxUploadMb: int(env.MAX_UPLOAD_MB, 12),
  };
}
