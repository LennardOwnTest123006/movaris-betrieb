// Datenbank-Adapter: SQLite (eingebaut in Node 22, Datei lokal) oder PostgreSQL (private Cloud).
// Einheitliche Schnittstelle: all/get/run/tx. SQL wird mit "?" geschrieben; für Postgres in $1.. umgewandelt.
import { mkdirSync } from "node:fs";
import { dirname } from "node:path";

const toPg = (sql) => {
  let i = 0;
  return sql.replace(/\?/g, () => "$" + ++i);
};
const norm = (p) => (p || []).map((v) => (v === undefined ? null : typeof v === "boolean" ? (v ? 1 : 0) : v));

// Einfache Sperre, damit SQLite-Transaktionen nicht mit anderen Schreibzugriffen verschachtelt werden.
function lock() {
  let last = Promise.resolve();
  return (fn) => {
    const run = last.then(fn, fn);
    last = run.catch(() => {});
    return run;
  };
}

export async function openSqlite(file) {
  const { DatabaseSync } = await import("node:sqlite");
  if (file !== ":memory:") mkdirSync(dirname(file), { recursive: true });
  const db = new DatabaseSync(file);
  db.exec("PRAGMA journal_mode=WAL; PRAGMA synchronous=NORMAL; PRAGMA foreign_keys=ON; PRAGMA busy_timeout=5000; PRAGMA cache_size=-16000;");
  const cache = new Map();
  const stmt = (sql) => {
    let s = cache.get(sql);
    if (!s) {
      s = db.prepare(sql);
      if (cache.size > 400) cache.clear();
      cache.set(sql, s);
    }
    return s;
  };
  const plain = (r) => (r ? { ...r } : r);
  const raw = {
    all: async (sql, p) => stmt(sql).all(...norm(p)).map(plain),
    get: async (sql, p) => plain(stmt(sql).get(...norm(p))),
    run: async (sql, p) => {
      const r = stmt(sql).run(...norm(p));
      return { changes: Number(r.changes) };
    },
    exec: async (sql) => db.exec(sql),
  };
  const guard = lock();
  return {
    kind: "sqlite",
    all: raw.all,
    get: raw.get,
    exec: raw.exec,
    run: (sql, p) => guard(() => raw.run(sql, p)),
    tx: (fn) =>
      guard(async () => {
        db.exec("BEGIN IMMEDIATE");
        try {
          const out = await fn(raw);
          db.exec("COMMIT");
          return out;
        } catch (e) {
          db.exec("ROLLBACK");
          throw e;
        }
      }),
    backup: async (target) => {
      db.exec(`VACUUM INTO '${String(target).replace(/'/g, "''")}'`);
    },
    close: async () => db.close(),
  };
}

// query(sql, params) -> {rows, rowCount}; bei Postgres ein pg.Pool, im Test auch PGlite.
export function pgAdapter(queryFn, connectFn, closeFn) {
  const wrap = (q) => ({
    all: async (sql, p) => (await q(toPg(sql), norm(p))).rows,
    get: async (sql, p) => (await q(toPg(sql), norm(p))).rows[0],
    run: async (sql, p) => ({ changes: (await q(toPg(sql), norm(p))).rowCount ?? 0 }),
    exec: async (sql) => {
      for (const part of sql.split(";").map((s) => s.trim()).filter(Boolean)) await q(part, []);
    },
  });
  const base = wrap(queryFn);
  return {
    kind: "postgres",
    ...base,
    tx: async (fn) => {
      const { query, release } = await connectFn();
      const t = wrap(query);
      await query("BEGIN", []);
      try {
        const out = await fn(t);
        await query("COMMIT", []);
        return out;
      } catch (e) {
        await query("ROLLBACK", []);
        throw e;
      } finally {
        release();
      }
    },
    backup: async () => {
      throw new Error("Backup bei Postgres bitte mit pg_dump (siehe README).");
    },
    close: closeFn,
  };
}

export async function openPostgres(url) {
  const pg = (await import("pg")).default;
  pg.types.setTypeParser(20, (v) => parseInt(v, 10)); // bigint (COUNT/SUM)
  pg.types.setTypeParser(1700, (v) => parseFloat(v)); // numeric
  const pool = new pg.Pool({ connectionString: url, max: 10, idleTimeoutMillis: 30000 });
  return pgAdapter(
    (sql, p) => pool.query(sql, p),
    async () => {
      const c = await pool.connect();
      return { query: (sql, p) => c.query(sql, p), release: () => c.release() };
    },
    () => pool.end()
  );
}

export async function openDb(url) {
  if (url && /^postgres(ql)?:\/\//.test(url)) return openPostgres(url);
  const file = !url ? "./data/movaris.db" : url.replace(/^sqlite:(\/\/)?/, "");
  return openSqlite(file);
}
