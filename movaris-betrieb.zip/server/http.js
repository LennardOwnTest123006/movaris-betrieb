// Kleiner HTTP-Baukasten ohne Framework: Router, JSON, Sicherheits-Header, statische Dateien mit gzip + ETag.
import { readFile, stat } from "node:fs/promises";
import { createHash } from "node:crypto";
import { gzipSync } from "node:zlib";
import { join, normalize, extname } from "node:path";

export class HttpError extends Error {
  constructor(status, message, extra) {
    super(message);
    this.status = status;
    this.extra = extra;
  }
}
export const bad = (m, extra) => new HttpError(400, m, extra);
export const forbidden = (m = "Keine Berechtigung.") => new HttpError(403, m);
export const notFound = (m = "Nicht gefunden.") => new HttpError(404, m);

export const SECURITY_HEADERS = {
  "x-content-type-options": "nosniff",
  "referrer-policy": "same-origin",
  "x-frame-options": "DENY",
  "permissions-policy": "camera=(self), microphone=(), geolocation=(self)",
  "content-security-policy":
    "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data: blob:; connect-src 'self'; font-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'",
};

export function send(res, status, body, headers = {}) {
  const isBuf = Buffer.isBuffer(body);
  const data = isBuf || typeof body === "string" ? body : JSON.stringify(body);
  res.writeHead(status, {
    ...SECURITY_HEADERS,
    "content-type": isBuf ? "application/octet-stream" : typeof body === "string" ? "text/html; charset=utf-8" : "application/json; charset=utf-8",
    "cache-control": "no-store",
    ...headers,
  });
  res.end(data);
}

export async function readJson(req, limit = 1_000_000) {
  const ct = req.headers["content-type"] || "";
  const chunks = [];
  let size = 0;
  for await (const c of req) {
    size += c.length;
    if (size > limit) throw new HttpError(413, "Anfrage zu groß.");
    chunks.push(c);
  }
  const raw = Buffer.concat(chunks).toString("utf8");
  if (!raw) return {};
  if (ct.includes("application/x-www-form-urlencoded")) return Object.fromEntries(new URLSearchParams(raw));
  try {
    return JSON.parse(raw);
  } catch {
    throw bad("Ungültige Daten.");
  }
}

export function createRouter() {
  const routes = [];
  const add = (method, path, handler, opts = {}) => {
    const keys = [];
    const re = new RegExp("^" + path.replace(/\/:(\w+)/g, (_, k) => (keys.push(k), "/([^/]+)")) + "/?$");
    routes.push({ method, re, keys, handler, opts });
  };
  const match = (method, pathname) => {
    let allowed = false;
    for (const r of routes) {
      const m = pathname.match(r.re);
      if (!m) continue;
      if (r.method !== method) {
        allowed = true;
        continue;
      }
      const params = {};
      r.keys.forEach((k, i) => (params[k] = decodeURIComponent(m[i + 1])));
      return { route: r, params };
    }
    return allowed ? { methodNotAllowed: true } : null;
  };
  return {
    get: (p, h, o) => add("GET", p, h, o),
    post: (p, h, o) => add("POST", p, h, o),
    put: (p, h, o) => add("PUT", p, h, o),
    del: (p, h, o) => add("DELETE", p, h, o),
    match,
  };
}

const MIME = {
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".webmanifest": "application/manifest+json",
  ".svg": "image/svg+xml",
  ".png": "image/png",
  ".ico": "image/x-icon",
  ".webp": "image/webp",
};
const fileCache = new Map();

export function staticServer(root) {
  return async function serve(req, res, pathname) {
    let p = pathname.endsWith("/") ? pathname + "index.html" : pathname;
    const full = normalize(join(root, p));
    if (!full.startsWith(normalize(root))) return false;
    let st;
    try {
      st = await stat(full);
      if (st.isDirectory()) return false;
    } catch {
      return false;
    }
    const key = full + ":" + st.mtimeMs;
    let entry = fileCache.get(key);
    if (!entry) {
      const data = await readFile(full);
      const type = MIME[extname(full)] || "application/octet-stream";
      const compressible = /text|javascript|json|svg|manifest/.test(type) && data.length > 1024;
      entry = { data, gz: compressible ? gzipSync(data, { level: 9 }) : null, type, etag: '"' + createHash("sha1").update(data).digest("base64url").slice(0, 20) + '"' };
      fileCache.set(key, entry);
    }
    const headers = {
      ...SECURITY_HEADERS,
      "content-type": entry.type,
      etag: entry.etag,
      "cache-control": /\.(html|webmanifest)$/.test(full) || full.endsWith("sw.js") ? "no-cache" : "public, max-age=300, must-revalidate",
      vary: "accept-encoding",
    };
    if (req.headers["if-none-match"] === entry.etag) {
      res.writeHead(304, headers);
      res.end();
      return true;
    }
    if (entry.gz && /\bgzip\b/.test(req.headers["accept-encoding"] || "")) {
      res.writeHead(200, { ...headers, "content-encoding": "gzip" });
      res.end(entry.gz);
    } else {
      res.writeHead(200, headers);
      res.end(entry.data);
    }
    return true;
  };
}

// Einfache Begrenzung von Anfragen (z. B. Login, öffentliches Formular)
export function limiter(limit, windowMs) {
  const hits = new Map();
  return (key) => {
    const now = Date.now();
    const arr = (hits.get(key) || []).filter((t) => now - t < windowMs);
    if (arr.length >= limit) {
      hits.set(key, arr);
      return false;
    }
    arr.push(now);
    hits.set(key, arr);
    if (hits.size > 10000) hits.clear();
    return true;
  };
}
