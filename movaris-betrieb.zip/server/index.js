// Startpunkt: node server/index.js  (Konfiguration über .env, siehe README)
import { createServer } from "node:http";
import { loadEnvFile, config } from "./config.js";
import { openDb } from "./db.js";
import { createApp } from "./app.js";
import { hashPassword, uid } from "./auth.js";

loadEnvFile(process.env.ENV_FILE || ".env");
const cfg = config();
const db = await openDb(cfg.databaseUrl);
const app = await createApp({ db, cfg });

// Optional: ersten Admin über Umgebungsvariablen anlegen (z. B. bei automatischer Installation)
if (process.env.ADMIN_EMAIL && process.env.ADMIN_PASSWORD) {
  const n = await db.get("SELECT COUNT(*) AS n FROM users");
  if (!n || !n.n) {
    await db.run("INSERT INTO users (id, email, name, role, password_hash, active, created_at) VALUES (?, ?, ?, 'admin', ?, 1, ?)", [uid(), process.env.ADMIN_EMAIL.toLowerCase(), process.env.ADMIN_NAME || "Admin", await hashPassword(process.env.ADMIN_PASSWORD), new Date().toISOString()]);
    console.log("Admin-Zugang angelegt:", process.env.ADMIN_EMAIL);
  }
}

const server = createServer({ requestTimeout: 120000, headersTimeout: 30000 }, app.handler);
server.keepAliveTimeout = 30000;
server.listen(cfg.port, cfg.host, () => {
  console.log(`MOVARIS Betrieb läuft auf http://${cfg.host === "0.0.0.0" ? "localhost" : cfg.host}:${cfg.port}  (Datenbank: ${db.kind})`);
  app.mail.start();
});
const shutdown = async () => {
  app.mail.stop();
  server.close();
  await db.close?.();
  process.exit(0);
};
process.on("SIGTERM", shutdown);
process.on("SIGINT", shutdown);
