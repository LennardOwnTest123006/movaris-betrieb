// Postfach-Anbindung: IMAP (z. B. info@movaris.de), AgentMail-API und Versand per SMTP oder AgentMail.

export const imapConfigured = (c) => Boolean(c.imap.host && c.imap.user && c.imap.pass);
export const agentmailConfigured = (c) => Boolean(c.agentmail.key && c.agentmail.inbox);
export const smtpConfigured = (c) => Boolean(c.smtp.host && c.smtp.from);
export const sendConfigured = (c) => smtpConfigured(c) || agentmailConfigured(c);

const addr = (a) => (a && a.value && a.value[0]) || {};

// Liest ungelesene Mails per IMAP. ingest(mail) muss { ok } liefern; danach wird die Mail als gelesen markiert.
export async function fetchImap(c, ingest, { limit = 40 } = {}) {
  const { ImapFlow } = await import("imapflow");
  const { simpleParser } = await import("mailparser");
  const client = new ImapFlow({
    host: c.imap.host,
    port: c.imap.port,
    secure: c.imap.secure,
    auth: { user: c.imap.user, pass: c.imap.pass },
    logger: false,
    socketTimeout: 60000,
  });
  const result = { fetched: 0, created: 0, skipped: 0, errors: [] };
  await client.connect();
  const lock = await client.getMailboxLock(c.imap.folder);
  try {
    const uids = (await client.search({ seen: false }, { uid: true })) || [];
    for (const uid of uids.slice(0, limit)) {
      try {
        const msg = await client.fetchOne(String(uid), { source: true }, { uid: true });
        if (!msg || !msg.source) continue;
        const p = await simpleParser(msg.source);
        result.fetched++;
        const r = await ingest({
          source: "imap",
          messageId: p.messageId || `imap-${c.imap.user}-${uid}`,
          subject: p.subject || "",
          text: p.text || (p.html ? String(p.html).replace(/<[^>]+>/g, " ") : ""),
          fromName: addr(p.from).name || "",
          fromEmail: addr(p.from).address || "",
          replyTo: addr(p.replyTo).address || "",
          date: (p.date || new Date()).toISOString(),
          attachments: (p.attachments || []).map((a) => ({ name: a.filename || "anhang", mime: a.contentType, data: a.content })),
        });
        if (r && r.created) result.created++;
        else result.skipped++;
        await client.messageFlagsAdd(String(uid), ["\\Seen"], { uid: true });
        if (c.imap.doneFolder) await client.messageMove(String(uid), c.imap.doneFolder, { uid: true }).catch(() => {});
      } catch (e) {
        result.errors.push(String(e.message || e));
      }
    }
  } finally {
    lock.release();
    await client.logout().catch(() => {});
  }
  return result;
}

async function am(c, path, init = {}) {
  const r = await fetch(c.agentmail.base + path, {
    ...init,
    headers: { authorization: `Bearer ${c.agentmail.key}`, "content-type": "application/json", ...(init.headers || {}) },
    signal: AbortSignal.timeout(20000),
  });
  if (!r.ok) {
    let detail = "";
    try {
      const j = await r.json();
      detail = j.name || j.message || "";
    } catch {}
    throw new Error(`AgentMail ${r.status} ${detail}`.trim());
  }
  return r.json();
}

// Liest empfangene Nachrichten der AgentMail-Inbox. Bereits verarbeitete (mail_log) werden übersprungen.
export async function fetchAgentMail(c, ingest, isKnown, { limit = 40 } = {}) {
  const inbox = encodeURIComponent(c.agentmail.inbox);
  const list = await am(c, `/inboxes/${inbox}/messages?limit=${limit}&labels=received`);
  const result = { fetched: 0, created: 0, skipped: 0, errors: [] };
  for (const item of list.messages || []) {
    const id = item.message_id;
    if (!id || (await isKnown(id))) continue;
    try {
      const m = await am(c, `/inboxes/${inbox}/messages/${encodeURIComponent(id)}`);
      result.fetched++;
      const from = String(m.from || item.from || "");
      const fm = from.match(/^(.*?)\s*<([^>]+)>$/);
      const attachments = [];
      for (const a of (m.attachments || []).slice(0, 8)) {
        if (!a.attachment_id || (a.size || 0) > 10 * 1024 * 1024) continue;
        try {
          const r = await fetch(`${c.agentmail.base}/inboxes/${inbox}/messages/${encodeURIComponent(id)}/attachments/${encodeURIComponent(a.attachment_id)}`, {
            headers: { authorization: `Bearer ${c.agentmail.key}` },
            signal: AbortSignal.timeout(20000),
          });
          if (r.ok) attachments.push({ name: a.filename || "anhang", mime: a.content_type || "application/octet-stream", data: Buffer.from(await r.arrayBuffer()) });
        } catch {}
      }
      const r = await ingest({
        source: "agentmail",
        messageId: id,
        subject: m.subject || item.subject || "",
        text: m.text || m.extracted_text || item.preview || "",
        fromName: fm ? fm[1].replace(/"/g, "") : "",
        fromEmail: fm ? fm[2] : from,
        replyTo: Array.isArray(m.reply_to) ? m.reply_to[0] || "" : m.reply_to || "",
        date: m.timestamp || item.timestamp || new Date().toISOString(),
        attachments,
      });
      if (r && r.created) result.created++;
      else result.skipped++;
    } catch (e) {
      result.errors.push(String(e.message || e));
    }
  }
  return result;
}

let transporter = null;
export async function sendMail(c, { to, subject, html, text, replyTo }) {
  if (smtpConfigured(c)) {
    const nodemailer = (await import("nodemailer")).default;
    transporter ||= nodemailer.createTransport({
      host: c.smtp.host,
      port: c.smtp.port,
      secure: c.smtp.secure,
      auth: c.smtp.user ? { user: c.smtp.user, pass: c.smtp.pass } : undefined,
    });
    const info = await transporter.sendMail({ from: c.smtp.from, to, subject, html, text, replyTo });
    return { via: "smtp", id: info.messageId };
  }
  if (agentmailConfigured(c)) {
    const r = await am(c, `/inboxes/${encodeURIComponent(c.agentmail.inbox)}/messages/send`, {
      method: "POST",
      body: JSON.stringify({ to, subject, html, text, reply_to: replyTo || undefined }),
    });
    return { via: "agentmail", id: r.message_id };
  }
  throw new Error("Kein E-Mail-Versand eingerichtet (SMTP_* oder AGENTMAIL_* in der .env setzen).");
}
