// Posteingang: Mails einlesen, als Anfrage anlegen oder zur Prüfung ablegen; regelmäßiger Abruf.
import { uid } from "./auth.js";
import { parseInquiry, looksLikeInquiry } from "./parse.js";
import { createOrder, getSettings, logEvent, nowIso, storeFile, str, allowedMime } from "./services.js";
import { fetchImap, fetchAgentMail, imapConfigured, agentmailConfigured, smtpConfigured, sendMail } from "./mail.js";

const AUTO_REPLY = /^(automatische antwort|abwesenheitsnotiz|auto(matic)?[ -]?reply|out of office|undeliver|unzustellbar|delivery status|mail delivery|nicht zustellbar)/i;

export function createMailService({ db, cfg, log }) {
  const state = { running: false, lastRun: null, lastResult: null, timer: null };

  const known = async (messageId) => Boolean(await db.get("SELECT id FROM mail_log WHERE message_id = ?", [messageId]));

  // Gibt { created, orderId, status } zurück
  async function ingest(m, { force = false, userName = "Posteingang" } = {}) {
    const messageId = str(m.messageId, 300) || `ohne-id-${uid()}`;
    if (!force && (await known(messageId))) return { created: false, status: "doppelt" };
    const settings = await getSettings(db);
    const p = parseInquiry({ subject: m.subject, text: m.text, fromName: m.fromName, fromEmail: m.fromEmail, replyTo: m.replyTo });
    const subject = str(m.subject, 300) || "(ohne Betreff)";
    const own = [cfg.smtp.from, cfg.agentmail.inbox, cfg.imap.user].filter(Boolean).map((s) => s.toLowerCase());
    let status = "offen";
    let orderId = null;

    // Antwort auf bestehenden Auftrag? (Auftragsnummer im Betreff)
    const ref = subject.match(/\b(20\d{2}-\d{4})\b/);
    const existing = ref ? await db.get("SELECT id, number FROM orders WHERE number = ?", [ref[1]]) : null;

    if (AUTO_REPLY.test(subject) && !force) status = "ignoriert";
    else if (existing) {
      await db.tx(async (t) => {
        await logEvent(t, existing.id, "mail", `E-Mail von ${m.fromEmail || "?"}: ${subject}\n\n${String(m.text || "").slice(0, 3000)}`, userName);
      });
      status = "zugeordnet";
      orderId = existing.id;
    } else {
      const mode = settings.mail?.auto_create || "erkannt";
      const fromOwn = own.includes(String(m.fromEmail || "").toLowerCase());
      const shouldCreate = force || p.is_form || (mode === "alle" && !fromOwn) || (mode === "erkannt" && !fromOwn && looksLikeInquiry(subject, m.text));
      if (shouldCreate && p.email) {
        const res = await db.tx(async (t) => {
          const o = await createOrder(
            t,
            {
              source: m.source === "web" ? "website" : "email",
              kind: p.kind,
              title: p.is_form ? ["Website-Anfrage", p.size_text].filter(Boolean).join(": ") : subject,
              customer: { name: p.name, email: p.email, phone: p.phone },
              from_address: p.from_address,
              to_address: p.to_address,
              from_floor: p.from_floor,
              to_floor: p.to_floor,
              from_elevator: p.from_elevator,
              desired_date: p.desired_date,
              volume_m3: p.volume_m3,
              area_m2: p.area_m2,
              rooms: p.rooms,
              notes: [p.size_text && `Umfang: ${p.size_text}`, p.floors_text && `Etagen/Zugang: ${p.floors_text}`, p.contact_pref && `Bevorzugter Kontakt: ${p.contact_pref}`, p.message].filter(Boolean).join("\n"),
              mail_text: `Von: ${m.fromName || ""} <${m.fromEmail || ""}>\nBetreff: ${subject}\nDatum: ${m.date || ""}\n\n${m.text || ""}`,
            },
            userName
          );
          for (const a of (m.attachments || []).slice(0, 10)) {
            if (!allowedMime(a.mime)) continue;
            try {
              await storeFile(t, cfg.dataDir, { name: a.name, mime: a.mime, data: a.data, order_id: o.id }, cfg.maxUploadMb * 1048576);
            } catch {}
          }
          return o;
        });
        status = "angelegt";
        orderId = res.id;
      }
    }
    await db.run(
      "INSERT INTO mail_log (id, source, message_id, from_addr, subject, received_at, order_id, status, body, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ON CONFLICT (message_id) DO UPDATE SET status = excluded.status, order_id = excluded.order_id",
      [uid(), m.source || "?", messageId, str(`${m.fromName || ""} <${m.fromEmail || ""}>`, 300), subject, m.date || nowIso(), orderId, status, str(m.text, 50000), nowIso()]
    );
    if (status === "angelegt" && cfg.officeNotify && smtpConfigured(cfg)) {
      sendMail(cfg, { to: cfg.officeNotify, subject: `Neue Anfrage: ${subject}`, text: `Neue Anfrage von ${p.name} <${p.email}> wurde angelegt.` }).catch(() => {});
    }
    return { created: status === "angelegt", orderId, status };
  }

  async function runFetch() {
    if (state.running) return { busy: true };
    state.running = true;
    const result = { imap: null, agentmail: null, at: nowIso() };
    try {
      if (imapConfigured(cfg)) {
        try {
          result.imap = await fetchImap(cfg, ingest);
        } catch (e) {
          result.imap = { error: String(e.message || e) };
        }
      }
      if (agentmailConfigured(cfg)) {
        try {
          result.agentmail = await fetchAgentMail(cfg, ingest, known);
        } catch (e) {
          result.agentmail = { error: String(e.message || e) };
        }
      }
    } finally {
      state.running = false;
      state.lastRun = result.at;
      state.lastResult = result;
    }
    return result;
  }

  function start() {
    if (!(imapConfigured(cfg) || agentmailConfigured(cfg)) || cfg.mailPollMinutes <= 0) return;
    const tick = () => runFetch().catch((e) => log.error?.("Postfach-Abruf", e));
    setTimeout(tick, 5000).unref?.();
    state.timer = setInterval(tick, cfg.mailPollMinutes * 60e3);
    state.timer.unref?.();
  }
  const stop = () => state.timer && clearInterval(state.timer);

  const status = () => ({
    imap: imapConfigured(cfg) ? { host: cfg.imap.host, user: cfg.imap.user, folder: cfg.imap.folder } : null,
    agentmail: agentmailConfigured(cfg) ? { inbox: cfg.agentmail.inbox } : null,
    smtp: smtpConfigured(cfg) ? { host: cfg.smtp.host, from: cfg.smtp.from } : null,
    send: smtpConfigured(cfg) ? "smtp" : agentmailConfigured(cfg) ? "agentmail" : null,
    poll_minutes: cfg.mailPollMinutes,
    running: state.running,
    last_run: state.lastRun,
    last_result: state.lastResult,
    inquiry_endpoint: Boolean(cfg.inquiryKey),
  });

  return { ingest, runFetch, start, stop, status, send: (msg) => sendMail(cfg, msg) };
}
