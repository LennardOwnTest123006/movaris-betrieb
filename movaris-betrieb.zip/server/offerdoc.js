// Angebotsdokument: dieselbe Gestaltung für Druck/PDF, E-Mail und die Online-Annahmeseite.
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { euro } from "../public/shared/calc.js";
import { deDate } from "../public/shared/dates.js";
import { KINDS } from "../public/shared/domain.js";

export const esc = (s) =>
  String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const nl = (s) => esc(s).replace(/\n/g, "<br>");
const CSS = readFileSync(fileURLToPath(new URL("../public/shared/offer.css", import.meta.url)), "utf8");

export function offerMarkup({ offer, order, customer, company }) {
  const totals = typeof offer.totals === "string" ? JSON.parse(offer.totals) : offer.totals || {};
  const positions = typeof offer.positions === "string" ? JSON.parse(offer.positions) : offer.positions || [];
  const groups = [];
  for (const p of positions) {
    let g = groups.find((x) => x.name === p.group);
    if (!g) groups.push((g = { name: p.group, items: [] }));
    g.items.push(p);
  }
  const head = [company.name, company.street, [company.zip, company.city].filter(Boolean).join(" ")].filter(Boolean).map(esc).join(" · ");
  const contact = [company.phone && `Tel. ${esc(company.phone)}`, company.email && esc(company.email), company.web && esc(company.web)].filter(Boolean).join(" · ");
  const cust = customer
    ? [customer.company, customer.name, customer.street, [customer.zip, customer.city].filter(Boolean).join(" ")].filter(Boolean).map(esc).join("<br>")
    : "";
  let n = 0;
  const rows = groups
    .map(
      (g) =>
        `<tr class="og"><td colspan="5">${esc(g.name)}</td></tr>` +
        g.items
          .map(
            (p) =>
              `<tr><td class="pos">${++n}</td><td>${esc(p.text)}</td><td class="r">${String(p.qty).replace(".", ",")} ${esc(p.unit)}</td><td class="r">${euro(p.price)}</td><td class="r">${euro(p.total)}</td></tr>`
          )
          .join("")
    )
    .join("");
  const vatRows = (totals.vat || [])
    .map((v) => `<tr><td colspan="4" class="r">zzgl. ${String(v.rate).replace(".", ",")} % MwSt. auf ${euro(v.base)}</td><td class="r">${euro(v.amount)}</td></tr>`)
    .join("");
  const details = [
    order.kind && ["Leistung", KINDS[order.kind] || order.kind],
    (order.scheduled_start || order.desired_date) && ["Termin", deDate(order.scheduled_start || order.desired_date) + (order.scheduled_start ? "" : " (Wunschtermin)")],
    order.from_address && ["Von", order.from_address + (order.from_floor != null ? `, ${order.from_floor}. Etage${order.from_elevator ? " mit Aufzug" : ""}` : "")],
    order.to_address && ["Nach", order.to_address + (order.to_floor != null ? `, ${order.to_floor}. Etage${order.to_elevator ? " mit Aufzug" : ""}` : "")],
    order.volume_m3 && ["Umzugsvolumen", `ca. ${String(order.volume_m3).replace(".", ",")} m³`],
  ].filter(Boolean);
  return `<article class="offer">
  <header class="o-head"><div class="o-brand">${esc(company.name || "MOVARIS")}</div><div class="o-addr">${head}<br>${contact}</div></header>
  <section class="o-top">
    <div class="o-cust"><div class="o-small">${head}</div>${cust}</div>
    <table class="o-meta"><tr><td>Angebot</td><td>${esc(offer.number)}</td></tr><tr><td>Datum</td><td>${deDate(offer.created_at)}</td></tr>
    <tr><td>Auftrag</td><td>${esc(order.number)}</td></tr>${offer.valid_until ? `<tr><td>Gültig bis</td><td>${deDate(offer.valid_until)}</td></tr>` : ""}</table>
  </section>
  <h1>Angebot ${esc(offer.number)}</h1>
  <p>${nl(offer.intro || "")}</p>
  ${details.length ? `<table class="o-details">${details.map(([a, b]) => `<tr><td>${esc(a)}</td><td>${esc(b)}</td></tr>`).join("")}</table>` : ""}
  <table class="o-pos"><thead><tr><th>Pos.</th><th>Leistung</th><th class="r">Menge</th><th class="r">Einzelpreis</th><th class="r">Gesamt (netto)</th></tr></thead>
  <tbody>${rows}</tbody>
  <tfoot><tr><td colspan="4" class="r">Summe netto</td><td class="r">${euro(totals.net)}</td></tr>${vatRows}
  <tr class="o-sum"><td colspan="4" class="r">Festpreis gesamt (brutto)</td><td class="r">${euro(totals.gross)}</td></tr></tfoot></table>
  ${offer.terms ? `<div class="o-terms">${nl(offer.terms)}</div>` : ""}
  <footer class="o-foot">${nl(company.footer || "")}</footer>
</article>`;
}

export function offerEmail(data, link) {
  return `<!doctype html><html lang="de"><head><meta charset="utf-8"><style>${CSS}</style></head><body class="o-mail">
  <p>${nl(data.greeting || "Guten Tag,")}</p><p>anbei erhalten Sie unser Angebot. ${link ? "Sie können es auch online ansehen und direkt annehmen:" : ""}</p>
  ${link ? `<p><a class="o-btn" href="${esc(link)}">Angebot online ansehen und annehmen</a></p>` : ""}
  ${offerMarkup(data)}</body></html>`;
}

export function offerPage(data, { token, state, message } = {}) {
  const decided = data.offer.status === "angenommen" || data.offer.status === "abgelehnt";
  const action = decided
    ? `<div class="o-box ${data.offer.status === "angenommen" ? "ok" : ""}">${data.offer.status === "angenommen" ? "Vielen Dank – Sie haben dieses Angebot angenommen. Wir melden uns zur Terminabstimmung." : "Sie haben dieses Angebot abgelehnt. Vielen Dank für Ihre Rückmeldung."}</div>`
    : token
    ? `<section class="o-act">
      <form method="post" action="/angebot/${esc(token)}/annehmen" class="o-form">
        <h2>Angebot annehmen</h2>
        <label>Ihr Name<input name="name" required maxlength="120" autocomplete="name"></label>
        <label class="o-check"><input type="checkbox" name="agree" value="1" required> Ich nehme das Angebot ${esc(data.offer.number)} verbindlich an.</label>
        <button class="o-btn" type="submit">Verbindlich annehmen</button>
      </form>
      <form method="post" action="/angebot/${esc(token)}/ablehnen" class="o-form o-decline">
        <h2>Angebot ablehnen</h2>
        <label>Grund (optional)<textarea name="reason" maxlength="1000" rows="3"></textarea></label>
        <button class="o-btn o-ghost" type="submit">Ablehnen</button>
      </form></section>`
    : "";
  return `<!doctype html><html lang="de"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
  <meta name="robots" content="noindex"><title>Angebot ${esc(data.offer.number)}</title><link rel="stylesheet" href="/shared/offer.css"></head>
  <body class="o-page">${message ? `<div class="o-box ${state === "ok" ? "ok" : ""}">${esc(message)}</div>` : ""}${offerMarkup(data)}${action}
  <p class="o-print"><button type="button" class="o-btn o-ghost" data-print>Drucken / als PDF speichern</button></p><script src="/shared/print.js"></script></body></html>`;
}

export function printPage(data) {
  return `<!doctype html><html lang="de"><head><meta charset="utf-8"><title>Angebot ${esc(data.offer.number)}</title>
  <link rel="stylesheet" href="/shared/offer.css"><script src="/shared/print.js" defer></script></head><body class="o-page"><p class="o-print"><button type="button" class="o-btn" data-print>Drucken / als PDF speichern</button></p>${offerMarkup(data)}</body></html>`;
}
