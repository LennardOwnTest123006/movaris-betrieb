// Erkennt Anfrage-Daten in E-Mails: exakt beim Format des Website-Formulars, sonst per Mustererkennung.

export { KINDS } from "../public/shared/domain.js";

const LABELS = {
  anfrageart: "kindLabel",
  name: "name",
  "e-mail": "email",
  email: "email",
  telefon: "phone",
  tel: "phone",
  wunschtermin: "date",
  "von (ort/plz)": "from",
  von: "from",
  "nach (ort/plz)": "to",
  nach: "to",
  "größe/umfang": "size",
  umfang: "size",
  "etagen/aufzug/zugang": "floors",
  "bevorzugter kontakt": "contact",
  nachricht: "message",
};

const KIND_WORDS = [
  ["besichtigung", /besichtig/i],
  ["moebelhotel", /möbelhotel|moebelhotel|einlager|lagerplatz|corlette/i],
  ["selfstorage", /container|selfstorage|self-storage|lagerraum|lagerbox/i],
  ["entruempelung", /entrümpel|entruempel|entsorg|haushaltsauflös|wohnungsauflös|sperrmüll/i],
  ["firma", /firmenumzug|büroumzug|praxisumzug|betriebsverlagerung/i],
  ["verpackung", /karton|verpackungsmaterial|packservice|einpack/i],
  ["umzug", /umzug|umziehen|ziehen um|wohnungswechsel|transport/i],
];

const INQUIRY_HINTS = /umzug|umzieh|angebot|anfrage|besichtig|lager|container|möbelhotel|entrümpel|entsorg|möbel|kartons?|termin|wohnung|zimmer|etage|\bm²|\bm³|\bqm\b|kostenvoranschlag|transport|haushaltsauflös/i;

const clean = (s, n = 500) => (s == null ? "" : String(s).replace(/\u0000/g, "").trim().slice(0, n));

export function detectKind(text) {
  for (const [k, re] of KIND_WORDS) if (re.test(text)) return k;
  return "sonstiges";
}
export function kindFromLabel(label) {
  const l = (label || "").toLowerCase();
  if (l.startsWith("umzug")) return "umzug";
  if (l.startsWith("besichtigung")) return "besichtigung";
  if (l.includes("möbelhotel")) return "moebelhotel";
  if (l.includes("selfstorage") || l.includes("container")) return "selfstorage";
  if (l.includes("entrümpel")) return "entruempelung";
  if (l.includes("firmenumzug")) return "firma";
  if (l.includes("verpackung")) return "verpackung";
  return detectKind(l);
}

export function looksLikeInquiry(subject, text) {
  return INQUIRY_HINTS.test(`${subject || ""}\n${text || ""}`);
}

// deutsches Datum -> ISO (YYYY-MM-DD)
export function parseGermanDate(s, now = new Date()) {
  const m = String(s || "").match(/\b(\d{1,2})\.(\d{1,2})\.(\d{2,4})?/);
  if (m) {
    let y = m[3] ? Number(m[3]) : now.getFullYear();
    if (y < 100) y += 2000;
    const d = Number(m[1]), mo = Number(m[2]);
    if (d >= 1 && d <= 31 && mo >= 1 && mo <= 12) {
      let iso = `${y}-${String(mo).padStart(2, "0")}-${String(d).padStart(2, "0")}`;
      if (!m[3] && new Date(iso) < new Date(now.toISOString().slice(0, 10))) iso = `${y + 1}${iso.slice(4)}`;
      return iso;
    }
  }
  const iso = String(s || "").match(/\b(20\d{2})-(\d{2})-(\d{2})\b/);
  return iso ? iso[0] : null;
}

const PHONE = /(?:\+49|0049|\b0)[\s\-/()]*\d[\d\s\-/()]{5,18}\d/;
const EMAIL = /[^\s<>"'(),;:]+@[^\s<>"'(),;:]+\.[a-z]{2,}/i;
const PLZ_CITY = /\b(\d{5})\s+([A-ZÄÖÜ][\wäöüß.\- ]{1,40}?)(?=[\n,;.)]|\s{2}|\s+(?:nach|in|zum|zur|und|ab)\b|$)/g;

export function parseInquiry({ subject = "", text = "", fromName = "", fromEmail = "", replyTo = "" } = {}, now = new Date()) {
  const body = String(text || "").replace(/\r/g, "");
  const f = {};
  // 1) Formular-Format "Feld: Wert"
  let formHits = 0;
  for (const line of body.split("\n")) {
    const m = line.match(/^\s*([A-Za-zÄÖÜäöüß/() .\-]{2,30}):\s*(.+)$/);
    if (!m) continue;
    const key = LABELS[m[1].trim().toLowerCase()];
    if (key && !f[key]) {
      f[key] = m[2].trim();
      formHits++;
    }
  }
  if (f.message && formHits >= 3) {
    // Nachricht kann mehrzeilig sein: alles nach "Nachricht:" übernehmen
    const idx = body.search(/^\s*Nachricht:\s*/m);
    if (idx >= 0) f.message = body.slice(idx).replace(/^\s*Nachricht:\s*/, "").trim();
  }
  const isForm = formHits >= 3;

  const out = {
    kind: f.kindLabel ? kindFromLabel(f.kindLabel) : detectKind(`${subject}\n${body}`),
    name: clean(f.name || fromName, 120),
    email: clean((f.email && (f.email.match(EMAIL) || [])[0]) || replyTo || fromEmail, 160).toLowerCase(),
    phone: clean(f.phone || (body.match(PHONE) || [])[0] || "", 40),
    desired_date: parseGermanDate(f.date || "", now) || (isForm ? null : parseGermanDate(body, now)),
    from_address: clean(f.from, 200),
    to_address: clean(f.to, 200),
    floors_text: clean(f.floors, 200),
    size_text: clean(f.size, 120),
    contact_pref: clean(f.contact, 30),
    message: clean(isForm ? f.message || "" : body, 20000),
    is_form: isForm,
  };

  // 2) Freitext-Erkennung
  const all = `${subject}\n${body}`;
  if (!out.from_address || !out.to_address) {
    const fromM = all.match(/\bvon\s*:?\s+([^\n]{3,80}?)\s+(?:nach|zu|in die|in den)\s+([^\n.,;]{3,80})/i);
    if (fromM) {
      out.from_address ||= clean(fromM[1], 200);
      out.to_address ||= clean(fromM[2], 200);
    } else {
      const places = [...all.matchAll(PLZ_CITY)].map((m) => `${m[1]} ${m[2].trim()}`);
      if (places[0] && !out.from_address) out.from_address = places[0];
      if (places[1] && !out.to_address) out.to_address = places[1];
    }
  }
  const vol = all.match(/(\d+(?:[.,]\d+)?)\s*(?:m³|m3|cbm|kubikmeter)/i);
  out.volume_m3 = vol ? parseFloat(vol[1].replace(",", ".")) : null;
  const area = all.match(/(\d+(?:[.,]\d+)?)\s*(?:m²|m2|qm|quadratmeter)/i);
  out.area_m2 = area ? parseFloat(area[1].replace(",", ".")) : null;
  const rooms = all.match(/(\d+(?:[.,]5)?)\s*[- ]?(?:zimmer|zi\b|raum-?wohnung|zkb)/i);
  out.rooms = rooms ? parseFloat(rooms[1].replace(",", ".")) : null;
  const floorRe = /(\d{1,2})\s*\.?\s*(?:og|etage|stock|obergeschoss)/gi;
  const floors = [...all.matchAll(floorRe)].map((m) => Number(m[1]));
  out.from_floor = floors[0] ?? null;
  out.to_floor = floors[1] ?? null;
  out.from_elevator = /(?:mit|hat|gibt es einen?)\s+(?:aufzug|fahrstuhl|lift)/i.test(all) && !/(?:ohne|kein(?:en)?)\s+(?:aufzug|fahrstuhl|lift)/i.test(all);
  if (!out.name && out.email) out.name = out.email.split("@")[0];
  return out;
}
