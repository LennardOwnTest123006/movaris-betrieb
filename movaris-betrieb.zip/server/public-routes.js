// Anmeldung, Ersteinrichtung, öffentliches Anfrage-Formular und Online-Angebotsannahme.
import { hashPassword, verifyPassword, passwordProblem, createSession, destroySession, cookieHeader, clearCookie, readCookie, uid } from "./auth.js";
import { HttpError, bad, send, readJson } from "./http.js";
import { email, str, nowIso, getSettings, setStatus, logEvent, nowLocal } from "./services.js";
import { offerPage } from "./offerdoc.js";
import { sendMail, sendConfigured } from "./mail.js";

export function registerPublic(r, { db, cfg, mail, limits }) {
  const startSession = async (ctx, userId) => {
    const s = await createSession(db, userId);
    ctx.res.setHeader("set-cookie", cookieHeader(s.token, s.expires, cfg.secureCookies));
    await db.run("UPDATE users SET last_login = ? WHERE id = ?", [nowIso(), userId]);
  };

  r.get("/api/setup", async () => {
    const n = await db.get("SELECT COUNT(*) AS n FROM users");
    return { needed: !n || n.n === 0 };
  }, { auth: false });

  r.post("/api/setup", async (ctx) => {
    const b = await ctx.body();
    const res = await db.tx(async (t) => {
      const n = await t.get("SELECT COUNT(*) AS n FROM users");
      if (n && n.n > 0) throw new HttpError(409, "Die Einrichtung ist bereits abgeschlossen.");
      const mail = email(b.email);
      if (!mail || !str(b.name)) throw bad("Bitte Name und E-Mail angeben.");
      const p = passwordProblem(b.password);
      if (p) throw bad(p);
      const id = uid();
      await t.run("INSERT INTO users (id, email, name, role, password_hash, active, created_at) VALUES (?, ?, ?, 'admin', ?, 1, ?)", [id, mail, str(b.name, 120), await hashPassword(b.password), nowIso()]);
      return id;
    });
    await startSession(ctx, res);
    return { ok: true };
  }, { auth: false });

  r.post("/api/login", async (ctx) => {
    const b = await ctx.body();
    const mailAddr = String(b.email || "").trim().toLowerCase().slice(0, 160);
    if (!limits.login(ctx.ip) || !limits.login("u:" + mailAddr)) throw new HttpError(429, "Zu viele Versuche. Bitte in 15 Minuten erneut versuchen.");
    const u = await db.get("SELECT id, password_hash, active, role FROM users WHERE lower(email) = ?", [mailAddr]);
    const ok = u ? await verifyPassword(b.password || "", u.password_hash) : await verifyPassword("x", "scrypt$16384$AAAAAAAAAAAAAAAAAAAAAA==$AAAA");
    if (!u || !ok || !u.active) throw new HttpError(401, "E-Mail oder Passwort falsch.");
    await startSession(ctx, u.id);
    return { ok: true, role: u.role };
  }, { auth: false });

  r.post("/api/logout", async (ctx) => {
    await destroySession(db, readCookie(ctx.req));
    ctx.res.setHeader("set-cookie", clearCookie(cfg.secureCookies));
    return { ok: true };
  }, { auth: false });

  // ---------- Öffentliches Anfrage-Formular (Website → App) ----------
  r.post("/api/public/inquiry", async (ctx) => {
    const origin = ctx.req.headers.origin || "";
    if (origin && cfg.inquiryOrigins.includes(origin)) {
      ctx.res.setHeader("access-control-allow-origin", origin);
      ctx.res.setHeader("vary", "origin");
    }
    if (!cfg.inquiryKey) throw new HttpError(503, "Anfrage-Schnittstelle ist nicht eingerichtet.");
    const b = await readJson(ctx.req, 200_000);
    if ((ctx.req.headers["x-inquiry-key"] || b.key) !== cfg.inquiryKey) throw new HttpError(401, "Ungültiger Schlüssel.");
    if (!limits.inquiry(ctx.ip)) throw new HttpError(429, "Zu viele Anfragen.");
    if (b.website) return { ok: true }; // Honeypot
    const mailAddr = email(b.email);
    if (!str(b.name) || !mailAddr) throw bad("Name und E-Mail sind Pflicht.");
    const kindLabels = { umzug: "Umzug / Angebot", besichtigung: "Besichtigungstermin", moebelhotel: "Möbelhotel / Einlagerung", selfstorage: "Selfstorage-Container", entruempelung: "Entrümpelung / Entsorgung", verpackung: "Verpackungsmaterial", firma: "Firmenumzug", sonstiges: "Sonstige Frage" };
    const text = [
      ["Anfrageart", kindLabels[b.type] || "Sonstige Frage"], ["Name", b.name], ["E-Mail", mailAddr], ["Telefon", b.phone], ["Wunschtermin", b.date],
      ["Von (Ort/PLZ)", b.from], ["Nach (Ort/PLZ)", b.to], ["Größe/Umfang", b.size], ["Etagen/Aufzug/Zugang", b.floors], ["Bevorzugter Kontakt", b.contact], ["Nachricht", b.message],
    ].filter(([, v]) => str(v)).map(([k, v]) => `${k}: ${str(v, 1500)}`).join("\n");
    const r2 = await mail.ingest({ source: "web", messageId: `web-${uid()}`, subject: `${kindLabels[b.type] || "Anfrage"} – Anfrage von ${str(b.name, 80)}`, text, fromName: str(b.name, 80), fromEmail: mailAddr, date: nowIso() }, { force: true, userName: "Website" });
    return { ok: true, created: r2.created };
  }, { public: true, auth: false });

  // ---------- Online-Angebot ----------
  const loadOffer = async (token) => {
    if (!token || token.length > 80) return null;
    const offer = await db.get("SELECT * FROM offers WHERE token = ?", [token]);
    if (!offer) return null;
    const order = await db.get("SELECT * FROM orders WHERE id = ?", [offer.order_id]);
    const customer = order?.customer_id ? await db.get("SELECT * FROM customers WHERE id = ?", [order.customer_id]) : null;
    const settings = await getSettings(db);
    return { offer, order, customer, company: settings.company };
  };
  const page = (html, status = 200) => ({ __raw: true, status, body: html, headers: { "cache-control": "no-store", "x-robots-tag": "noindex" } });

  r.get("/angebot/:token", async (ctx) => {
    const d = await loadOffer(ctx.params.token);
    if (!d) throw new HttpError(404, "Angebot nicht gefunden.");
    const expired = d.offer.valid_until && d.offer.valid_until < nowLocal().day && d.offer.status === "versendet";
    return page(offerPage(d, { token: expired ? null : ctx.params.token, message: expired ? "Dieses Angebot ist abgelaufen. Bitte melden Sie sich bei uns – wir aktualisieren es gern." : null }));
  }, { public: true, auth: false });

  const decide = (accept) => async (ctx) => {
    if (!limits.offer(ctx.ip)) throw new HttpError(429, "Zu viele Anfragen.");
    const d = await loadOffer(ctx.params.token);
    if (!d) throw new HttpError(404, "Angebot nicht gefunden.");
    const b = await readJson(ctx.req, 20_000);
    if (d.offer.status !== "versendet") return page(offerPage(d, { message: "Für dieses Angebot liegt bereits eine Entscheidung vor." }));
    if (d.offer.valid_until && d.offer.valid_until < nowLocal().day) return page(offerPage(d, { message: "Dieses Angebot ist abgelaufen. Bitte melden Sie sich bei uns." }));
    if (accept && (!str(b.name) || !b.agree)) return page(offerPage(d, { token: ctx.params.token, message: "Bitte Namen eintragen und die Annahme bestätigen." }), 400);
    const who = accept ? `${str(b.name, 120)} (online)` : "Kunde (online)";
    await db.tx(async (t) => {
      await t.run("UPDATE offers SET status = ?, decided_at = ?, decided_by = ?, decision_note = ? WHERE id = ?", [accept ? "angenommen" : "abgelehnt", nowIso(), who, accept ? `Angenommen von ${str(b.name, 120)}, IP ${ctx.ip}` : str(b.reason, 1000), d.offer.id]);
      await logEvent(t, d.order.id, "angebot", `Angebot ${d.offer.number} online ${accept ? "angenommen" : "abgelehnt"}${accept ? ` von ${str(b.name, 120)}` : b.reason ? `: ${str(b.reason, 500)}` : ""}.`, "Kunde");
      if (accept && !["zuschlag", "geplant", "in_durchfuehrung", "erledigt", "abgerechnet"].includes(d.order.status)) await setStatus(t, d.order, "zuschlag", "Kunde");
      if (!accept && ["angebot_versendet", "angebot_erstellt"].includes(d.order.status)) await setStatus(t, d.order, "absage", "Kunde", str(b.reason, 500) || "online abgelehnt");
    });
    if (cfg.officeNotify && sendConfigured(cfg)) {
      sendMail(cfg, { to: cfg.officeNotify, subject: `Angebot ${d.offer.number} ${accept ? "angenommen" : "abgelehnt"}`, text: `Auftrag ${d.order.number}: Angebot ${d.offer.number} wurde online ${accept ? "angenommen" : "abgelehnt"}.` }).catch(() => {});
    }
    const fresh = await loadOffer(ctx.params.token);
    return page(offerPage(fresh, { state: "ok", message: accept ? "Vielen Dank! Ihre Annahme ist bei uns eingegangen." : "Danke für Ihre Rückmeldung." }));
  };
  r.post("/angebot/:token/annehmen", decide(true), { public: true, auth: false });
  r.post("/angebot/:token/ablehnen", decide(false), { public: true, auth: false });

  r.get("/api/health", async () => ({ ok: true, db: db.kind }), { public: true, auth: false });
}

export { send };
