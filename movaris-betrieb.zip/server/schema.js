// Datenbankschema (läuft unverändert auf SQLite und PostgreSQL). Datum/Zeit als ISO-Text, IDs als Text (UUID).
const R = { sqlite: "REAL", postgres: "DOUBLE PRECISION" };

const SCHEMA_V1 = (k) => `
CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT);
CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT);
CREATE TABLE IF NOT EXISTS employees (
  id TEXT PRIMARY KEY, name TEXT NOT NULL, phone TEXT, email TEXT, position TEXT,
  hourly_wage ${R[k]} DEFAULT 0, weekly_hours ${R[k]} DEFAULT 40, vacation_days ${R[k]} DEFAULT 30,
  entry_date TEXT, color TEXT, notes TEXT, active INTEGER DEFAULT 1, created_at TEXT
);
CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY, email TEXT NOT NULL UNIQUE, name TEXT NOT NULL, role TEXT NOT NULL,
  password_hash TEXT NOT NULL, employee_id TEXT REFERENCES employees(id), active INTEGER DEFAULT 1,
  created_at TEXT, last_login TEXT
);
CREATE TABLE IF NOT EXISTS sessions (
  id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id), expires_at TEXT NOT NULL, created_at TEXT
);
CREATE TABLE IF NOT EXISTS customers (
  id TEXT PRIMARY KEY, name TEXT NOT NULL, company TEXT, email TEXT, phone TEXT,
  street TEXT, zip TEXT, city TEXT, notes TEXT, created_at TEXT
);
CREATE TABLE IF NOT EXISTS vehicles (
  id TEXT PRIMARY KEY, name TEXT NOT NULL, plate TEXT, kind TEXT, capacity_m3 ${R[k]}, active INTEGER DEFAULT 1, notes TEXT
);
CREATE TABLE IF NOT EXISTS orders (
  id TEXT PRIMARY KEY, number TEXT NOT NULL UNIQUE, customer_id TEXT REFERENCES customers(id),
  kind TEXT NOT NULL, status TEXT NOT NULL, source TEXT, title TEXT,
  from_address TEXT, from_floor INTEGER, from_elevator INTEGER DEFAULT 0, from_carry_m INTEGER,
  to_address TEXT, to_floor INTEGER, to_elevator INTEGER DEFAULT 0, to_carry_m INTEGER,
  desired_date TEXT, scheduled_start TEXT, scheduled_end TEXT,
  volume_m3 ${R[k]}, area_m2 ${R[k]}, rooms ${R[k]}, distance_km ${R[k]},
  inventory TEXT, notes TEXT, special_wishes TEXT, mail_text TEXT, lost_reason TEXT,
  created_by TEXT, created_at TEXT, updated_at TEXT
);
CREATE INDEX IF NOT EXISTS ix_orders_status ON orders(status);
CREATE INDEX IF NOT EXISTS ix_orders_sched ON orders(scheduled_start);
CREATE INDEX IF NOT EXISTS ix_orders_customer ON orders(customer_id);
CREATE TABLE IF NOT EXISTS order_staff (order_id TEXT NOT NULL REFERENCES orders(id) ON DELETE CASCADE, employee_id TEXT NOT NULL REFERENCES employees(id), lead INTEGER DEFAULT 0, PRIMARY KEY (order_id, employee_id));
CREATE INDEX IF NOT EXISTS ix_staff_emp ON order_staff(employee_id);
CREATE TABLE IF NOT EXISTS order_vehicles (order_id TEXT NOT NULL REFERENCES orders(id) ON DELETE CASCADE, vehicle_id TEXT NOT NULL REFERENCES vehicles(id), PRIMARY KEY (order_id, vehicle_id));
CREATE TABLE IF NOT EXISTS order_events (
  id TEXT PRIMARY KEY, order_id TEXT NOT NULL REFERENCES orders(id) ON DELETE CASCADE, kind TEXT, text TEXT, user_name TEXT, created_at TEXT
);
CREATE INDEX IF NOT EXISTS ix_events_order ON order_events(order_id);
CREATE TABLE IF NOT EXISTS offers (
  id TEXT PRIMARY KEY, order_id TEXT NOT NULL REFERENCES orders(id) ON DELETE CASCADE, number TEXT NOT NULL UNIQUE,
  version INTEGER DEFAULT 1, status TEXT NOT NULL, input TEXT, positions TEXT, totals TEXT,
  net ${R[k]} DEFAULT 0, gross ${R[k]} DEFAULT 0, valid_until TEXT, intro TEXT, terms TEXT,
  token TEXT UNIQUE, created_at TEXT, sent_at TEXT, decided_at TEXT, decided_by TEXT, decision_note TEXT
);
CREATE INDEX IF NOT EXISTS ix_offers_order ON offers(order_id);
CREATE TABLE IF NOT EXISTS price_items (
  id TEXT PRIMARY KEY, key TEXT UNIQUE, category TEXT, name TEXT NOT NULL, unit TEXT, price ${R[k]} DEFAULT 0,
  vat_rate ${R[k]} DEFAULT 19, active INTEGER DEFAULT 1, sort INTEGER DEFAULT 0
);
CREATE TABLE IF NOT EXISTS time_entries (
  id TEXT PRIMARY KEY, employee_id TEXT NOT NULL REFERENCES employees(id), order_id TEXT REFERENCES orders(id) ON DELETE SET NULL,
  day TEXT NOT NULL, start_time TEXT, end_time TEXT, break_min INTEGER DEFAULT 0, minutes INTEGER DEFAULT 0,
  note TEXT, source TEXT, approved INTEGER DEFAULT 0, created_at TEXT
);
CREATE INDEX IF NOT EXISTS ix_time_emp_day ON time_entries(employee_id, day);
CREATE INDEX IF NOT EXISTS ix_time_order ON time_entries(order_id);
CREATE TABLE IF NOT EXISTS absences (
  id TEXT PRIMARY KEY, employee_id TEXT NOT NULL REFERENCES employees(id), kind TEXT NOT NULL,
  start_date TEXT NOT NULL, end_date TEXT NOT NULL, days ${R[k]} DEFAULT 0, half_day INTEGER DEFAULT 0, status TEXT NOT NULL,
  note TEXT, file_id TEXT, created_at TEXT, decided_at TEXT, decided_by TEXT
);
CREATE INDEX IF NOT EXISTS ix_abs_emp ON absences(employee_id, start_date);
CREATE TABLE IF NOT EXISTS feedback (
  id TEXT PRIMARY KEY, order_id TEXT REFERENCES orders(id) ON DELETE CASCADE, employee_id TEXT REFERENCES employees(id),
  kind TEXT NOT NULL, text TEXT, file_ids TEXT, status TEXT DEFAULT 'offen', created_at TEXT, done_at TEXT, done_by TEXT
);
CREATE INDEX IF NOT EXISTS ix_feedback_status ON feedback(status);
CREATE TABLE IF NOT EXISTS files (
  id TEXT PRIMARY KEY, name TEXT, mime TEXT, size INTEGER, path TEXT NOT NULL, order_id TEXT, owner_employee_id TEXT, created_at TEXT
);
CREATE INDEX IF NOT EXISTS ix_files_order ON files(order_id);
CREATE TABLE IF NOT EXISTS mail_log (
  id TEXT PRIMARY KEY, source TEXT, message_id TEXT UNIQUE, from_addr TEXT, subject TEXT, received_at TEXT,
  order_id TEXT, status TEXT, body TEXT, error TEXT, created_at TEXT
);
CREATE INDEX IF NOT EXISTS ix_mail_status ON mail_log(status);
`;

export async function migrate(db) {
  await db.exec("CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT)");
  const v = await db.get("SELECT value FROM meta WHERE key = ?", ["schema_version"]);
  if (!v) {
    await db.exec(SCHEMA_V1(db.kind));
    await db.run("INSERT INTO meta (key, value) VALUES (?, ?)", ["schema_version", "1"]);
  }
}
