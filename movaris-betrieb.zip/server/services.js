// Fachlogik, die von mehreren Routen genutzt wird.
import { mkdir, writeFile } from "node:fs/promises";
import { join, extname } from "node:path";
import { uid } from "./auth.js";
import { bad } from "./http.js";
import { CALC_DEFAULTS, DEFAULT_INVENTORY, DEFAULT_PRICE_ITEMS } from "../public/shared/calc.js";
import { KINDS, STATUS } from "../public/shared/domain.js";
import { workdays, monthRange, isoDay, parseDay, addDays } from "../public/shared/dates.js";

export const nowIso = () => new Date().toISOString();

// Uhrzeit für Zeiterfassung immer in Europe/Berlin, unabhängig von der Server-Zeitzone
const TZ = process.env.APP_TZ || "Europe/Berlin";
const fmt = new Intl.DateTimeFormat("sv-SE", { timeZone: TZ, year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", hour12: false });
export function nowLocal(d = new Date()) {
  const s = fmt.format(d).replace(",", ""); // "2026-10-31 14:05"
  return { day: s.slice(0, 10), time: s.slice(11, 16) };
}

// ---------- Validierung ----------
export const str = (v, max = 500) => (v === undefined || v === null ? null : String(v).replace(/\u0000/g, "").trim().slice(0, max) || null);
export const num = (v) => {
  if (v === undefined || v === null || v === "") return null;
  const n = typeof v === "string" ? parseFloat(v.replace(",", ".")) : Number(v);
  return Number.isFinite(n) ? n : null;
};
export const int = (v) => {
  const n = num(v);
  return n === null ? null : Math.round(n);
};
export const flag = (v) => (v === true || v === 1 || v === "1" || v === "true" || v === "on" ? 1 : 0);
export const day = (v, name = "Datum") => {
  if (v === undefined || v === null || v === "") return null;
  const s = String(v).slice(0, 10);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(s) || isNaN(parseDay(s))) throw bad(`${name} ist ungültig.`);
  return s;
};
export const time = (v, name = "Uhrzeit") => {
  if (v === undefined || v === null || v === "") return null;
  const s = String(v).slice(0, 5);
  if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(s)) throw bad(`${name} ist ungültig (HH:MM).`);
  return s;
};
export const dateTime = (v, name = "Zeitpunkt") => {
  if (v === undefined || v === null || v === "") return null;
  const s = String(v).slice(0, 16);
  if (!/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/.test(s)) throw bad(`${name} ist ungültig.`);
  return s;
};
export const email = (v) => {
  const s = str(v, 160);
  if (!s) return null;
  if (!/^[^\s@<>]+@[^\s@<>]+\.[^\s@<>]{2,}$/.test(s)) throw bad("E-Mail-Adresse ist ungültig.");
  return s.toLowerCase();
};
export const oneOf = (v, list, name) => {
  if (!list.includes(v)) throw bad(`${name} ist ungültig.`);
  return v;
};

// ---------- Einstellungen ----------
export const DEFAULT_SETTINGS = {
  company: {
    name: "MOVARIS",
    street: "Brandgehaege 5",
    zip: "38444",
    city: "Wolfsburg",
    phone: "+49 5308 921 7050",
    email: "info@movaris.de",
    web: "movaris.de",
    footer: "",
  },
  calc: { ...CALC_DEFAULTS },
  offer: {
    greeting: "Guten Tag,",
    intro: "vielen Dank für Ihre Anfrage. Gerne bieten wir Ihnen die folgenden Leistungen zum Festpreis an.",
    terms: "Dieses Angebot ist ein Festpreisangebot auf Grundlage Ihrer Angaben (Umzugsgut, Etagen, Laufwege, Termin). Ändert sich der Umfang, passen wir das Angebot gemeinsam an. Es gelten unsere Allgemeinen Geschäftsbedingungen.",
    subject: "Ihr Angebot {nummer} von MOVARIS",
  },
  mail: { auto_create: "erkannt" },
  inventory: DEFAULT_INVENTORY,
};

export async function getSettings(db) {
  const rows = await db.all("SELECT key, value FROM settings");
  const out = structuredClone(DEFAULT_SETTINGS);
  for (const r of rows) {
    try {
      const v = JSON.parse(r.value);
      out[r.key] = Array.isArray(v) || typeof v !== "object" ? v : { ...(out[r.key] || {}), ...v };
    } catch {}
  }
  return out;
}
export async function putSetting(db, key, value) {
  await db.run("INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT (key) DO UPDATE SET value = excluded.value", [key, JSON.stringify(value)]);
}

export async function seed(db) {
  const n = await db.get("SELECT COUNT(*) AS n FROM price_items");
  if (!n || !n.n) {
    for (const p of DEFAULT_PRICE_ITEMS) {
      await db.run("INSERT INTO price_items (id, key, category, name, unit, price, vat_rate, active, sort) VALUES (?, ?, ?, ?, ?, ?, ?, 1, ?)", [uid(), p.key, p.category, p.name, p.unit, 0, p.vat_rate, p.sort]);
    }
  }
}

// ---------- Nummernkreise ----------
export async function nextNumber(t, table, prefix) {
  const year = nowLocal().day.slice(0, 4);
  const like = `${prefix}${year}-%`;
  const row = await t.get(`SELECT number FROM ${table} WHERE number LIKE ? ORDER BY number DESC LIMIT 1`, [like]);
  const last = row ? parseInt(row.number.split("-").pop(), 10) : 0;
  return `${prefix}${year}-${String(last + 1).padStart(4, "0")}`;
}

// ---------- Verlauf ----------
export const logEvent = (t, orderId, kind, text, userName) =>
  t.run("INSERT INTO order_events (id, order_id, kind, text, user_name, created_at) VALUES (?, ?, ?, ?, ?, ?)", [uid(), orderId, kind, String(text).slice(0, 4000), userName || "System", nowIso()]);

// ---------- Kunden ----------
export async function findOrCreateCustomer(t, c) {
  const mail = c.email ? String(c.email).toLowerCase() : null;
  if (mail) {
    const ex = await t.get("SELECT * FROM customers WHERE lower(email) = ?", [mail]);
    if (ex) {
      // fehlende Angaben ergänzen
      const upd = {};
      for (const k of ["phone", "street", "zip", "city", "company"]) if (!ex[k] && c[k]) upd[k] = c[k];
      if (Object.keys(upd).length) {
        await t.run(`UPDATE customers SET ${Object.keys(upd).map((k) => `${k} = ?`).join(", ")} WHERE id = ?`, [...Object.values(upd), ex.id]);
      }
      return ex.id;
    }
  }
  const id = uid();
  await t.run("INSERT INTO customers (id, name, company, email, phone, street, zip, city, notes, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [
    id, str(c.name, 120) || mail || "Unbekannt", str(c.company, 120), mail, str(c.phone, 40), str(c.street, 160), str(c.zip, 10), str(c.city, 80), str(c.notes, 2000), nowIso(),
  ]);
  return id;
}

export const ORDER_FIELDS = {
  kind: (v) => oneOf(v, Object.keys(KINDS), "Auftragsart"),
  title: (v) => str(v, 200),
  from_address: (v) => str(v, 200),
  from_floor: int,
  from_elevator: flag,
  from_carry_m: int,
  to_address: (v) => str(v, 200),
  to_floor: int,
  to_elevator: flag,
  to_carry_m: int,
  desired_date: (v) => day(v, "Wunschtermin"),
  volume_m3: num,
  area_m2: num,
  rooms: num,
  distance_km: num,
  notes: (v) => str(v, 20000),
  special_wishes: (v) => str(v, 5000),
  inventory: (v) => (v == null ? null : JSON.stringify(Array.isArray(v) ? v.slice(0, 300).map((i) => ({ name: str(i.name, 80), room: str(i.room, 40), m3: num(i.m3) || 0, qty: num(i.qty) || 0 })) : [])),
};

export async function createOrder(t, data, userName) {
  const id = uid();
  const number = await nextNumber(t, "orders", "");
  const customerId = data.customer_id || (await findOrCreateCustomer(t, data.customer || {}));
  const row = { kind: "umzug" };
  for (const [k, fn] of Object.entries(ORDER_FIELDS)) if (data[k] !== undefined) row[k] = fn(data[k]);
  const now = nowIso();
  const cols = ["id", "number", "customer_id", "status", "source", "mail_text", "created_by", "created_at", "updated_at", ...Object.keys(row)];
  const vals = [id, number, customerId, data.status || "neu", data.source || "manuell", str(data.mail_text, 50000), userName || null, now, now, ...Object.values(row)];
  await t.run(`INSERT INTO orders (${cols.join(", ")}) VALUES (${cols.map(() => "?").join(", ")})`, vals);
  await logEvent(t, id, "anlage", `Auftrag ${number} angelegt (${data.source || "manuell"}).`, userName);
  return { id, number, customer_id: customerId };
}

export async function setStatus(t, order, status, userName, note) {
  if (order.status === status) return;
  await t.run("UPDATE orders SET status = ?, updated_at = ?" + (status === "absage" ? ", lost_reason = ?" : "") + " WHERE id = ?", status === "absage" ? [status, nowIso(), str(note, 1000), order.id] : [status, nowIso(), order.id]);
  await logEvent(t, order.id, "status", `Status: ${STATUS[order.status]?.label || order.status} → ${STATUS[status]?.label || status}${note ? ` (${note})` : ""}`, userName);
  order.status = status;
}

// ---------- Dateien ----------
const ALLOWED = {
  "image/jpeg": [".jpg", (b) => b[0] === 0xff && b[1] === 0xd8],
  "image/png": [".png", (b) => b[0] === 0x89 && b[1] === 0x50],
  "image/webp": [".webp", (b) => b.slice(0, 4).toString() === "RIFF" && b.slice(8, 12).toString() === "WEBP"],
  "application/pdf": [".pdf", (b) => b.slice(0, 4).toString() === "%PDF"],
};
export const allowedMime = (m) => Boolean(ALLOWED[m]);

export async function storeFile(t, dataDir, { name, mime, data, order_id, owner_employee_id }, maxBytes) {
  const spec = ALLOWED[mime];
  if (!spec) throw bad("Dateityp nicht erlaubt (JPG, PNG, WEBP oder PDF).");
  const buf = Buffer.isBuffer(data) ? data : Buffer.from(String(data || "").replace(/^data:[^,]+,/, ""), "base64");
  if (!buf.length) throw bad("Datei ist leer.");
  if (buf.length > maxBytes) throw bad(`Datei zu groß (max. ${Math.round(maxBytes / 1048576)} MB).`);
  if (!spec[1](buf)) throw bad("Dateiinhalt passt nicht zum Dateityp.");
  const id = uid();
  const d = nowLocal().day;
  const rel = join("files", d.slice(0, 4), d.slice(5, 7), id + spec[0]);
  await mkdir(join(dataDir, "files", d.slice(0, 4), d.slice(5, 7)), { recursive: true });
  await writeFile(join(dataDir, rel), buf);
  const safeName = (str(name, 120) || "datei").replace(/[^\wäöüÄÖÜß.\- ]/g, "_").replace(new RegExp(`\\${extname(name || "x")}$`), "") + spec[0];
  await t.run("INSERT INTO files (id, name, mime, size, path, order_id, owner_employee_id, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)", [
    id, safeName, mime, buf.length, rel, order_id || null, owner_employee_id || null, nowIso(),
  ]);
  return id;
}

// ---------- Planung: Konflikte ----------
const overlapDays = (aFrom, aTo, bFrom, bTo) => aFrom <= bTo && bFrom <= aTo;
export async function planConflicts(db, { orderId, start, end, employeeIds = [], vehicleIds = [] }) {
  const out = [];
  if (!start) return out;
  const endV = end || start;
  const dFrom = start.slice(0, 10), dTo = endV.slice(0, 10);
  for (const eid of employeeIds) {
    const emp = await db.get("SELECT name FROM employees WHERE id = ?", [eid]);
    const abs = await db.all("SELECT kind, start_date, end_date, status FROM absences WHERE employee_id = ? AND status IN ('beantragt','genehmigt','gemeldet') AND start_date <= ? AND end_date >= ?", [eid, dTo, dFrom]);
    for (const a of abs) out.push({ type: "abwesend", employee_id: eid, text: `${emp?.name || "Mitarbeiter"}: ${a.kind === "krank" ? "krank gemeldet" : a.kind === "urlaub" ? "Urlaub" : "abwesend"} (${a.start_date} bis ${a.end_date}${a.status === "beantragt" ? ", beantragt" : ""})` });
    const busy = await db.all(
      "SELECT o.number, o.scheduled_start, o.scheduled_end FROM orders o JOIN order_staff s ON s.order_id = o.id WHERE s.employee_id = ? AND o.id <> ? AND o.status NOT IN ('storniert','absage','abgerechnet') AND o.scheduled_start IS NOT NULL AND o.scheduled_start < ? AND COALESCE(o.scheduled_end, o.scheduled_start) > ?",
      [eid, orderId || "", endV > start ? endV : start + "~", start]
    );
    for (const b of busy) out.push({ type: "doppelt", employee_id: eid, text: `${emp?.name || "Mitarbeiter"} ist schon für Auftrag ${b.number} eingeplant (${b.scheduled_start.replace("T", " ")}).` });
  }
  for (const vid of vehicleIds) {
    const v = await db.get("SELECT name FROM vehicles WHERE id = ?", [vid]);
    const busy = await db.all(
      "SELECT o.number, o.scheduled_start FROM orders o JOIN order_vehicles x ON x.order_id = o.id WHERE x.vehicle_id = ? AND o.id <> ? AND o.status NOT IN ('storniert','absage','abgerechnet') AND o.scheduled_start IS NOT NULL AND o.scheduled_start < ? AND COALESCE(o.scheduled_end, o.scheduled_start) > ?",
      [vid, orderId || "", endV > start ? endV : start + "~", start]
    );
    for (const b of busy) out.push({ type: "fahrzeug", vehicle_id: vid, text: `Fahrzeug ${v?.name || ""} ist schon für Auftrag ${b.number} verplant (${b.scheduled_start.replace("T", " ")}).` });
  }
  return out;
}
export { overlapDays };

// ---------- Mitarbeiter-Auswertung ----------
export async function employeeReport(db, emp, year, month) {
  const [mFrom, mTo] = monthRange(year, month);
  const yFrom = `${year}-01-01`, yTo = `${year}-12-31`;
  const daily = (Number(emp.weekly_hours) || 0) / 5; // Sollstunden je Arbeitstag
  const entries = await db.all(
    "SELECT t.*, o.number AS order_number, o.title AS order_title FROM time_entries t LEFT JOIN orders o ON o.id = t.order_id WHERE t.employee_id = ? AND t.day BETWEEN ? AND ? ORDER BY t.day, t.start_time",
    [emp.id, mFrom, mTo]
  );
  const absences = await db.all("SELECT * FROM absences WHERE employee_id = ? AND start_date <= ? AND end_date >= ? ORDER BY start_date", [emp.id, yTo, yFrom]);
  const counted = absences.filter((a) => a.status === "genehmigt" || a.status === "gemeldet");
  // Im laufenden Monat zählt das Soll nur bis heute – sonst stünden früh im Monat hohe Minusstunden da.
  const today = nowLocal().day;
  const sollTo = today >= mFrom && today <= mTo ? today : mTo;
  const futureMonth = mFrom > today;
  const absDaysMonth = counted.reduce((s, a) => s + (a.half_day ? 0.5 : workdays(a.start_date, a.end_date, mFrom, mTo)), 0);
  const absDaysSoll = counted.reduce((s, a) => s + (a.half_day ? (a.start_date <= sollTo ? 0.5 : 0) : workdays(a.start_date, a.end_date, mFrom, sollTo)), 0);
  const targetMin = futureMonth ? 0 : Math.round(Math.max(0, workdays(mFrom, sollTo) - absDaysSoll) * daily * 60);
  const targetFullMin = Math.round(Math.max(0, workdays(mFrom, mTo) - absDaysMonth) * daily * 60);
  const actualMin = entries.reduce((s, e) => s + (e.minutes || 0), 0);
  const byOrder = {};
  for (const e of entries) {
    const k = e.order_id || "ohne";
    byOrder[k] ||= { order_id: e.order_id, number: e.order_number || "–", title: e.order_title || "Ohne Auftrag", minutes: 0 };
    byOrder[k].minutes += e.minutes || 0;
  }
  const vacTaken = counted.filter((a) => a.kind === "urlaub").reduce((s, a) => s + (a.half_day ? 0.5 : workdays(a.start_date, a.end_date, yFrom, yTo)), 0);
  const vacPlanned = absences.filter((a) => a.kind === "urlaub" && a.status === "beantragt").reduce((s, a) => s + (a.half_day ? 0.5 : workdays(a.start_date, a.end_date, yFrom, yTo)), 0);
  const sickDays = counted.filter((a) => a.kind === "krank").reduce((s, a) => s + workdays(a.start_date, a.end_date, yFrom, yTo), 0);
  const sickCases = counted.filter((a) => a.kind === "krank").length;
  const yearRow = await db.get("SELECT COALESCE(SUM(minutes),0) AS m, COUNT(DISTINCT order_id) AS jobs FROM time_entries WHERE employee_id = ? AND day BETWEEN ? AND ?", [emp.id, yFrom, yTo]);
  const unapproved = entries.filter((e) => !e.approved).length;
  return {
    period: { year, month, from: mFrom, to: mTo },
    month: { target_min: targetMin, target_full_min: targetFullMin, soll_until: futureMonth ? null : sollTo, actual_min: actualMin, overtime_min: actualMin - targetMin, entries, by_order: Object.values(byOrder).sort((a, b) => b.minutes - a.minutes), absence_days: absDaysMonth, unapproved },
    year: {
      minutes: yearRow?.m || 0,
      jobs: yearRow?.jobs || 0,
      vacation_entitlement: Number(emp.vacation_days) || 0,
      vacation_taken: vacTaken,
      vacation_planned: vacPlanned,
      vacation_remaining: (Number(emp.vacation_days) || 0) - vacTaken - vacPlanned,
      sick_days: sickDays,
      sick_cases: sickCases,
    },
    absences,
  };
}

export function todayStatusForEmployees(absences, orders, today) {
  const st = {};
  for (const a of absences) if (a.start_date <= today && a.end_date >= today && (a.status === "genehmigt" || a.status === "gemeldet")) st[a.employee_id] = a.kind;
  for (const o of orders) for (const eid of o.staff || []) if (!st[eid]) st[eid] = "eingeplant";
  return st;
}

export const csv = (rows) =>
  "﻿" + rows.map((r) => r.map((v) => {
    if (typeof v === "number") return String(v).replace(".", ",");
    const s = v === null || v === undefined ? "" : String(v);
    const inj = /^[=+\-@\t\r]/.test(s); // Schutz vor Formel-Injektion in Excel
    return /[;"\n\r]/.test(s) || inj ? `"${(inj ? "'" : "") + s.replace(/"/g, '""')}"` : s;
  }).join(";")).join("\r\n");

export { isoDay, addDays };
