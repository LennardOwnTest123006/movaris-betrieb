@echo off
REM MOVARIS Betrieb auf einem Windows-Buero-PC starten (Node.js 22 muss installiert sein)
cd /d "%~dp0"
if not exist node_modules call npm install --omit=dev
if not exist .env copy .env.example .env
start "" http://localhost:8080
npm start
