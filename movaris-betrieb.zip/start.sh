#!/bin/sh
# MOVARIS Betrieb starten (Linux/macOS, Node.js 22)
cd "$(dirname "$0")"
[ -d node_modules ] || npm install --omit=dev
[ -f .env ] || cp .env.example .env
exec npm start
