@echo off
rem Test-Start mit Beispieldaten. Node 22 noetig (nodejs.org).
set ADMIN_EMAIL=chef@movaris.de
set ADMIN_PASSWORD=SehrGeheim123
set INQUIRY_KEY=testkey
set DATABASE_URL=sqlite:./data/test.db
if not exist node_modules call npm install --omit=dev
start "MOVARIS Server" cmd /c "npm start"
timeout /t 5 >nul
node --disable-warning=ExperimentalWarning seed-demo.mjs http://127.0.0.1:8080
start http://localhost:8080
echo.
echo Buero: chef@movaris.de / SehrGeheim123   Mitarbeiter-App (/m/): tom@movaris.de / TomTom12345
pause
