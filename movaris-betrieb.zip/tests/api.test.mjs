import test from "node:test";
import { runFlow } from "./flow.mjs";
test("Gesamtablauf mit SQLite", async (t) => runFlow(t));
