// Kompletter Geschäftsablauf: Anfrage → Angebot → Zuschlag → Planung → Einsatz → Stunden/Urlaub/Krank.
// Läuft identisch gegen SQLite und PostgreSQL (PGlite).
import assert from "node:assert/strict";
import { startApp, client, TINY_JPEG } from "./helpers.mjs";

export async function runFlow(t, { db } = {}) {
  const s = await startApp({ db, env: { INQUIRY_KEY: "test-key-123", PUBLIC_URL: "https://betrieb.example" } });
  const admin = client(s.base);
  try {
    await t.test("Ersteinrichtung und Anmeldung", async () => {
      assert.deepEqual((await admin.get("/api/setup")).data, { needed: true });
      assert.equal((await admin.post("/api/setup", { name: "Chef", email: "chef@movaris.de", password: "kurz" })).status, 400);
      assert.equal((await admin.post("/api/setup", { name: "Chef", email: "chef@movaris.de", password: "SehrGeheim123" })).status, 200);
      assert.equal((await admin.post("/api/setup", { name: "X", email: "x@movaris.de", password: "SehrGeheim123" })).status, 409);
      const me = await admin.get("/api/me");
      assert.equal(me.data.user.role, "admin");
      const anon = client(s.base);
      assert.equal((await anon.get("/api/orders")).status, 401);
      assert.equal((await anon.post("/api/login", { email: "chef@movaris.de", password: "falsch1234" })).status, 401);
      // CSRF-Schutz: ohne eigenen Header kein Schreibzugriff
      const r = await fetch(s.base + "/api/customers", { method: "POST", headers: { "content-type": "application/json", cookie: admin.cookie }, body: JSON.stringify({ name: "X" }) });
      assert.equal(r.status, 403);
    });

    const ids = {};
    await t.test("Stammdaten: Mitarbeiter, Zugang, Fahrzeug, Preise", async () => {
      ids.e1 = (await admin.post("/api/employees", { name: "Tom Träger", weekly_hours: 40, vacation_days: 30, color: "#ff0000" })).data.id;
      ids.e2 = (await admin.post("/api/employees", { name: "Lea Lift", weekly_hours: 30, vacation_days: 28 })).data.id;
      ids.v1 = (await admin.post("/api/vehicles", { name: "Koffer-LKW 1", plate: "WOB-MV 1" })).data.id;
      assert.equal((await admin.post("/api/users", { email: "tom@movaris.de", name: "Tom", role: "mitarbeiter", password: "TomTom12345", employee_id: ids.e1 })).status, 200);
      assert.equal((await admin.post("/api/users", { email: "lea@movaris.de", name: "Lea", role: "mitarbeiter", password: "LeaLea12345", employee_id: ids.e2 })).status, 200);
      const prices = (await admin.get("/api/prices")).data.rows;
      const set = { personal_std: 45, lkw_std: 35, km: 1.2, moebellift: 180, karton: 2.9 };
      for (const p of prices) if (set[p.key]) assert.equal((await admin.put(`/api/prices/${p.id}`, { price: set[p.key] })).status, 200);
      const st = await admin.put("/api/settings", { company: { footer: "MOVARIS · Wolfsburg" }, calc: { vat_rate: 19, floor_pct: 5 } });
      assert.equal(st.data.calc.floor_pct, 5);
      assert.equal(st.data.company.name, "MOVARIS");
    });

    await t.test("Rollen: Mitarbeiter kommt nicht an Büro-Daten", async () => {
      const tom = client(s.base);
      assert.equal((await tom.post("/api/login", { email: "tom@movaris.de", password: "TomTom12345" })).data.role, "mitarbeiter");
      for (const p of ["/api/orders", "/api/employees", "/api/settings", "/api/users", "/api/dashboard", "/api/time"]) assert.equal((await tom.get(p)).status, 403, p);
      assert.equal((await tom.put("/api/prices/x", { price: 1 })).status, 403);
      assert.equal((await tom.get("/api/my/overview")).status, 200);
    });

    await t.test("Eingang: Website-Formular, Postfach-Mails, Zuordnung, Dubletten", async () => {
      const anon = client(s.base);
      assert.equal((await anon.post("/api/public/inquiry", { name: "A", email: "a@b.de" }, { "x-inquiry-key": "falsch" })).status, 401);
      const w = await anon.post("/api/public/inquiry", { type: "umzug", name: "Erika Muster", email: "erika@example.com", phone: "0170 111222", date: "20.11.2026", from: "38440 Wolfsburg, 3. OG", to: "38100 Braunschweig", size: "3 Zimmer", message: "Klavier dabei" }, { "x-inquiry-key": "test-key-123" });
      assert.equal(w.status, 200);
      assert.equal(w.data.created, true);
      const ing = (m) => s.app.mail.ingest({ source: "imap", date: new Date().toISOString(), ...m });
      const a = await ing({ messageId: "<m1@x>", subject: "Anfrage Umzug", text: "Hallo, wir ziehen am 01.12.2026 von 38440 Wolfsburg nach 38100 Braunschweig, ca. 30 m³.", fromName: "Max Muster", fromEmail: "max@example.com" });
      assert.equal(a.status, "angelegt");
      assert.equal((await ing({ messageId: "<m1@x>", subject: "Anfrage Umzug", text: "x", fromEmail: "max@example.com" })).status, "doppelt");
      const b = await ing({ messageId: "<m2@x>", subject: "Ihre Rechnung 4711", text: "Anbei die Rechnung.", fromEmail: "buchhaltung@lieferant.de" });
      assert.equal(b.status, "offen");
      const c = await ing({ messageId: "<m3@x>", subject: "Automatische Antwort: Urlaub", text: "Bin weg", fromEmail: "x@y.de" });
      assert.equal(c.status, "ignoriert");
      const orders = (await admin.get("/api/orders?status=neu")).data.rows;
      assert.equal(orders.length, 2);
      const max = orders.find((o) => o.customer === "Max Muster");
      ids.order = max.id;
      ids.orderNumber = max.number;
      const d = await ing({ messageId: "<m4@x>", subject: `Re: Ihr Angebot zu Auftrag ${max.number}`, text: "Passt der Termin?", fromEmail: "max@example.com" });
      assert.equal(d.status, "zugeordnet");
      const mails = (await admin.get("/api/mail?status=offen")).data.rows;
      assert.equal(mails.length, 1);
      const created = await admin.post(`/api/mail/${mails[0].id}/create-order`);
      assert.equal(created.status, 200);
      assert.equal((await admin.get("/api/badges")).data.mail_open, 0);
      const det = (await admin.get(`/api/orders/${max.id}`)).data;
      assert.equal(det.order.desired_date, "2026-12-01");
      assert.equal(det.order.volume_m3, 30);
      assert.ok(det.events.some((e) => e.kind === "mail" && e.text.includes("Passt der Termin")));
      assert.ok(det.order.mail_text.includes("Wolfsburg"));
      const erika = (await admin.get("/api/orders?q=erika")).data.rows[0];
      assert.equal(erika.kind, "umzug");
      assert.equal(erika.source, "website");
    });

    await t.test("Statuswechsel nur entlang des Prozesses", async () => {
      assert.equal((await admin.post(`/api/orders/${ids.order}/status`, { status: "in_bearbeitung" })).status, 200);
      const buero = client(s.base);
      await admin.post("/api/users", { email: "buero@movaris.de", name: "Büro", role: "buero", password: "Buero1234567" });
      await buero.post("/api/login", { email: "buero@movaris.de", password: "Buero1234567" });
      assert.equal((await buero.post(`/api/orders/${ids.order}/status`, { status: "abgerechnet" })).status, 400);
      assert.equal((await buero.put(`/api/prices/x`, { price: 1 })).status, 403);
      assert.equal((await buero.get(`/api/orders/${ids.order}`)).status, 200);
    });

    await t.test("Angebot: kalkulieren, versenden, online annehmen", async () => {
      const prices = (await admin.get("/api/prices")).data.rows;
      const lift = prices.find((p) => p.key === "moebellift");
      const input = { staff: 3, hours: 6, trucks: 1, km: 40, floors_from: 3, elevator_from: false, extras: [{ id: lift.id, qty: 1 }], custom: [{ text: "Klaviertransport", qty: 1, price: 250 }] };
      const prev = await admin.post("/api/calc", { input });
      // Personal 810, Etagen 3×5 % = 121,50, LKW 210, km 48, Lift 180, Klavier 250 → 1619,50 netto
      assert.equal(prev.data.totals.net, 1619.5);
      assert.equal(prev.data.totals.gross, 1927.21);
      const o = await admin.post(`/api/orders/${ids.order}/offers`, { input });
      assert.equal(o.status, 200);
      assert.match(o.data.number, /^A\d{4}-0001$/);
      ids.offer = o.data.id;
      let det = (await admin.get(`/api/orders/${ids.order}`)).data;
      assert.equal(det.order.status, "angebot_erstellt");
      const print = await admin.get(`/api/offers/${ids.offer}/print`);
      assert.match(print.data, /Festpreis gesamt/);
      assert.match(print.data, /1\.927,21/);
      const send = await admin.post(`/api/offers/${ids.offer}/send`, {});
      assert.equal(send.status, 400); // kein Mailversand eingerichtet → klare Meldung
      assert.match(send.data.error, /nicht eingerichtet/);
      const ms = await admin.post(`/api/offers/${ids.offer}/mark-sent`);
      assert.match(ms.data.link, /^https:\/\/betrieb\.example\/angebot\//);
      det = (await admin.get(`/api/orders/${ids.order}`)).data;
      assert.equal(det.order.status, "angebot_versendet");
      const token = ms.data.link.split("/").pop();
      const anon = client(s.base);
      const page = await anon.get(`/angebot/${token}`);
      assert.equal(page.status, 200);
      assert.match(page.data, /Verbindlich annehmen/);
      assert.equal((await anon.get(`/angebot/falsch`)).status, 404);
      const noAgree = await anon.raw("POST", `/angebot/${token}/annehmen`, "name=Max", { "content-type": "application/x-www-form-urlencoded" });
      assert.equal(noAgree.status, 400);
      const acc = await anon.raw("POST", `/angebot/${token}/annehmen`, "name=Max+Muster&agree=1", { "content-type": "application/x-www-form-urlencoded" });
      assert.equal(acc.status, 200);
      assert.match(acc.data, /Vielen Dank/);
      det = (await admin.get(`/api/orders/${ids.order}`)).data;
      assert.equal(det.order.status, "zuschlag");
      assert.equal(det.offers[0].status, "angenommen");
      const again = await anon.raw("POST", `/angebot/${token}/ablehnen`, "reason=doch+nicht", { "content-type": "application/x-www-form-urlencoded" });
      assert.match(again.data, /bereits eine Entscheidung/);
      const dash = (await admin.get("/api/dashboard")).data;
      assert.equal(dash.won.count, 1);
      assert.equal(dash.won.gross, 1927.21);
    });

    await t.test("Planung mit Konfliktprüfung (Urlaub, Doppelbelegung)", async () => {
      const lea = client(s.base);
      await lea.post("/api/login", { email: "lea@movaris.de", password: "LeaLea12345" });
      const ab = await lea.post("/api/my/absences", { kind: "urlaub", start_date: "2026-12-01", end_date: "2026-12-04" });
      assert.equal(ab.status, 200);
      assert.equal(ab.data.status, "beantragt");
      assert.equal(ab.data.days, 4);
      const plan = { start: "2026-12-01T08:00", end: "2026-12-01T17:00", employee_ids: [ids.e1, ids.e2], vehicle_ids: [ids.v1], lead_id: ids.e1 };
      const c = await admin.post(`/api/orders/${ids.order}/schedule`, plan);
      assert.equal(c.status, 409);
      assert.ok(c.data.conflicts.some((x) => x.employee_id === ids.e2));
      const ok = await admin.post(`/api/orders/${ids.order}/schedule`, { ...plan, employee_ids: [ids.e1] });
      assert.equal(ok.status, 200);
      assert.equal((await admin.get(`/api/orders/${ids.order}`)).data.order.status, "geplant");
      // zweiter Auftrag am selben Tag mit gleichem LKW → Konflikt
      const other = (await admin.get("/api/orders?q=erika")).data.rows[0];
      const c2 = await admin.post(`/api/orders/${other.id}/schedule`, { start: "2026-12-01T13:00", end: "2026-12-01T15:00", employee_ids: [ids.e1], vehicle_ids: [ids.v1] });
      assert.equal(c2.status, 409);
      assert.equal(c2.data.conflicts.length, 2);
      const p = (await admin.get("/api/plan?from=2026-11-30&to=2026-12-06")).data;
      assert.equal(p.orders.length, 1);
      assert.equal(p.absences.length, 1);
    });

    await t.test("Mitarbeiter-App: Zeiterfassung, Rückmeldung mit Foto, Abschluss", async () => {
      const tom = client(s.base);
      await tom.post("/api/login", { email: "tom@movaris.de", password: "TomTom12345" });
      const lea = client(s.base);
      await lea.post("/api/login", { email: "lea@movaris.de", password: "LeaLea12345" });
      const jobs = (await tom.get("/api/my/jobs")).data.rows;
      assert.equal(jobs.length, 1);
      assert.equal(jobs[0].customer, "Max Muster");
      assert.ok(!("gross" in jobs[0]));
      assert.equal((await lea.get(`/api/my/jobs/${ids.order}`)).status, 404); // nicht zugeteilt
      assert.equal((await lea.post("/api/my/clock", { action: "start", order_id: ids.order })).status, 403);
      assert.equal((await tom.post("/api/my/clock", { action: "start", order_id: ids.order })).status, 200);
      assert.equal((await tom.post("/api/my/clock", { action: "start" })).status, 400);
      assert.equal((await admin.get(`/api/orders/${ids.order}`)).data.order.status, "in_durchfuehrung");
      const stop = await tom.post("/api/my/clock", { action: "stop", break_min: 0 });
      assert.equal(stop.status, 200);
      const fb = await tom.post("/api/my/feedback", { order_id: ids.order, kind: "sonderwunsch", text: "Kunde möchte Lampen abgebaut haben", files: [{ name: "foto.jpg", mime: "image/jpeg", data: TINY_JPEG }] });
      assert.equal(fb.status, 200);
      const fake = await tom.post("/api/my/feedback", { order_id: ids.order, kind: "info", text: "x", files: [{ name: "x.jpg", mime: "image/jpeg", data: Buffer.from("<html>").toString("base64") }] });
      assert.equal(fake.status, 400);
      const det = (await admin.get(`/api/orders/${ids.order}`)).data;
      assert.match(det.order.special_wishes, /Lampen/);
      const fileId = det.feedback[0].file_ids[0];
      const img = await fetch(`${s.base}/api/files/${fileId}`, { headers: { cookie: tom.cookie } });
      assert.equal(img.status, 200);
      assert.equal(img.headers.get("content-type"), "image/jpeg");
      assert.match(img.headers.get("content-security-policy"), /sandbox/);
      assert.equal((await fetch(`${s.base}/api/files/${fileId}`, { headers: { cookie: lea.cookie } })).status, 403);
      assert.equal((await admin.get("/api/badges")).data.feedback_open, 1);
      assert.equal((await tom.post("/api/my/feedback", { order_id: ids.order, kind: "abschluss" })).status, 200);
      assert.equal((await admin.get(`/api/orders/${ids.order}`)).data.order.status, "erledigt");
    });

    await t.test("Stunden, Urlaub, Krankmeldung und Auswertung", async () => {
      const tom = client(s.base);
      await tom.post("/api/login", { email: "tom@movaris.de", password: "TomTom12345" });
      const today = new Date().toISOString().slice(0, 10);
      const te = await tom.post("/api/my/time", { day: today, start_time: "07:00", end_time: "16:30", break_min: 15, order_id: ids.order, note: "Umzug" });
      assert.equal(te.status, 200);
      assert.equal(te.data.minutes, 555);
      assert.match(te.data.warn, /45 Min/);
      assert.equal((await tom.post("/api/my/time", { day: "2099-01-01", start_time: "07:00", end_time: "08:00" })).status, 400);
      const erika = (await admin.get("/api/orders?q=erika")).data.rows[0];
      assert.equal((await admin.post(`/api/orders/${erika.id}/schedule`, { start: "2026-12-02T08:00", end: "2026-12-02T12:00", employee_ids: [ids.e1] })).status, 200);
      const k = await tom.post("/api/my/absences", { kind: "krank", start_date: "2026-11-30", end_date: "2026-12-02", note: "Grippe" });
      assert.equal(k.data.status, "gemeldet");
      assert.equal(k.data.conflicts.length, 1); // für 02.12. bei Erika eingeplant (erledigte Aufträge zählen nicht)
      const det = (await admin.get(`/api/orders/${erika.id}`)).data;
      assert.ok(det.events.some((e) => e.kind === "warnung" && e.text.includes("Tom Träger")));
      const pending = (await admin.get("/api/absences?status=beantragt")).data.rows;
      assert.equal(pending.length, 1);
      assert.equal((await admin.post(`/api/absences/${pending[0].id}/decide`, { status: "genehmigt" })).status, 200);
      const rep = (await admin.get(`/api/employees/${ids.e2}?year=2026&month=12`)).data.report;
      assert.equal(rep.year.vacation_taken, 4);
      assert.equal(rep.year.vacation_remaining, 24);
      const tomRep = (await admin.get(`/api/employees/${ids.e1}?year=2026&month=12`)).data.report;
      assert.equal(tomRep.year.sick_days, 3); // 30.11., 1.12., 2.12.
      assert.equal(tomRep.month.absence_days, 2);
      const un = (await admin.get("/api/time?unapproved=1")).data.rows;
      assert.ok(un.length >= 2);
      assert.equal((await admin.post("/api/time/approve-all", { ids: un.map((x) => x.id) })).status, 200);
      assert.equal((await admin.get("/api/badges")).data.time_unapproved, 0);
      const freigegeben = (await tom.get("/api/my/time")).data.entries.find((x) => x.minutes === 555);
      assert.equal((await tom.del(`/api/my/time/${freigegeben.id}`)).status, 400);
      const emps = (await admin.get("/api/employees")).data.rows;
      assert.ok(!("hourly_wage" in emps[0]));
      const csvr = await admin.get(`/api/export/time.csv?from=${today}&to=${today}`);
      assert.match(csvr.data, /Tom Träger/);
      assert.match(csvr.headers.get("content-disposition"), /attachment/);
    });

    await t.test("Benutzerverwaltung und Passwort", async () => {
      const users = (await admin.get("/api/users")).data.rows;
      const me = users.find((u) => u.email === "chef@movaris.de");
      assert.equal((await admin.put(`/api/users/${me.id}`, { role: "buero" })).status, 400); // letzter Admin bleibt
      const tom = client(s.base);
      await tom.post("/api/login", { email: "tom@movaris.de", password: "TomTom12345" });
      assert.equal((await tom.post("/api/me/password", { old: "falsch", new: "NeuesPasswort1" })).status, 400);
      assert.equal((await tom.post("/api/me/password", { old: "TomTom12345", new: "NeuesPasswort1" })).status, 200);
      assert.equal((await tom.get("/api/my/overview")).status, 200);
      const tomUser = users.find((u) => u.email === "tom@movaris.de");
      await admin.put(`/api/users/${tomUser.id}`, { active: false });
      assert.equal((await tom.get("/api/my/overview")).status, 401);
    });
  } finally {
    await s.close();
    await s.db.close?.();
  }
}
