// Test-Hilfen: App mit frischer Datenbank auf zufälligem Port starten, HTTP-Client mit Cookie.
import { createServer } from "node:http";
import { mkdtempSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { openSqlite, pgAdapter } from "../server/db.js";
import { createApp } from "../server/app.js";
import { config } from "../server/config.js";

export async function pgliteDb() {
  const { PGlite } = await import("@electric-sql/pglite");
  const pg = new PGlite();
  const q = async (sql, p) => {
    const r = await pg.query(sql, p);
    return { rows: r.rows, rowCount: r.affectedRows ?? r.rows.length };
  };
  return pgAdapter(q, async () => ({ query: q, release() {} }), () => pg.close());
}

export async function startApp({ env = {}, db } = {}) {
  const dataDir = mkdtempSync(join(tmpdir(), "mvtest-"));
  const cfg = { ...config({ ...env }), dataDir };
  const database = db || (await openSqlite(":memory:"));
  const silent = { error: () => {} };
  const app = await createApp({ db: database, cfg, log: silent });
  const server = createServer(app.handler);
  await new Promise((r) => server.listen(0, "127.0.0.1", r));
  const base = `http://127.0.0.1:${server.address().port}`;
  return { app, db: database, cfg, base, close: () => new Promise((r) => server.close(r)) };
}

export function client(base) {
  let cookie = "";
  const call = async (method, path, body, headers = {}) => {
    const r = await fetch(base + path, {
      method,
      redirect: "manual",
      headers: { "x-mv": "1", ...(body !== undefined ? { "content-type": "application/json" } : {}), ...(cookie ? { cookie } : {}), ...headers },
      body: body !== undefined ? (typeof body === "string" ? body : JSON.stringify(body)) : undefined,
    });
    const sc = r.headers.get("set-cookie");
    if (sc) cookie = sc.split(";")[0].endsWith("=") ? "" : sc.split(";")[0];
    const ct = r.headers.get("content-type") || "";
    const data = ct.includes("json") ? await r.json() : await r.text();
    return { status: r.status, data, headers: r.headers };
  };
  return {
    get: (p, h) => call("GET", p, undefined, h),
    post: (p, b = {}, h) => call("POST", p, b, h),
    put: (p, b = {}, h) => call("PUT", p, b, h),
    del: (p) => call("DELETE", p),
    raw: call,
    get cookie() { return cookie; },
  };
}

// 1×1 JPEG für Foto-Uploads
export const TINY_JPEG = "/9j/4AAQSkZJRgABAQEASABIAAD/2wBDAP//////////////////////////////////////////////////////////////////////////////////////wgALCAABAAEBAREA/8QAFBABAAAAAAAAAAAAAAAAAAAAAP/aAAgBAQABPxA=";
