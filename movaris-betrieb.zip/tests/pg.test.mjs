import test from "node:test";
import { runFlow } from "./flow.mjs";
import { pgliteDb } from "./helpers.mjs";
test("Gesamtablauf mit PostgreSQL (PGlite)", async (t) => runFlow(t, { db: await pgliteDb() }));
