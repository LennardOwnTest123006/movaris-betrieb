import test from "node:test";
import assert from "node:assert/strict";
import { calculate, suggest, inventoryVolume, DEFAULT_PRICE_ITEMS } from "../public/shared/calc.js";
import { holidays, workdays, isWorkday, minutesBetween, legalBreak, hm } from "../public/shared/dates.js";
import { parseInquiry, looksLikeInquiry, parseGermanDate } from "../server/parse.js";
import { csv } from "../server/services.js";

const prices = DEFAULT_PRICE_ITEMS.map((p, i) => ({ ...p, id: "p" + i, price: { personal_std: 40, lkw_std: 30, km: 1.5, moebellift: 150, karton: 2.5, halteverbot: 90 }[p.key] || 0 }));

test("Kalkulation: Personal, LKW, km, Zusatzleistung, MwSt.", () => {
  const r = calculate({ staff: 3, hours: 5, trucks: 1, km: 20, extras: [{ key: "moebellift", qty: 1 }, { key: "karton", qty: 40 }] }, prices, { vat_rate: 19 });
  const t = Object.fromEntries(r.positions.map((p) => [p.key, p.total]));
  assert.equal(t.personal_std, 600); // 3 × 5 × 40
  assert.equal(t.lkw_std, 150); // 1 × 5 × 30
  assert.equal(t.km, 30);
  assert.equal(t.moebellift, 150);
  assert.equal(t.karton, 100);
  assert.equal(r.totals.net, 1030);
  assert.equal(r.totals.vat_sum, 195.7);
  assert.equal(r.totals.gross, 1225.7);
  assert.deepEqual(r.hints, []);
});

test("Kalkulation: Zuschläge nur auf Personal, Nachlass anteilig vor MwSt.", () => {
  const r = calculate({ staff: 2, hours: 4, trucks: 1, floors_from: 3, elevator_from: false, floors_to: 2, elevator_to: true, carry_from_m: 35, weekend: true, discount_pct: 10 }, prices, { vat_rate: 19, floor_pct: 5, carry_free_m: 10, carry_pct_per_10m: 2, weekend_pct: 25 });
  // Personal 320, LKW 120. Zuschläge: 3 Etagen × 5 % = 15 % → 48; Laufweg 25 m → 3 × 2 % = 6 % → 19,20; Wochenende 25 % → 80
  const sur = r.positions.filter((p) => p.group === "Zuschläge").map((p) => p.total);
  assert.deepEqual(sur, [48, 19.2, 80]);
  assert.equal(r.totals.subtotal, 587.2);
  assert.equal(r.totals.net, 528.48);
  assert.equal(r.totals.gross, 628.89);
});

test("Kalkulation: fehlende Preise werden gemeldet, keine erfundenen Preise", () => {
  const zero = DEFAULT_PRICE_ITEMS.map((p, i) => ({ ...p, id: "z" + i }));
  const r = calculate({ staff: 2, hours: 3 }, zero, {});
  assert.equal(r.totals.gross, 0);
  assert.ok(r.hints.some((h) => h.includes("Preis fehlt")));
});

test("Kalkulation: Stundenschätzung aus Volumen nur mit eingestelltem Faktor", () => {
  assert.equal(suggest({ volume_m3: 30 }, {}).hours, 0);
  const s = suggest({ volume_m3: 30 }, { m3_per_man_hour: 1.5, travel_hours: 1, min_hours: 3 });
  assert.equal(s.manHours, 20);
  assert.equal(s.staff, 3);
  assert.equal(s.hours, 8); // 20/3 = 6,67 → 7 + 1 Std. Anfahrt
  assert.equal(inventoryVolume([{ m3: 1.5, qty: 2 }, { m3: 0.1, qty: 30 }]), 6);
});

test("Feiertage Niedersachsen 2026 und Arbeitstage", () => {
  const h = holidays(2026);
  for (const d of ["2026-04-03", "2026-04-06", "2026-05-14", "2026-05-25", "2026-10-31", "2026-10-03"]) assert.ok(h.has(d), d);
  assert.equal(isWorkday("2026-10-31"), false);
  assert.equal(workdays("2026-12-21", "2026-12-31"), 8); // 25.12. Feiertag (Fr), 26./27. Wochenende
  assert.equal(workdays("2026-04-01", "2026-04-07"), 3);
  assert.equal(minutesBetween("22:00", "06:00"), 480);
  assert.equal(legalBreak(361), 30);
  assert.equal(legalBreak(541), 45);
  assert.equal(hm(-75), "-1:15");
});

test("Mail-Erkennung: Format des Website-Formulars", () => {
  const text = "Neue unverbindliche Anfrage über die Website (KEINE Buchung)\n\nAnfrageart: Möbelhotel / Einlagerung (MOVARIS lagert ein)\nName: Erika Muster\nE-Mail: erika@example.com\nTelefon: 0170 1234567\nWunschtermin: 12.11.2026\nGröße/Umfang: 3 Zimmer\nNachricht: Bitte melden\nZweite Zeile";
  const p = parseInquiry({ subject: "Möbelhotel – Anfrage von Erika Muster", text, fromEmail: "movaris@agentmail.to", replyTo: "erika@example.com" });
  assert.equal(p.is_form, true);
  assert.equal(p.kind, "moebelhotel");
  assert.equal(p.email, "erika@example.com");
  assert.equal(p.desired_date, "2026-11-12");
  assert.equal(p.phone, "0170 1234567");
  assert.match(p.message, /Zweite Zeile/);
});

test("Mail-Erkennung: Freitext mit Orten, Volumen, Etagen", () => {
  const p = parseInquiry({ subject: "Umzug Anfrage", text: "Hallo, wir ziehen am 15.12.2026 von 38440 Wolfsburg nach 38100 Braunschweig. Ca. 35 m³, 3. OG ohne Aufzug, 3-Zimmer-Wohnung. Tel 05361 123456", fromName: "Max Muster", fromEmail: "max@example.com" }, new Date("2026-10-31"));
  assert.equal(p.kind, "umzug");
  assert.equal(p.desired_date, "2026-12-15");
  assert.equal(p.volume_m3, 35);
  assert.equal(p.rooms, 3);
  assert.equal(p.from_floor, 3);
  assert.match(p.from_address, /38440 Wolfsburg/);
  assert.match(p.to_address, /38100 Braunschweig/);
  assert.equal(p.name, "Max Muster");
  assert.ok(looksLikeInquiry("Umzug", ""));
  assert.equal(looksLikeInquiry("Ihre Rechnung Nr. 4711", "Sehr geehrte Damen und Herren, anbei die Rechnung."), false);
  assert.equal(parseGermanDate("am 3.1.", new Date("2026-10-31")), "2027-01-03");
});

test("CSV: Semikolon, Anführungszeichen, Schutz vor Formel-Injektion", () => {
  const out = csv([["a;b", '=SUMME(1)', 1.5, "-x"]]);
  assert.equal(out, '﻿"a;b";"\'=SUMME(1)";1,5;"\'-x"');
});
